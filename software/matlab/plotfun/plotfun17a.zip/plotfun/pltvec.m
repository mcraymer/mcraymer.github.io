function pltvec(x,y,vx,vy,vscale,vectype)
% PLOTVEC  Plots a set of vectors at points on current figure.
% Useage:  pltvec(x,y,vx,vy,vscale,vectype)
% Version: 1996-11-27
% Input:   x       - x point coordinates
%          y       - y point coordinates
%          vx      - vector x coordinate
%          vy      - vector y coordinate
%          vscale  - vector scale factor for plotting (default=1)
%          vectype - linetype for vectors (default 'y-')

% Version History
% 1996-11-27  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

% Check input arguments
if nargin<4
  error('Too few arguments.');
end
if nargin<5
  vscale=1;
end
if nargin<6
  vectype='y-';
end

% Plot discrepancy vectors
n=length(x);
for i=1:n
  xx=[x(i);x(i)+vx(i)*vscale];
  yy=[y(i);y(i)+vy(i)*vscale];
  plot(xx,yy,vectype);
% plot(xx,yy,'y-');
% plot([x(i);x(i)+vx(i)],[y(i);y(i)+vy(i)],'y-');
  hold on;
end
