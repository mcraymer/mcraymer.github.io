function plabel=ptlabels(n,val,prec)
% PTLABELS  Forms char array of point labels using point number and an
%   optional numerical value.
% Version: 1996-01-23
% Useage:  plabel=ptlabels(n,num)
% Input:   n - number of points
%          val - vector of numerical values (default=none)
%          prec - numerical precision to use in labels (default=3)
% Output:  plabel - array of point labels (char)

% Version History
% 1996-01-23  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<2
  val=0;
end
if nargin<3
  prec=3;
end

nc = length(int2str(n))+prec+6;  % max label chars
plabel=setstr(ones(n,nc).*' ');  % form blank array
for i=1:n                        % assign labels to array
  if val
    str=[' ' int2str(i) '(' num2str(val(i),prec) ')'];
  else
    str=[' ' int2str(i)];
  end
  plabel(i,1:length(str)) = str;
end
