function pltell(xo,yo,a,b,az,s,ltype)
% Plot Ellipse
%   Plots ellipse centred at (xo,yo).  Note: need to use a square
%   aspect ratio for plot; i.e., use axis('square') command when
%   defining plot area and axes.
% Version: 1995-01-25
% Useage:  ploell(xo,yo,a,b,az,s,ltype)
% Input:   xo - x (north) origin of ellipse
%          yo - y (east) origin of ellipse
%          a - major axis of ellipse
%          b - minor axis of ellipse
%          az - azimuth of major axis (radians)
%          s  - scale factor for ellise (default=1)
%          ltype - line type (default=solid,red)
% Output:  Plotted ellipse centred at (xo,yo)

% Version History
% 1995-01-25  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<5
  error('Wrong number of input arguements');
end
if nargin<6
  s=1;            % Define scale factor
end
dt=0.1;           % Angular resolution
t=[(0:dt:2*pi)';0];
Rt=[cos(az) sin(az); -sin(az) cos(az)];
x=s*a*cos(t);
y=s*b*sin(t);
xx=xo+[x y]*Rt(:,1);
yy=yo+[x y]*Rt(:,2);
if nargin<7
  plot(yy,xx);
else
  plot(yy,xx,ltype);
end
