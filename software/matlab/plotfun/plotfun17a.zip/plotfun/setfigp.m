function setfigp(var1,var2)
% SETFIGP  Sets default figure position. See also FIGDEF, GETFIGP,
%   SETFIGS.
% Version: 1997-02-09
% Usage:   setfigp(h,pos)
%          setfigp(pos)
%          setfigp
% Input:   h   - figure handle (optional, current assumed)
%          pos - new default figure position (pixels)
%                [left bottom width height]
%                (optional, startup default position assumed)
% Output:  none

% Version History
% 1997-02-09  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<1
  defigpos;
  return
elseif nargin==1
  h=0;
  pos=var1;
elseif nargin==2
  h=var1;
  pos=var2;
end

set(h,'DefaultFigurePosition',pos);
