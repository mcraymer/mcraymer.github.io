function pltell3(xo,yo,zo,C,ltype)
% PLTELL3  Plots projections of 3D error ellipsoid on each of three
%   coordinate planes centred at specified position given covariance
%   matrix. Note: use square aspect ratio for plot, i.e.,
%   axis('square'), when defining plot area and axes.
% Version: 2010-11-12
% Useage:  pltell3(xo,yo,zo,ax,az,inc,ltype)
% Input:   xo    - x coordinate of ellipsoid origin
%          yo    - y coordinate of ellipsoid origin
%          zo    - z coordinate of ellipsoid origin
%          C     - 3D covariance matrix of point
%          ltype - line type (default='b-')
% Output:  Plotted ellipsoid centred at xo

% Version History
% 2010-11-12  Initial version based on pltell.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<4 | nargin>5
  error('Wrong number of input arguements');
end
if nargin<5
  ltype='b-';
end
dt=0.1;              % Angular resolution for ellipses (rad)
t=[(0:dt:2*pi)';0];

% Plot ellipse in north-east plane (right handed system)
ind=[1 2];
[a,b,az]=errell2(C(ind,ind));
x=a*cos(t);
y=b*sin(t);
Rt=[cos(az) sin(az); -sin(az) cos(az)];
xx=xo+[x y]*Rt(:,1);
yy=yo+[x y]*Rt(:,2);
zz=zo*ones(size(t));
plot3(yy,xx,zz,ltype);

% Plot ellipse in north-up plane (right handed system)
ind=[1 3];
[a,b,az]=errell2(C(ind,ind));
x=a*cos(t);
y=b*sin(t);
Rt=[cos(az) sin(az); -sin(az) cos(az)];
xx=xo+[x y]*Rt(:,1);
yy=yo*ones(size(t));
zz=zo+[x y]*Rt(:,2);
plot3(yy,xx,zz,ltype);

% Plot y-z ellipse in east-up plane (left-handed system)
ind=[2 3];
[a,b,az]=errell2(C(ind,ind));
x=a*cos(t);
y=b*sin(t);
Rt=[cos(az) -sin(az); sin(az) cos(az)];
xx=xo*ones(size(t));
yy=yo+[x y]*Rt(:,1);
zz=zo+[x y]*Rt(:,2);
plot3(yy,xx,zz,ltype);
