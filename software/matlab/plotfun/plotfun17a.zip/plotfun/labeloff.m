function labeloff(labelh)
% LABELOFF  Removes labels defined by label handles labelh from
%   current plot by setting Visible property off.
% Version: 1996-01-21

% Version History
% 1996-01-21  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

nh = length(labelh);
for i=1:nh
  set(labelh,'Visible','off');
end
