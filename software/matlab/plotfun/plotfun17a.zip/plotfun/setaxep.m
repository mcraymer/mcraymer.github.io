function setaxep(pos)
% SETAXEP  Sets default axes position (left, bottom, width, height).
%   See also GETAXEP, SETAXES.
% Version: 1997-05-03
% Usage:   setaxep(pos)
% Input:   pos - new default axes position (normalized)
%                [left bottom width height]
% Output:  none

% Version History
% 1997-05-03  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<1
  error('Too few input arguments');
end

% Set new axes position
set(0,'DefaultAxesPosition',pos);
