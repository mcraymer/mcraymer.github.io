function pos=getaxep
% GETAXEP  Gets current axes position. See also SETAXEP, SETAXES.
% Version: 1997-09-28
% Usage:   pos=getfigp
% Input:   none
% Output:  pos - current figure position (pixels)
%                [left bottom width height]

% Version History
% 1997-09-28  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

%pos=get(gca,'Position');          %current axes only
pos=get(0,'DefaultAxesPosition');  %default axes
