function setaxes(size)
% SETAXES  Sets default axes size (width, height). See also GETAXEP,
%   SETAXEP.
% Version: 1997-05-03
% Usage:   setaxes(size)
% Input:   size - new default axes size (normalized)
%                 [width height]
% Output:  none

% Version History
% 1997-05-03  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<1
  error('Too few input arguments');
end

% Get current axes position
pos=get(0,'DefaultAxesPosition');

% Set new axes position
set(0,'DefaultAxesPosition',[pos(1) pos(2) size(1) size(2)]);
