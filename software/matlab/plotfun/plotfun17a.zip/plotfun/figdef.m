function figdef
% FIGDEF  Resets default figure position to startup values. See also
%   GETFIGP, SETFIGP, SETFIGS.
% Version: 1997-09-28
% Usage:   figdef

% Version History
% 1997-09-28  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

% Get computer type
cname=computer;

% Set the default figure position, in pixels.
% On small screens, make figure smaller, with same aspect ratio.

screen = get(0, 'ScreenSize');
width = screen(3);
height = screen(4);
if all(cname(1:2) == 'PC')           %PC SCREENS
   if height >= 500                  %large pc screens
      mwwidth = 560; mwheight = 420;
   else                              %small pc screens
      mwwidth = 500; mwheight = 375;
   end
   left = (width - mwwidth)/2;
   bottom = height - mwheight -60;
else                                 %OTHER SCREENS
   if height > 768                   %large other screens
      mwwidth = 560; mwheight = 420;
      left = (width-mwwidth)/2;
      bottom = height-mwheight-60;
   else                              %small other screens
      mwwidth = 512; mwheight = 384;
      left = (width-mwwidth);
      bottom = height-mwheight-50;
   end
end
set(0,'DefaultFigurePosition',[left bottom mwwidth mwheight]);
set(0,'DefaultAxesPosition',[0.1300 0.1100 0.7750 0.8150]);
set(0,'DefaultAxesFontName','Helvetica');
set(0,'DefaultAxesFontSize',12);
set(0,'DefaultTextFontName','Helvetica');
set(0,'DefaultTextFontSize',12);

