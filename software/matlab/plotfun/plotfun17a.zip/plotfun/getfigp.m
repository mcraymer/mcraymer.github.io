function pos=getfigp(h)
% GETFIGP  Gets default figure position. See also FIGDEF, SETFIGP,
%   SETFIGS.
% Version: 1997-09-28
% Usage:   pos=getfigp(h)
%          pos=getfigp
% Input:   h   - figure handle (optional, current assumed)
% Output:  pos - default figure position (pixels)
%                [left bottom width height]

% Version History
% 1997-09-28  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<1
  h=0;
end
pos=get(h,'DefaultFigurePosition');
