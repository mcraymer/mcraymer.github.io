function pltmenu(labelh)
% PLTMENU  Adds a menu for the current figure. Menu items include:
%     Grid On
%     Grid Off
%     Labels On   (optional)
%     Labels Off  (optional)
%     Zoom On
%     Zoom Off
%     Zoom Out
%   With zoom on, mouse click zooms in 2x, mouse shift-click zooms
%   out 2x, and mouse click-drag zooms to selected area. Zoom out
%   returns the figure to the initial state. See zoom.m for more
%   details.
% Version: 1996-12-01
% Useage:  pltmenu(labelh)
% Input:   labelh - optional handle for point labels (used
%                   only by 'Label On', 'Label Off')

% Version History
% 1996-12-01  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

f = uimenu('Label','Plot');
uimenu(f,'Label','Grid On','Callback','grid on');
uimenu(f,'Label','Grid Off','Callback','grid off');
if nargin==1
  uimenu(f,'Label','Labels On','Callback','labelon(labelh)');
  uimenu(f,'Label','Labels Off','Callback','labeloff(labelh)');
end
uimenu(f,'Label','Zoom On','Callback','zoom on');
uimenu(f,'Label','Zoom Off','Callback','zoom off');
uimenu(f,'Label','Zoom Out','Callback','zoom out');
