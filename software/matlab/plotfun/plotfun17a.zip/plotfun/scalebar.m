function scalebar(xo,yo,size,scale,c)
% SCALEBAR  Adds a scale bar to current plot at location x,y.
% Version: 1997-02-20
% Usage:   scalebar(xo,yo,size,scale,c)
% Input:   xo,yo - location (start) of bar on plot
%          size  - max size of bar (unscaled)
%          scale - scale factor for bar
%          c - bar colour (optional, default='w')
% Output:  none

% Version History
% 1997-02-20  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<4
  error('Too few input arguments');
elseif nargin==4
  if all(get(gcf,'Color')==[1 1 1]),
    c='k';
  else
    c='w';
  end
end

%ticlen=get(gca,'TickLength');
%ticlen=ticlen(1);
ltype=['-' c];
hold on;
plot([xo xo+size*scale],[yo yo],ltype);
text(xo,yo,'or');
text(xo+size*scale,yo,num2str(size));
%plot([xo xo],[yo yo+ticlen],ltype);
%plot([xo+size*scale xo+size*scale],[yo yo+ticlen],ltype);
%text(xo,yo+ticlen*2.5,'0');
%text(xo+size*scale,yo+ticlen*2.5,num2str(size));
hold off;
