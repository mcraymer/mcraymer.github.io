function setfigs(size)
% SETFIGS  Sets default figure size (width, height). See also FIGDEF,
%   GETFIGP, SETFIGP.
% Version: 1997-02-09
% Usage:   setfigs(size)
% Input:   size - new default figure size (pixels)
%                 [width height] - optional
%                 Default is startup default position
% Output:  none

% Version History
% 1997-02-09  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<1
  defigpos;
  return
end

% Get screen size
screen=get(0,'ScreenSize');
swidth=screen(3);
sheight=screen(4);

% Set new default figure position
nwidth=size(1);
nheight=size(2);
nleft=(swidth-nwidth)/2;
nbottom=sheight-nheight-60;
set(0,'DefaultFigurePosition',[nleft nbottom nwidth nheight]);
