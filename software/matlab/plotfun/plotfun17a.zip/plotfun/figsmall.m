function figsmall
% FIGSMALL  Sets default figure size so that 3 plots will fit on a
%   page with 6.5" wide margins.
% Version: 1997-05-02
% Usage:   figsmall

% Version History
% 1997-05-02  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

set(0,'DefaultFigurePosition',[109 210 430 170]);  % 17" monitor
%set(0,'DefaultFigurePosition',[109 175 430 170]); % 13" monitor
set(0,'DefaultAxesPosition',[0.09  0.20  0.85  0.70]);
set(0,'DefaultAxesFontName','Helvetica');
set(0,'DefaultAxesFontSize',10);
set(0,'DefaultTextFontName','Helvetica');
set(0,'DefaultTextFontSize',10);
