function labelon(labelh)
% LABELON  Adds labels defined by label handles labelh from current
%   plot by setting Visible property on.
% Version: 1996-01-21

% Version History
% 1996-01-21  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

nh = length(labelh);
for i=1:nh
  set(labelh,'Visible','on');
end
