function setfont(type,size)
% SETFONT  Sets default figure text and axes font and size. Default
%   is Helvetical 12 point.
% Version: 1997-06-24
% Usage:   setfont(type,size)
% Input:   type - font type (string) - optional
%                 Default = 'Helvetica'
%          size - font size (pixels) - optional
%                 Default = 12 point
% Output:  none

% Version History
% 1997-06-24  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin==0
  type='Helvetica';
  size=12;
elseif nargin==1
  if isstring(type)
    size=12;
  else
    size=type;
    type='Helvetica';
  end
end

set(0,'DefaultAxesFontName',type);
set(0,'DefaultAxesFontSize',size);
set(0,'DefaultTextFontName',type);
set(0,'DefaultTextFontSize',size);
