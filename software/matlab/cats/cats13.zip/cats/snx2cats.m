function snx2cats(filespec,scode,rframe,cfile,log)
% SNX2CATS  Reads SINEX files and comptues NEU coordinates and st.dev. of a
%   site wrt initial position and writes to CATS time series file. Requires
%   GHOST Toolbox function rdsinex and Geodetic Toolbox functions doy2jd &
%   jd2yr (used by rdsinex). Uses GRS80 reference ellipsoid (hard-coded).
% Version: 2013-04-20
% Usage:   snx2cats  (prompts for input)
%          snx2cats(filespec,scode,rframe)
%          snx2cats(filespec,scode,rframe,cfile)
%          snx2cats(filespec,scode,rframe,cfile,log)
% Input:   filespec - filespec for SINEX files
%          scode    - site code (4 char)
%          rframe   - reference frame
%          cfile    - file name of output CATS file (default = scode.neu)
%          log      - flag to output status info (0=no=default, >0=yes)
% Output:  CATS time series file

% Version History
% 2010-03-20  Initial version.
% 2010-11-10  Get reference frame from user and output in header.
%             Output "Reference Position" comment in header.
% 2010-12-11  Corrected usage info in header.
% 2011-03-29  Assigned 0.00005 standard deviation to sn, se, su if less
%             than 0.00005 to avoid round off to 0.0000 in output neu file.
% 2013-04-20  Output CATS files even if only one epoch.
%             Changed order of input arguments to always require rframe input.
%			  Added/modified user messages.

[a,b,e2,finv]=refell('grs80');

% Get user input if not specified
if nargin==0
  filespec=input('Enter file specification w/ wildcards > ','s');
  scode=input('Enter 4-char site code > ','s');
  rframe=input('Enter reference frame > ','s');
  cfile=input(['Enter output CATS file [' scode '.neu] > '],'s');
  if isempty(cfile)
    cfile=[scode '.neu'];
  end
  log=input(['Output more info (0=no, 1=yes) [0] >']);
  if isempty(log)
    log=0;
  end
end
if nargin==3
  cfile=[scode '.neu'];
  log=0;
end
if nargin==4
  log=0;
end
if nargin~=0 & nargin~=3 & nargin~=4 & nargin~=5
  error('Incorrect number of input arguments');
end

scode=upper(scode);
ind=strfind(filespec,'/');
if isempty(ind)
  path=[];
else
  path=filespec(1:ind(length(ind)));
end
d=dir(filespec);
nfiles=length(d);

% Echo input settings & list SINEX files
if log
  disp(['Filespec: ' filespec]);
  disp(['Site code: ' scode]);
  disp(['Output CATS file: ' cfile]);
  disp(['Reference Frame: ' rframe]);
  if nfiles>0
    disp(' ');
    disp('Input SINEX files:');
    dir(filespec)
    disp([num2str(nfiles) ' SINEX files found']);
  else
    disp([num2str(nfiles) ' SINEX files found']);
  end
end
if nfiles==0
  disp(' ');
  disp('*** Warning: No SINEX files found with specified filespec');
  return
end

% Read XYZ from each SINEX file & find site ID
nt=0;
for i=1:nfiles
  sfile=d(i).name;
  sfile=[path sfile];
  %disp(['Reading SINEX file ' sfile]);
  [site,point,soln,epoch,X,Y,Z,C]=rdsnx(sfile);
  ind=strcmp(scode,cellstr(upper(site)));
  is=find(ind);
  if is
    disp(['Found station ' scode ' in ' sfile]);
    if length(is)>1
      disp('*** Warning: More than one solution found; taking first one');
      is=is(1);
    end
    nt=nt+1;
    yr(nt)=epoch(is);
    Xs(nt)=X(is);
    Ys(nt)=Y(is);
    Zs(nt)=Z(is);
    indc=(is-1)*3+[1:3];
    Cs(:,:,nt)=C(indc,indc);
  end
end
if log
  disp(['Number of epochs found: ' num2str(nt)]);
end

% Compute NEU coordinates
for i=1:nt
  [yr ind]=sort(yr);  % Sort by epoch
  Xs=Xs(ind);
  Ys=Ys(ind);
  Zs=Zs(ind);
  Cs=Cs(:,:,ind);
  if i==1
    X1=Xs(i);
    Y1=Ys(i);
    Z1=Zs(i);
    [lat1,lon1,h1]=xyz2ell(X1,Y1,Z1,a,e2);
  end
  %[lat,lon,h]=xyz2ell(Xs(i),Ys(i),Zs(i),a,e2);
  [n(i),e(i),u(i)]=ct2lg(Xs(i)-X1,Ys(i)-Y1,Zs(i)-Z1,lat1,lon1);
  Cneu=cct2clg(Cs(:,:,i),lat1,lon1);
  sn(i)=sqrt(Cneu(1,1));
  se(i)=sqrt(Cneu(2,2));
  su(i)=sqrt(Cneu(3,3));
  if sn(i)<0.00005
    sn(i)=0.00005;
  end
  if se(i)<0.00005
    se(i)=0.00005;
  end
  if su(i)<0.00005
    su(i)=0.00005;
  end
end

% Write CATS file
if nt>=1
  if log
    disp(' ');
    disp(['Writing output CATS file ' cfile ' (' num2str(nt) ' epochs)...']);
  end
  fid=fopen(cfile,'w');
  fprintf(fid,'# Site: %s\n',scode);
  fprintf(fid,'# Reference Position:\n');
  fprintf(fid,'# X (m): %10.4f\n',X1);
  fprintf(fid,'# Y (m): %10.4f\n',Y1);
  fprintf(fid,'# Z (m): %10.4f\n',Z1);
  fprintf(fid,'# Latitude  (deg): %11.7f\n',rad2deg(lat1));
  fprintf(fid,'# Longitude (deg): %11.7f\n',rad2deg(lon1));
  fprintf(fid,'# Height      (m): %11.4f\n',h1);
  fprintf(fid,'# Reference Frame: %s\n',rframe);
  fprintf(fid,'# offset \n');
  for i=1:nt
    fprintf(fid,'%9.4f %10.4f %10.4f %10.4f %8.4f %8.4f %8.4f\n',...
            yr(i),n(i),e(i),u(i),sn(i),se(i),su(i));
  end
  fclose(fid);
else
  disp(' ');
  disp(['*** Warning: ' scode ' not found in any epochs; no CATS file generated']);
end
