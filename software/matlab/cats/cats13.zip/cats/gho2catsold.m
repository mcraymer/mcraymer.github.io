function gho2catsold(filespec,scode,cfile,rframe)
% GHO2CATS  Reads GHOST files and comptues NEU coordinates and st.dev. of a
%   site wrt initial position and writes to CATS time series file. Requires
%   GHOST Toolbox function rdwsa and Geodetic Toolbox functions doy2jd &
%   jd2yr (used by rdsinex). Uses GRS80 reference ellipsoid (hard-coded).
%   *** OLD VERSION *** Uses rdwsaold with epoch in columns 8-15 of header record.
% Version: 2010-11-18
% Usage:   gho2cats  (prompts for input)
%          gho2cats(filespec,scode)
%          gho2cats(filespec,scode,cfile)
%          gho2cats(filespec,scode,cfile,rframe)
% Input:   filespec - filespec for GHOST files
%          scode    - site code (4 char)
%          cfile    - file name of output CATS file (default = scode.neu)
%          rframe   - reference frame (default = ITRF2005)
% Output:  CATS time series file

% Version History
% 2010-11-18  Initial version based on snx2cats.

[a,b,e2,finv]=refell('grs80');

% Get user input if not specified
if nargin==0
  filespec=input('Enter GHOST WSA filespec w/ wildcards > ','s');
  scode=input('Enter site code (4-char) > ','s');
  cfile=input(['Enter output CATS file [' scode '.neu] > '],'s');
  if isempty(cfile)
    cfile=[scode '.neu'];
  end
  rframe=input('Enter reference frame [ITRF2005] > ','s');
  if isempty(rframe)
    rframe='ITRF2005';
  end
end
if nargin==2
  cfile=[scode '.neu'];
  rframe='ITRF2005';
end
if nargin==3
  rframe='ITRF2005';
end
if nargin~=0 & nargin~=2 & nargin~=3 & nargin~=4
  error('Incorrect number of input arguments');
end

scode=upper(scode);
ind=strfind(filespec,'/');
if isempty(ind)
  path=[];
else
  path=filespec(1:ind(length(ind)));
end
d=dir(filespec);
nfiles=length(d);
rframe=upper(rframe);

% Echo input settings & list GHOST WSA files
disp(' ');
disp(['Filespec: ' filespec]);
disp(['Site code: ' scode]);
disp(['Output CATS file: ' cfile]);
disp(['Reference Frame: ' rframe]);
if nfiles>0
  disp(' ');
  disp('Input GHOST WSA files:');
  dir(filespec)
  disp([num2str(nfiles) ' GHOST WSA files found']);
else
  disp([num2str(nfiles) ' GHOST WSA files found']);
end
if nfiles==0
  return
end

% Read PLH from each GHOST file for site ID
nt=0;
disp(' ');
for i=1:nfiles
  gfile=d(i).name;
  gfile=[path gfile];
  %disp(['Reading GHOST WSA file ' gfile]);
  [site,lat,lon,h,C,epoch]=rdwsaold(gfile);
  if isempty(epoch)
    str=['No epoch found in file ' gfile];
    error(str);
  end
  is=strmatch(scode,upper(site(:,10:13)));
  if is
    disp(['Site found in file ' gfile ', epoch ' num2str(epoch)]);
    if length(is)>1
      disp('*** Warning: More than one solution found; using first one');
      is=is(1);
    end
    nt=nt+1;
    yr(nt)=epoch;
    lats(nt)=lat(is);
    lons(nt)=lon(is);
    hs(nt)=h(is);
    indc=(is-1)*3+[1:3];
    Cs(:,:,nt)=C(indc,indc);
  else
    disp(['Site not found in file ',gfile]);
  end
end

% Sort by epoch
[yr ind]=sort(yr);  % Sort by epoch
lats=lats(ind);
lons=lons(ind);
hs=hs(ind);
Cs=Cs(:,:,ind);

% Compute reference coordinates
lat1=lats(1);
lon1=lons(1);
h1=hs(1);
[X1,Y1,Z1]=ell2xyz(lat1,lon1,h1,a,e2);

% Compute NEU coordinates
for i=1:nt
  dlat=lats(i)-lat1;
  dlon=lons(i)-lon1;
  [n(i),e(i)]=dg2lg(dlat,dlon,lat1,h1,a,e2);
  u(i)=hs(i)-h1;
  Cneu=Cs(:,:,i);
  sn(i)=sqrt(Cneu(1,1));
  se(i)=sqrt(Cneu(2,2));
  su(i)=sqrt(Cneu(3,3));
end

% Write CATS file
if nt>1
  disp(' ');
  disp(['Writing output CATS file ' cfile ' (' num2str(nt) ' epochs)...']);
  fid=fopen(cfile,'w');
  fprintf(fid,'# Site: %s\n',scode);
  fprintf(fid,'# Station Number/Name: %s\n',site(is,:));
  fprintf(fid,'# Reference Position:\n');
  fprintf(fid,'# X (m): %10.4f\n',X1);
  fprintf(fid,'# Y (m): %10.4f\n',Y1);
  fprintf(fid,'# Z (m): %10.4f\n',Z1);
  fprintf(fid,'# Latitude  (deg): %11.7f\n',rad2deg(lat1));
  fprintf(fid,'# Longitude (deg): %11.7f\n',rad2deg(lon1));
  fprintf(fid,'# Height      (m): %11.4f\n',h1);
  fprintf(fid,'# Reference Frame: %s\n',rframe);
  fprintf(fid,'# offset \n');
  fprintf(fid,'#  Year      North(m)    East(m)     Up(m)    Std_N    Std_E    Std_U\n');
  for i=1:nt
    fprintf(fid,'%9.3f %10.4f %10.4f %10.4f %8.4f %8.4f %8.4f\n',...
            yr(i),n(i),e(i),u(i),sn(i),se(i),su(i));
  end
  fclose(fid);
elseif nt==1
  disp(' ');
  disp('No CATS file created (site in only one epoch)');
else
  disp(' ');
  disp('No CATS file created (site not in any epochs)');
end
