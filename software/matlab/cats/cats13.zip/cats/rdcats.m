function [site,t,n,e,u,sn,se,su,toff,lat,lon,h,x,y,z]=rdcats(cfile)
% RDCATS  Reads CATS time series file of NEU coordinates.
% Version: 2010-11-10
% Usage:   [site,t,n,e,u,sn,se,su,toff,lat,lon,h,x,y,z]=rdcats(cfile)
% Input:   cfile - CATS time series file name
% Output:  site  - site code (4 char)
%          t     - vector of coordinate epochs (year)
%          n     - vector of north coordinates wrt reference position
%          e     - vector of east coordinates wrt reference position
%          u     - vector of up coordinates wrt reference position
%          sn    - vector of north coordinate stds wrt reference position
%          se    - vector of east coordinate stds wrt reference position
%          su    - vector of up coordinate stds wrt reference position
%          toff  - array of offset data; col 1 = decimal year, col 2 = offset
%                  code (sum of 4 for north, 2 for east & 1 for vertical, 7
%                  = all, 0 = omit) - first offset always at start of time
%                  series
%          lat   - latitude of reference position (deg)
%          lon   - longitude of reference position (deg)
%          h     - ellipsoidal height of reference position (m)
%          x     - geocentric Cartesian x coordinate of reference position (m)
%                  (optional)
%          y     - geocentric Cartesian y coordinate of reference position (m)
%                  (optional)
%          z     - geocentric Cartesian z coordinate of reference position (m)
%                  (optional)

% Version History
% 2010-03-25  Initial version.
% 2010-04-06  Added reading of offsets.
% 2010-05-05  Modified toff to always include 1st offset at start of
%             time series.
% 2010-11-10  Modified to read arbitrary number of header/comment
%             records.

if nargin~=1
  error('Incorrect number of input arguments');
end
if nargout~=12 & nargout~=15
  error('Incorrect number of output arguments');
end

%----- Initialize variables

toff=[0 7];  % epoch of offsets (initial one at start of series for all components)
noff=size(toff);
noff=length(toff(:,1));   % number of offsets

%----- Open CATS file

fid=fopen(cfile,'r');
if fid<0
  error('*** Error: File not found');
end

%----- Read header/comment lines (lines beginning with #)

nhead=0;
while (1)
  rec=fgetl(fid);
  if rec(1:1)~='#'
    break;
  end
  nhead=nhead+1;

  if findstr('site',lower(rec))
    ind=findstr(' ',rec);
    site=rec(ind(length(ind))+1:length(rec));

  elseif findstr('x',lower(rec))
    ind=findstr(' ',rec);
    x=sscanf( rec(ind(length(ind)):length(rec)),'%f');

  elseif findstr('y',lower(rec))
    ind=findstr(' ',rec);
    y=sscanf( rec(ind(length(ind)):length(rec)),'%f');

  elseif findstr('z',lower(rec))
    ind=findstr(' ',rec);
    z=sscanf( rec(ind(length(ind)):length(rec)),'%f');

  elseif findstr('latitude',lower(rec))
    ind=findstr(' ',rec);
    latdeg=sscanf( rec(ind(length(ind)):length(rec)),'%f');
    lat=deg2rad(latdeg);

  elseif findstr('longitude',lower(rec))
    ind=findstr(' ',rec);
    londeg=sscanf( rec(ind(length(ind)):length(rec)),'%f');
    lon=deg2rad(londeg);

  elseif findstr('height',lower(rec))
    ind=findstr(' ',rec);
    h=sscanf( rec(ind(length(ind)):length(rec)),'%f');

  elseif findstr('offset',lower(rec))
    %toff=[];
    if length(rec)>findstr('offset',lower(rec))+5
      ind=findstr('offset',rec)+6;
      off=sscanf( rec(ind:length(rec)),'%f %f'); % decimal year and component code of offset
      if isempty(off)
        %disp('Empty offset record found - ignoring');
      else
        if off(2)~=0
          noff=noff+1;
          toff(noff,1)=off(1);
          toff(noff,2)=off(2);
        end
      end
    end
  end % if
end % while

%----- Read data

A=importdata(cfile,' ',nhead);
t=A.data(:,1);
n=A.data(:,2);
e=A.data(:,3);
u=A.data(:,4);
if length(A.data(1,:))==7
  sn=A.data(:,5);
  se=A.data(:,6);
  su=A.data(:,7);
end
toff(1,1)=t(1);  % reset time of intial offset to start of time series instead of 0
