function [t,n,e,u,sn,se,su,toff]=pltcats(cfile,lines)
% PLTCATS  Reads and plots CATS time series file of NEU coordinates.
%   Requires CATS Toolbox function rdcats and Plot Toolbox functions
%   pltell & pltell3.
% Version: 2010-12-11
% Usage:   [t,n,e,u,sn,se,su,toff]=pltcats(cfile)
%          [t,n,e,u,sn,se,su,toff]=pltcats(cfile,'lines')
% Input:   cfile - CATS time series file name
%          lines - optional flog to plot lines between points (0 =
%                  'no lines' = no lines, else = lines = default)
% Output:  PDF files of plots of NEU coordinates, including:
%            <site_n.pdf>  - plot of north time series
%            <site_e.pdf>  - plot of east time series
%            <site_u.pdf>  - plot of up (vertical) time series
%            <site_hz.pdf> - plot of horizontal time series
%            <site_hv.pdf> - plot of horizontal & vertical time series
%            <site_3d.pdf> - plot of 3D time series

% Version History
% 2010-03-25  Initial version based on rdcats.
% 2010-04-06  Used rdcats to read CATS file.
% 2010-05-05  Do not plot first offset (always at start of series).
% 2010-11-10  Added default option to plot lines between points.
% 2010-11-12  Add 3D time series plot.
% 2010-12-11  Correct plotting offset for north time series.
%             Enabled computing and plotting linear trends with
%             multiple offsets using lreg2.
%             Output rms of residual time series.
%			  Corrected test for more than 1 epoch for linear trend
%			  (added nt variable).
% 2013-04-20  Corrected test for single epoch to avoid computing/plotting
%			  linear trend.

if nargin~=1 & nargin~=2
  error('Incorrect number of input arguments');
end
if nargin==1
  lines=1;
end
if nargin==2
  if lines
    if strcmp(lower(lines),'nolines') | strcmp(lower(lines),'no lines')
      lines=0;
    else
      lines=1;
    end
  end
end

%----- Read CATS file

[fpath,fname,fext]=fileparts(cfile);
[site,t,n,e,u,sn,se,su,toff,lat,lon,h,x,y,z]=rdcats(cfile);
n=n*1000;    % Convert units from meters to mm
e=e*1000;
u=u*1000;
sn=sn*1000;
se=se*1000;
su=su*1000;
nt=length(n);

%----- Linear trends for each component

if nt>1
  [bn,Cbn,vfn,rn]=lreg2(t,n,toff(:,1),diag(sn.^2));
  nbn=length(bn);
  nrms=rms(rn);
  fprintf('North Velocity = %5.1f +/- %4.1f   rms = %4.1f  (mm/y)\n',bn(nbn),sqrt(Cbn(nbn,nbn)*vfn),nrms);
  [be,Cbe,vfe,re]=lreg2(t,e,toff(:,1),diag(se.^2));
  nbe=length(be);
  erms=rms(re);
  fprintf('East Velocity  = %5.1f +/- %4.1f   rms = %4.1f  (mm/y)\n',be(nbe),sqrt(Cbe(nbe,nbe)*vfe),erms);
  [bu,Cbu,vfu,ru]=lreg2(t,u,toff(:,1),diag(su.^2));
  nbu=length(bu);
  urms=rms(ru);
  fprintf('Vert Velocity  = %5.1f +/- %4.1f   rms = %4.1f  (mm/y)\n',bu(nbu),sqrt(Cbu(nbu,nbu)*vfu),urms);
end

%----- Plot north time series

close all;

figure;
if lines
  plot(t,n,'+b-');
  %errorbar(t,n,sn,-sn,'ob-');
else
  plot(t,n,'+b');
  %errorbar(t,e,sn,-sn,'ob');
end
hold on;
if nt>1
  %plot(t,bn(1)+bn(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
xlabel('Year');
ylabel('North mm');
title([upper(site) ' Time Series']);
ax=axis;
dx=(ax(2)-ax(1))/30;
dy=(ax(4)-ax(3))/20;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f  rms = %4.1f (mm/y)',bn(nbn),sqrt(Cbn(nbn,nbn)*vfn),nrms);
  text(ax(1)+dx,ax(3)+dy,s);
end

pfile=[fname '_n.pdf'];
orient landscape;
print('-dpdf',pfile);

%----- Plot east time series

figure;
if lines
  plot(t,e,'+b-');
  %errorbar(t,e,se,-se,'ob-');
else
  plot(t,e,'+b');
  %errorbar(t,e,se,-se,'ob');
end
hold on;
if nt>1
  %plot(t,be(1)+be(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
xlabel('Year');
ylabel('East (mm)');
title([upper(site) ' Time Series']);
ax=axis;
dx=(ax(2)-ax(1))/30;
dy=(ax(4)-ax(3))/20;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f  rms = %4.1f (mm/y)',be(nbe),sqrt(Cbe(nbe,nbe)*vfe),erms);
  text(ax(1)+dx,ax(3)+dy,s);
end

pfile=[fname '_e.pdf'];
orient landscape;
print('-dpdf',pfile);

%----- Plot up (vertical) time series

figure;
if lines
  plot(t,u,'+b-');
  %errorbar(t,u,su,-su,'ob-');
else
  plot(t,u,'+b');
  %errorbar(t,u,su,-su,'ob');
end
hold on;
if nt>1
  %plot(t,bu(1)+bu(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
xlabel('Year');
ylabel('Height (mm)');
title([upper(site) ' Time Series']);
ax=axis;
dx=(ax(2)-ax(1))/30;
dy=(ax(4)-ax(3))/20;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f  rms = %4.1f (mm/y)',bu(nbu),sqrt(Cbu(nbu,nbu)*vfu),urms);
  text(ax(1)+dx,ax(3)+dy,s);
end

pfile=[fname '_u.pdf'];
orient landscape;
print('-dpdf',pfile);

%----- Plot north, east, up time series on same page

figure;
subplot(3,1,1);
if lines
  plot(t,n,'+b-');
  %errorbar(t,n,sn,-sn,'ob-');
else
  plot(t,n,'+b');
  %errorbar(t,n,sn,-sn,'ob');
end
hold on;
if nt>1
  %plot(t,bn(1)+bn(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
ylabel('North (mm)');
title([upper(site) ' Time Series']);
ax=axis;
dx=(ax(2)-ax(1))/40;
dy=(ax(4)-ax(3))/5;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f  rms = %4.1f (mm/y)',bn(nbn),sqrt(Cbn(nbn,nbn)*vfn),nrms);
  %text(ax(1)+dx,ax(3)+dy,s);
end

subplot(3,1,2);
if lines
  plot(t,e,'+b-');
  %errorbar(t,e,se,-se,'ob-');
else
  plot(t,e,'+b');
  %errorbar(t,e,se,-se,'ob');
end
hold on;
if nt>1
  %plot(t,be(1)+be(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
ylabel('East (mm)');
ax=axis;
dx=(ax(2)-ax(1))/40;
dy=(ax(4)-ax(3))/10;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f  rms = %4.1f (mm/y)',be(nbe),sqrt(Cbe(nbe,nbe)*vfe),erms);
  %text(ax(1)+dx,ax(3)+dy,s);
end

subplot(3,1,3);
if lines
  plot(t,u,'+b-');
  %errorbar(t,u,su,-su,'ob-');
else
  plot(t,u,'+b');
  %errorbar(t,u,su,-su,'ob');
end
hold on;
if nt>1
  %plot(t,bu(1)+bu(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
ylabel('Height (mm)');
xlabel('Year');
ax=axis;
dx=(ax(2)-ax(1))/40;
dy=(ax(4)-ax(3))/5;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f  rms = %4.1f (mm/y)',bu(nbu),sqrt(Cbu(nbu,nbu)*vfu),urms);
  %text(ax(1)+dx,ax(3)+dy,s);
end

pfile=[fname '_neu.pdf'];
orient portrait;
print('-dpdf',pfile);

return

%----- Plot horizontal time series

figure
if lines
  plot(e,n,'+b-');
else
  plot(n,e,'+b');
end
hold on;
offset=0.5;
for i=1:length(n)
    pltell(n(i),e(i),sn(i),se(i),0,1);
    text(e(i)+offset,n(i)+offset,num2str(t(i)));
end
hold off;
axis equal;
grid;
xlabel('East (mm)');
ylabel('North (mm)');
title([upper(site) ' Time Series']);

pfile=[fname '_hz.pdf'];
orient landscape;
print('-dpdf',pfile);

%----- Plot horizontal & vertical time series on same page

figure
subplot(3,1,[1 2]);
%subplot(5,1,[1 2 3]);
if lines
  plot(e,n,'+b-');
else
  plot(n,e,'+b');
end
hold on;
offset=0.5;
for i=1:length(n)
    pltell(n(i),e(i),sn(i),se(i),0,1);
    text(e(i)+offset,n(i)+offset,num2str(t(i)));
end
hold off;
axis equal;
grid;
xlabel('East (mm)');
ylabel('North (mm)');
title([upper(site) ' Time Series']);

subplot(3,1,3);
%subplot(5,1,[4 5]);
if lines
  %plot(t,u,'ob-');
  errorbar(t,u,su,-su,'ob-');
else
  %plot(t,u,'ob');
  errorbar(t,u,su,-su,'ob');
end
hold on;
if nt>1
  %plot(t,bu(1)+bu(2)*t,'-r');  % plot linear trend
end
ax=axis;
for i=1:nrows(toff)-1
  plot([toff(i+1,1);toff(i+1,1)],[ax(3);ax(4)],'-r');
end
hold off;
grid;
ylabel('Height (mm)');
xlabel('Year');
ax=axis;
dx=(ax(2)-ax(1))/40;
dy=(ax(4)-ax(3))/5;
if nt>1
  s=sprintf('Velocity = %5.1f +/- %4.1f (mm/y)',bu(nbu),sqrt(Cbu(nbu,nbu)*vfu));
  text(ax(1)+dx,ax(3)+dy,s);
end

pfile=[fname '_hv.pdf'];
orient portrait;
print('-dpdf',pfile);

%----- Plot 3D neu time series

figure
if lines
  plot3(e,n,u,'+b-');
else
  plot3(n,e,u,'+b');
end
hold on;
offset=0.5;
for i=1:length(n)
  C=diag([sn(i);se(i);su(i)].^2);
  pltell3(n(i),e(i),u(i),C,'b-');
  text(e(i),n(i),u(i)+offset,num2str(t(i)));
end
hold off;
axis equal;
grid;
xlabel('East (mm)');
ylabel('North (mm)');
zlabel('Height (mm)');
title([upper(site) ' Time Series']);

pfile=[fname '_3d.pdf'];
orient portrait;
print('-dpdf',pfile);
