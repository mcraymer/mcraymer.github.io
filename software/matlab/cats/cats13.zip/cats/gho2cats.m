function gho2cats(filespec,scode,rframe,cfile,log)
% GHO2CATS  Reads GHOST files and comptues NEU coordinates and st.dev. of a
%   site wrt initial position and writes to CATS time series file. Requires
%   GHOST Toolbox function rdwsa and Geodetic Toolbox functions doy2jd &
%   jd2yr (used by rdsinex). Uses GRS80 reference ellipsoid (hard-coded).
% Version: 2013-04-20
% Usage:   gho2cats  (prompts for input)
%          gho2cats(filespec,scode,rframe)
%          gho2cats(filespec,scode,rframe,cfile)
%          gho2cats(filespec,scode,rframe,cfile,log)
% Input:   filespec - filespec for GHOST files
%          scode    - site code (4 char)
%          rframe   - reference frame
%          cfile    - file name of output CATS file (default = scode.neu)
%          log      - flag to output status info (0=no=default, >0=yes)
% Output:  CATS time series file

% Version History
% 2010-11-18  Initial version based on snx2cats.
% 2013-04-20  Output CATS files even if only one epoch.
%             Changed order of input arguments to always require rframe input.
%			  Added/modified user messages.

[a,b,e2,finv]=refell('grs80');

% Get user input if not specified
if nargin==0
  filespec=input('Enter GHOST WSA filespec w/ wildcards > ','s');
  scode=input('Enter site code (4-char) > ','s');
  rframe=input('Enter reference frame > ','s');
  cfile=input(['Enter output CATS file [' scode '.neu] > '],'s');
  if isempty(cfile)
    cfile=[scode '.neu'];
  end
  log=input(['Output more info (0=no, 1=yes) [0] >']);
  if isempty(log)
    log=0;
  end
end
if nargin==3
  cfile=[scode '.neu'];
  log=0;
end
if nargin==4
  log=0;
end
if nargin~=0 & nargin~=3 & nargin~=4 & nargin~=5
  error('Incorrect number of input arguments');
end

scode=upper(scode);
ind=strfind(filespec,'/');
if isempty(ind)
  path=[];
else
  path=filespec(1:ind(length(ind)));
end
d=dir(filespec);
nfiles=length(d);
rframe=upper(rframe);

% Echo input settings & list GHOST WSA files
if log
  disp(['Filespec: ' filespec]);
  disp(['Site code: ' scode]);
  disp(['Output GHOST file: ' cfile]);
  disp(['Reference Frame: ' rframe]);
  if nfiles>0
    disp(' ');
    disp('Input SINEX files:');
    dir(filespec)
    disp([num2str(nfiles) ' GHOST files found']);
  else
    disp([num2str(nfiles) ' GHOST files found']);
  end
end
if nfiles==0
  disp(' ');
  disp('*** Warning: No GHOST files found with specified filespec');
  return
end

% Read PLH from each GHOST file for site ID
nt=0;
disp(' ');
for i=1:nfiles
  gfile=d(i).name;
  gfile=[path gfile];
  %disp(['Reading GHOST WSA file ' gfile]);
  [site,lat,lon,h,C,epoch]=rdwsa(gfile);
  if isempty(epoch)
    str=['No epoch found in file ' gfile];
    error(str);
  end
  is=strmatch(scode,upper(site(:,10:13)));
  if is
    disp(['Site found in file ' gfile ', epoch ' num2str(epoch)]);
    if length(is)>1
      disp('*** Warning: More than one solution found; using first one');
      is=is(1);
    end
    nt=nt+1;
    yr(nt)=epoch;
    lats(nt)=lat(is);
    lons(nt)=lon(is);
    hs(nt)=h(is);
    indc=(is-1)*3+[1:3];
    Cs(:,:,nt)=C(indc,indc);
  end
end
if log
  disp(['Number of epochs found: ' num2str(nt)]);
end

% Sort by epoch
[yr ind]=sort(yr);  % Sort by epoch
lats=lats(ind);
lons=lons(ind);
hs=hs(ind);
Cs=Cs(:,:,ind);

% Compute reference coordinates
lat1=lats(1);
lon1=lons(1);
h1=hs(1);
[X1,Y1,Z1]=ell2xyz(lat1,lon1,h1,a,e2);

% Compute NEU coordinates
for i=1:nt
  dlat=lats(i)-lat1;
  dlon=lons(i)-lon1;
  [n(i),e(i)]=dg2lg(dlat,dlon,lat1,h1,a,e2);
  u(i)=hs(i)-h1;
  Cneu=Cs(:,:,i);
  sn(i)=sqrt(Cneu(1,1));
  se(i)=sqrt(Cneu(2,2));
  su(i)=sqrt(Cneu(3,3));
end

% Write CATS file
if nt>=1
  disp(' ');
  disp(['Writing output CATS file ' cfile ' (' num2str(nt) ' epochs)...']);
  fid=fopen(cfile,'w');
  fprintf(fid,'# Site: %s\n',scode);
  fprintf(fid,'# Station Number/Name: %s\n',site(is,:));
  fprintf(fid,'# Reference Position:\n');
  fprintf(fid,'# X (m): %10.4f\n',X1);
  fprintf(fid,'# Y (m): %10.4f\n',Y1);
  fprintf(fid,'# Z (m): %10.4f\n',Z1);
  fprintf(fid,'# Latitude  (deg): %11.7f\n',rad2deg(lat1));
  fprintf(fid,'# Longitude (deg): %11.7f\n',rad2deg(lon1));
  fprintf(fid,'# Height      (m): %11.4f\n',h1);
  fprintf(fid,'# Reference Frame: %s\n',rframe);
  fprintf(fid,'# offset \n');
  fprintf(fid,'#  Year      North(m)    East(m)     Up(m)    Std_N    Std_E    Std_U\n');
  for i=1:nt
    fprintf(fid,'%9.3f %10.4f %10.4f %10.4f %8.4f %8.4f %8.4f\n',...
            yr(i),n(i),e(i),u(i),sn(i),se(i),su(i));
  end
  fclose(fid);
else
  disp(' ');
  disp(['*** Warning: ' scode ' not found in any epochs; no CATS file generated']);
end
