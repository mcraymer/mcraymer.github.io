% SNX2MAT  Reads XYZ coordinates and cov matrix from SINEX file and
%   writes to MATLAB .mat file.
% Version: 2010-03-20
% Usage:   snx2mat  (prompts for input & output)
% Input:   SINEX file name
%          Reference frame & epoch (metadata only)
%          Scale factor to rescale cov matrix (optional)
% Output:  MATLAB .mat file containing the following variables:
%            sname - array of station names (21 chars max)
%            XYZ   - array of geocentric XYZ coordinates
%            C     - covariance matrix in geocentric XYZ (only if matrix
%                    present in SINEX file)

% Version History
% 2000-10-23  Added error traps for opening i/o files.
%             Added automatic detection of velocity estimates.
% 2006-10-22  Added error traps for reading beyond end of file.
%             Added warning if no cov matrix found.
% 2008-06-04  Added check for solution type S on header record.
% 2010-03-20  Cleaned up header comments & removed program banner
%             output (use help snx2mat for info).
%             Added to SINEX Utilities Toolbox.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

clear all

%----- Open file

while (1)
  ifile=input('Enter SINEX file name > ','s');
  if isempty(ifile)
    return
  end
  fid=fopen(ifile,'r');
  if fid<0
    disp('*** Error: File not found');
  else
    break;
  end
end

%----- Read number of coordinates

rec = fgetl(fid);
n = sscanf(rec(61:65),'%d');   % number parameters
if ~isempty(findstr(rec(68:length(rec)),'X')) | ~isempty(findstr(rec(68:length(rec)),'S'))    % check for coordinate estimates
  if isempty(findstr(rec(68:length(rec)),'V')) & ~isempty(findstr(rec(68:length(rec)),'S'))   % check for velocity estimates
    ns=n/3;  % number of stations w/o velocity estimates
  else
    ns=n/6;  % number of stations with velocity estimates
  end
else
  error('No coordinate solution type X or S found on SINEX header record');
end
disp(' ');
disp(['Number of parameters: ' num2str(n)]);
disp(['Number of stations: ' num2str(ns)]);

%----- Find estimated coordinates

while (1)
  if (length(rec) >= 18)
    if (rec(1:18) == '+SOLUTION/ESTIMATE')
      break;
    end
  end
  rec = fgetl(fid);
  if ~ischar(rec)
    error('No SOLUTION/ESTIMATE data block found');
  end
end

%----- Read station codes and coordinates

disp('Reading station codes and coordinates in snx file...');
is = 0;
indx = zeros(3,ns);
scode = zeros(ns,4);
XYZ = zeros(ns,3);
fgetl(fid);  %skip header

rec = fgetl(fid);  %get first station
while (rec(1) ~= '-')

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAX')
      is = is+1;
      indx(1,is) = sscanf(rec(1:6),'%d');
      scode(is,:) = sscanf(rec(15:18),'%s');
      XYZ(is,1) = sscanf(rec(48:68),'%f');
      rec = fgetl(fid);
      break;
    else
      rec = fgetl(fid);
    end
  end
  if (rec(1) == '-')
    break;
  end

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAY')
      indx(2,is) = sscanf(rec(1:6),'%d');
      XYZ(is,2) = sscanf(rec(48:68),'%f');
      rec = fgetl(fid);
      break;
    else
      rec = fgetl(fid);
    end
  end
  if (rec(1) == '-')
    break;
  end

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAZ')
      indx(3,is) = sscanf(rec(1:6),'%d');
      XYZ(is,3) = sscanf(rec(48:68),'%f');
      rec = fgetl(fid);
      disp([scode(is,:) ':' int2str(is) ':' int2str(indx(1,is)) ',' int2str(indx(2,is)) ',' int2str(indx(3,is))]);
      break;
    else
      rec = fgetl(fid);
    end
  end
end
ns = is;
indx = indx(:,1:ns);
scode = char(scode(1:ns,:));
XYZ = XYZ(1:ns,:);
disp([int2str(ns) ' stations found in snx file']);

%----- Find estimated covariance matrix

while (1)
  if (length(rec) > 25)
    if (rec(1:25) == '+SOLUTION/MATRIX_ESTIMATE')
      matexist = 1;  % True
      break;
    end
  end
  rec = fgetl(fid);
  if ~ischar(rec)
    disp('Warning: No SOLUTION/MATRIX_ESTIMATE data block found');
    matexist = 0;  % False
    break;
  end
end

%----- Read covariance matrix

if matexist
  disp('Reading covariance matrix from snx file...');
  C = zeros(n,n);
  fgetl(fid);  %skip header
  rec = fgetl(fid);  %get first cov record
  if ~ischar(rec)
    error('Premature end of file before entire matrix read');
  end
  while (rec(1) ~= '-')
    %if (rec(1) ~= '-')
      indc = sscanf(rec(1:12),'%d');
      c = sscanf(rec(14:length(rec)),'%f');
      row = indc(1);
      col = [ indc(2) : indc(2)+length(c)-1 ];
      C(row,col) = c';
    %end
    rec = fgetl(fid);
  end
  C = C + C' - diag(diag(C));
  C = C(indx(:),indx(:));
end

%----- Save data

ofile=[ifile(1:findstr(ifile,'.')-1) '.mat'];
disp(' ');
disp(['Saving data (scode,XYZ,C) to ' ofile '...']);
if matexist
  eval(['save ' ofile ' scode XYZ C']);
else
  eval(['save ' ofile ' scode XYZ']);
end
fclose(fid);
