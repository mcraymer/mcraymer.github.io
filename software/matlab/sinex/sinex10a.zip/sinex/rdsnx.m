function [site,point,soln,epoch,x,y,z,C]=rdsnx(sfile)
% RDSNX  Reads XYZ coordinates and cov matrix from SINEX file.
%   Requires Geodetic Toolbox functions doy2jd & jd2yr.
% Version: 2010-03-23
% Usage:   [site,point,soln,epoch,x,y,z,C]=rdsnx(sfile)
% Input:   sfile - file name of SINEX file
% Output:  site - array of site codes (4 chars)
%          point- array of point code (2 chars)
%          soln - array of solution IDs (4 chars)
%          epoch- array of coordinate epochs (years+decimal)
%          x    - vector of Cartesian x components (m)
%          y    - vector of Cartesian y components (m)
%          z    - vector of Cartesian z components (m)
%          C    - geocentric XYZ covariance matrix (m^2)

% Version History
% 2010-03-23  Initial version

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=7 & nargout~=8)
  error('Incorrect number of output arguments');
end

%----- Open SINEX file

%disp(['Reading SINEX file ' sfile ' ...']);
fid=fopen(sfile,'r');
if fid<0
  error('*** Error: File not found');
end
cflag=0;

%----- Read number of coordinates

rec = fgetl(fid);
np = sscanf(rec(61:65),'%d');   % number parameters
if isempty(findstr(rec(68:length(rec)),'X')) & isempty(findstr(rec(68:length(rec)),'S'))    % check for coordinate estimates
  error('No coordinate solution type X or S found on SINEX header record');
end
%disp(['Number of parameters: ' num2str(np)]);

%----- Find estimated coordinates

while 1
  if length(rec) >= 18
    if rec(1:18) == '+SOLUTION/ESTIMATE'
      break;
    end
  end
  rec = fgetl(fid);
  if ~ischar(rec)
    error('No SOLUTION/ESTIMATE data block found');
  end
end

%----- Read station codes, coordinate epoch and coordinates

%disp('Reading station codes, epoch and coordinates...');
is = 0;
ms = floor(np/3);  % Max number of stations
indx = zeros(3,ms);
site = zeros(ms,4);
point = zeros(ms,2);
soln = zeros(ms,4);
epoch = zeros(ms,1);
XYZ = zeros(ms,3);
std = zeros(ms,3);
fgetl(fid);  %skip header

rec = fgetl(fid);  %get first station
while (rec(1) ~= '-')

  while rec(1) ~= '-'
    if rec(8:11)=='STAX'
      is = is+1;
      indx(1,is) = sscanf(rec(1:6),'%d');
      site(is,:) = sscanf(rec(15:18),'%4c');
      point(is,:) = sscanf(rec(20:21),'%2c');
      soln(is,:) = sscanf(rec(23:26),'%4c');
      yr = sscanf(rec(28:29),'%d');
      if yr>90
        yr = 1900+yr;
      else
        yr = 2000+yr;
      end
      doy = sscanf(rec(31:33),'%d');
      sod = sscanf(rec(35:39),'%d');
      jd = doy2jd(yr,doy+sod/86400);
      epoch(is,1) = jd2yr(jd);
      XYZ(is,1) = sscanf(rec(48:68),'%f');
      std(is,1) = sscanf(rec(70:80),'%f');
      rec = fgetl(fid);
      break;
    else
      rec = fgetl(fid);
    end
  end
  if rec(1) == '-'
    break;
  end

  while rec(1) ~= '-'
    if rec(8:11)=='STAY'
      indx(2,is) = sscanf(rec(1:6),'%d');
      XYZ(is,2) = sscanf(rec(48:68),'%f');
      std(is,2) = sscanf(rec(70:80),'%f');
      rec = fgetl(fid);
      break;
    else
      rec = fgetl(fid);
    end
  end
  if rec(1) == '-'
    break;
  end

  while rec(1) ~= '-'
    if rec(8:11)=='STAZ'
      indx(3,is) = sscanf(rec(1:6),'%d');
      XYZ(is,3) = sscanf(rec(48:68),'%f');
      std(is,3) = sscanf(rec(70:80),'%f');
      rec = fgetl(fid);
      %disp([site(is,:) ':' int2str(is) ':' int2str(indx(1,is)) ',' int2str(indx(2,is)) ',' int2str(indx(3,is))]);
      break;
    else
      rec = fgetl(fid);
    end
  end
end

% Remove zero padding (from using ms for initial dimensioning)
ns = is;
indx = indx(:,1:ns);
site = char(site(1:ns,:));
point = char(point(1:ns,:));
soln = char(soln(1:ns,:));
epoch = epoch(1:ns,1);
XYZ = XYZ(1:ns,:);
std = std(1:ns,:);
x=XYZ(:,1);
y=XYZ(:,2);
z=XYZ(:,3);
%disp([int2str(ns) ' stations found']);

%----- Find estimated covariance matrix

if nargout==8
  while 1
    if length(rec) > 25
      if (rec(1:25) == '+SOLUTION/MATRIX_ESTIMATE')
        matexist = 1;  % True
        break;
      end
    end
    rec = fgetl(fid);
    if ~ischar(rec)
      %disp('Warning: No SOLUTION/MATRIX_ESTIMATE data block found');
      matexist = 0;  % False
      break;
    end
  end

%----- Read covariance matrix

  if matexist
    %disp('Reading covariance matrix...');
    C = zeros(np,np);
    fgetl(fid);  %skip header
    rec = fgetl(fid);  %get first cov record
    if ~ischar(rec)
      error('Premature end of file before entire matrix read');
    end
    while rec(1) ~= '-'
      %if rec(1) ~= '-'
        indc = sscanf(rec(1:12),'%d');
        crec = sscanf(rec(14:length(rec)),'%f');
        row = indc(1);
        col = [ indc(2) : indc(2)+length(crec)-1 ];
        C(row,col) = crec';
      %end
      rec = fgetl(fid);
    end
    C = C + C' - diag(diag(C));
    C = C(indx(:),indx(:));
  else  % Form diagonal cov matrix from std on coordinate records
    %C=diag(reshape((std.^2)',ns*3,1));  % A bit slower method
    C=zeros(ns*3,ns*3);
    for i=1:ns
      indc=(i-1)*3+[1:3];
      C(indc,indc)=diag(std(i,:).^2);
    end
  end
end

%----- Close SINEX file

fclose(fid);
