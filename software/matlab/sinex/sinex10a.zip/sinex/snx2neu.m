function [yr,n,e,u,sn,se,su,X1,Y1,Z1,lat1,lon1,h1]=snx2neu(sfilespec,scode,a,e2)
% SNX2NEU  Read SINEX files and computes NEU coordinates and st.dev.
%   wrt initial position. Requires Geodetic Toolbox functions doy2jd &
%   jd2yr (used by rdsinex).
% Version: 2010-03-20
% Usage:   [yr,n,e,u,sn,se,su,X1,Y1,Z1,lat1,lon1,h1]=snx2neu (prompts for input)
%          [yr,n,e,u,sn,se,su,X1,Y1,Z1,lat1,lon1,h1]=snx2neu(sfilespec,scode,a,e2)
% Input:   sfilespec - SINEX file specification (wildcards ok)
%          scode - Site code (4 chars)
%          a   - ref. ellipsoid major semi-axis (m)
%          e2  - ref. ellipsoid eccentricity squared
% Output:  yr  - vector of epochs of NEU coordinates (years+decimal)
%          n   - vector of north coordinates wrt first file in sfilespec (m)
%          e   - vector of east coordinates (m)
%          u   - vector of up coordinates (m)
%          sn  - vector of std of north coordinates (m)
%          se  - vector std of east coordinates (m)
%          su  - vector std of up coordinates (m)
%          X1  - geocentric Cartesian X coordinates from first file (m)
%          Y1  - geocentric Carteisan Y coordinates (m)
%          Z1  - geocentric Carteisan Z coordinates (m)
%          lat1- ellipsoidal latitude from first filfe (rad)
%          lon1- ellipsoidal longitude (rad)
%          h1  - ellipsoidal height (m)

% Version History
% 2010-03-20  Initial version.
%
% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin==0
  [a,b,e2,finv]=refell('grs80');
  filespec=input('Enter file specification (w/ wildcards) > ','s');
  scode=input('Enter 4-char site code > ','s');
  disp(' ');
end

scode=upper(scode);
d=dir(filespec);

% Read XYZ from each SINEX file & find site ID
yr=[];  % epoch
n=[];   % north
e=[];   % east
u=[];   % up
sn=[];  % std north
se=[];  % std east
su=[];  % std up
for i=1:length(d)
  sfile=d(i).name;
  [site,point,soln,epoch,X,Y,Z,C]=rdsinex(sfile);
  ind=strcmp(scode,cellstr(upper(site)));
  is=find(ind);
  if is
    disp(['Found station ' scode ' in ' sfile]);
    if ~exist('X1')
      X1=X(is);
      Y1=Y(is);
      Z1=Z(is);
      [lat1,lon1,h1]=xyz2ell(X1,Y1,Z1,a,e2);
    end
    yr=[yr;epoch(is)];
    [lat,lon,h]=xyz2ell(X(is),Y(is),Z(is),a,e2);
    [ni,ei,ui]=ct2lg(X(is)-X1,Y(is)-Y1,Z(is)-Z1,lat,lon);
    n=[n;ni];
    e=[e;ei];
    u=[u;ui];
    cind=(is-1)*3+[1:3];
    Cneu=cct2clg(C(cind,cind),lat,lon);
    sn=[sn;sqrt(Cneu(1,1))];
    se=[se;sqrt(Cneu(2,2))];
    su=[su;sqrt(Cneu(3,3))];
  end
end
