function pltlabels(latd,lond,label,xoffset,yoffset)
% PLTNET  Plots point labels on a plot of network of points.
% Version: 2012-01-13
% Usage:   pltlabels(latd,lond,label,xoffset,yoffset)
% Input:   latd  - latitude of points (deg)
%          lond  - longitude of points (deg)
%          label - point labels (string vector)
%          xoffset - label offset in x from point (optional)
%          yoffset - label offset in y from point (optional)

% Version History
% 2012-01-13  Initial version based on pltnet in Geodetic Toolbox.

% Copyright (c) 2012, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<3
  error('Too few input arguments');
elseif nargin==3
  xoffset=0;
  yoffset=0;
elseif nargin==4
  yoffset=0;
elseif nargin>5
  error('Too many input arguments');
end

if ~isempty(label)
  error('No labels to plot');
end

n=length(latd);
for i=1:n
  text(lond(i)+xoffset,latd(i)+yoffset,label(i,:));
end
