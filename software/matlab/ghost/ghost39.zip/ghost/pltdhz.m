function pltdhz(latd,lond,dn,de,scale)
% PLTDHZ  Plots horizontal discrepancy vectors for a network.
% Version: 1998-04-03
% Usage:  pltdhz(latd,lond,dn,de,scale)
% Input:  latd - vector of latitudes (deg)
%         lond - vector of longitudes (deg)
%         dn   - vector of local north discrepancies (m)
%         de   - vector of local east discrepancies (m)
% Output: Plot
%
% Required M-files: pltvec

% Version History
% 1996-12-16  Initial version.
% 1998-04-03  Minor modifications.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin < 4)
  error('Incorrect number of input arguments');
elseif (nargin == 4)
  dlat=max(latd)-min(latd);
  dlon=max(lond)-min(lond);
  dmax=max([dlat;dlon]);
  dhmax=max(sqrt(dn.^2+de.^2));
  scale=dmax/10/dhmax;
elseif (nargin > 5)
  error('Incorrect number of input arguments');
end

clf;
plot(lond,latd,'ro');
hold on;
axis('equal');
pltvec(lond,latd,de,dn,scale,'b-');
hold off;
xlabel('Longitude (deg)');
ylabel('Latitutde (deg)');

hz=sqrt(dn.^2+de.^2);
hzmax=max(hz);
imax=find(hz==hzmax);
ax=axis;
text(ax(1)+(ax(2)-ax(1))/20,ax(3)+(ax(4)-ax(3))/20,['Max Hz Discrepancy = ' num2str(hzmax) ' (m)']);
