% MAT2GHO  Script to convert a MAT file of XYZ coordinates and CT
%   covariance matrix created by SNX2MAT to GHOST format (code 95
%   set). Optionally scales covariance matrix.
% Version: 2001-03-28
% Usage:   script prompts for input
% Input:   MAT file
%          Console:
%            Input MAT file name
%            Output GHOST 3DC file
%            Scale factor to rescale cov matrix (optional)
% Output:  MATLAB .mat file containing the following variables:
%            sname - array of station names (21 chars max)
%            XYZ   - array of geocentric X,Y,Z coordinates
%            C     - full covariance matrix in geocentric X,Y,Z

% Version History
% 1999-05-05  Initial version.
% 2001-03-28  Changed program discription comments and script banner.
%             Added checks for non-existence input file.
%             Added check for existing output file and confirm to
%             overwrite.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

clear
disp('MAT2GHO  Converts a MAT file of XYZ coordinates and CT');
disp('covariance matrix created by SNX2MAT to GHOST format');
disp('(code 95 set). Optionally scales covariance matrix.');
disp('Version: 2001-03-28');
disp(' ');

%----- Get input file

matfile=input('Enter input .mat file > ','s');
while (1)
  matfile=input('Enter input .mat file > ','s');
  mfid=fopen(matfile,'r');
  if mfid<0
    disp('*** Error: File not found');
  else
    fclose(mfid);
    break;
  end
end

%----- Get output file

while (1)
  gfile=input('Enter output GHOST file > ','s');
  gfid=fopen(gfile,'r');
  if gfid>0
    reply=input('*** Error: File already exists; overwrite it? [y,n] > ','s');
    if isempty(reply)
      reply='n';
    else
      reply=lower(reply);
    end
    if reply=='y'
      fclose(gfid);
      gfid=-1;
    end
  end
  if gfid<0  
    gfid=fopen(gfile,'w');
    if gfid<0
      error('Cannot open output file');
    else
      break;
    end
  end

%----- Get reference frame and scale factor

ref=input('Enter ref frame & epoch (e.g., ITRF96(1998.500) ) > ','s');
sf=input('Enter scale factor for cov matrix [1] > ');
if sf==[]
  sf=1;
end
disp(' ');

%----- Read coordinates and covariance matrix

eval(['load ' matfile]);  %sname,XYZ,C

%----- Write 3DC header

fprintf(1,'\n');
disp('Writing GHOST data file...');
disp('Writing code 95 header and coordinate records...');
fprintf(gfid,'* MAT file: %s\n',matfile);
fprintf(gfid,'* Reference frame: %s\n',ref);
fprintf(gfid,'* Cov matrix scaled by: %6.4f\n',sf);
fprintf(fid,' 953DC\n');

%----- Write position records

[n,m]=size(XYZ);
for i=1:n
  fprintf(fid,' 92    %-21s       %15.4f%15.4f%15.4f\n',sname(i,:),XYZ(i,1),XYZ(i,2),XYZ(i,3));
end

%----- Write covariance matrix

disp('Writing covariance matrix...');
fprintf(fid,' 97POV UPPER');
[n,m]=size(C);
for i=1:n
  fprintf(fid,'\n%20.11e%20.11e%20.11e%20.11e',C(i,i:n)*sf);
end
fprintf(fid,'\n');
fclose(fid);
