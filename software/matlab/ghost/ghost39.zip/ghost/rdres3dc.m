function [setid,rn,re,rh,rx,ry,rz]=rdres3dc(rfile,staid)
% RDCRES3DC  Reads coordinate observation (3DC) residuals from
%   LISRES.LIS file for a specified station.
% Version: 2011-11-27
% Usage:  [setid,rn,re,rh,rx,ry,rz]=rdres3dc(rfile,staid)
% Input:  rfile - file name of LISRES listing containing residuals
%         staid - station id for which to extract residuals
% Output: setid - vector of 3DC set description (char)
%         rn    - vector of residuals in north (m)
%         re    - vector of residuals in east (m)
%         rh    - vector of residuals in height (m)
%         rx    - vector of residuals in geocentric X (m)
%         ry    - vector of residuals in geocentric Y (m)
%         rz    - vector of residuals in geocentric Z (m)

% Version History
% 2003-04-11  Initial version.
% 2008-04-09  Modified for GHOST 2006Mar version.
% 2009-01-14  Corrected rdres2dc for sessions without specified
%             stations.
% 2011-11-27  Modified for GHOST version 2005Mar.
%             Computed NEU residual from XYZ residual (NEU residuals
%             not always computed correctly by GHOST).
%             Commented out status/debug output.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<2
  error('Incorrect number of input arguments');
end
if (nargout~=7)
  error('Incorrect number of output arguments');
end

%----- Extract left-justified 9-char station number
staid=strjust(staid,'left');
stanum=sprintf('%-9s',staid);
%disp(['[',stanum,']']);

%----- Open LISRES listing and initialize some variables
fid=fopen(rfile,'r');
nset=0;  % Number of 3DC sets
nres=0;  % Number of 3DC sets with specified station
rec=' ';
setid=char([]);
rn=[];
re=[];
rh=[];
rx=[];
ry=[];
rz=[];

%----- Search for start of residual listings
  while ~strcmp(rec(1:min(21,length(rec))),'    Residual listings')
    rec=fgetl(fid);
    if rec==-1; fclose(fid); return; end
  end
  %disp('Found residual listings');

%----- Main loop to search file
while 1
  rec=fgetl(fid);
  if rec==-1; fclose(fid); return; end

%----- Check for set ID
  if strcmp(rec(1:min(3,length(rec))),'  [')
    nset=nset+1;
    id=strjust(rec(4:27),'left');
    %disp(['3DC set ',num2str(nset),' [',id,']']);
  end

%----- Check for NEU residuals of specified station
%----- Forget this: NEU residuals not always computed correctly by GHOST
%  if strcmp(strjust(rec(2:min(10,length(rec))),'left'),stanum)
%    %disp(rec);
%    %keyboard
%    disp(['Found ',stanum,' in residual set ',id]);
%   %disp(['Found ',stanum,' in NEU residual set ',id]);
%    nres=nres+1;
%    setid(nres,:)=id;
%    rn(nres,1)=sscanf(rec(45:52),'%f');
%    rec=fgetl(fid);
%    if rec==-1; fclose(fid); return; end
%    re(nres,1)=sscanf(rec(45:52),'%f');
%    rec=fgetl(fid);
%    if rec==-1; fclose(fid); return; end
%    rh(nres,1)=sscanf(rec(45:52),'%f');
%    rec=fgetl(fid);
%    if rec==-1; fclose(fid); return; end
%    %disp([rn(nres) re(nres) rh(nres)]);
%  end

%----- Check for XYZ residuals of specified station
 %if strcmp(strjust(rec(18:min(26,length(rec))),'left'),stanum)
  if strcmp(strjust(rec(3:min(11,length(rec))),'left'),stanum) & strcmp(rec(15:15),'X')
   disp(['Found ',stanum,' in XYZ residual set ',id]);
    nres=nres+1;
    setid(nres,:)=id;

    x=sscanf(rec(17:28),'%f');
    rx(nres,1)=sscanf(rec(103:108),'%f');

    rec=fgetl(fid);
    if rec==-1; fclose(fid); return; end
    y=sscanf(rec(17:28),'%f');
    ry(nres,1)=sscanf(rec(103:108),'%f');

    rec=fgetl(fid);
    if rec==-1; fclose(fid); return; end
    z=sscanf(rec(17:28),'%f');
    rz(nres,1)=sscanf(rec(103:108),'%f');

    rec=fgetl(fid);
    if rec==-1; fclose(fid); return; end

    %disp([rx(nres) ry(nres) rz(nres)]);
    [lat,lon,h]=xyz2ell(x,y,z);
    [rn(nres,1),re(nres,1),rh(nres,1)]=ct2lg(rx(nres),ry(nres),rz(nres),lat,lon);
  end
%----- End of main loop
end
