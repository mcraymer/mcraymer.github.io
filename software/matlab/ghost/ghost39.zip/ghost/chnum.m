function chnum(ifile,ofile,oldnum,newnum)
% CHNUM  Reads GHOST input file and writes new file with station
% number oldnum changed to newnum on code 4, 24, 41, 92, 96 records.
% Version: 2009-05-10
% Useage:  chnum(ifile,ofile,oldnum,newnum)
% Input:   ifile - file name of input GHOST records
%          ofile - file name of output GHOST records
%          oldnum - old station number to change (9 chars max)
%          newnum - new station number (9 chars max)
% Output:  Updated GHOST file "ofile"

% Version History
% 2009-05-10  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=4)
  error('Incorrect number of input arguments');
end

ifid=fopen(ifile,'r');
if ifid==-1
  error(['Error opening input file ' ifile]);
end
ofid=fopen(ofile,'w');
if ofid==-1
  error(['Error opening output file ' ofile]);
end

oldnum=[strjust(oldnum,'left') blanks(9-length(oldnum))];
newnum=[strjust(newnum,'left') blanks(9-length(newnum))];

n=0;
while 1
  rec=fgetl(ifid);
  if ~isstr(rec)
    fclose(ifid);
    fclose(ofid);
    return;
  end
  n=n+1;
  if length(rec)>2
    recnum=rec(1:3);
    if recnum=='  4' | recnum==' 96' | recnum==' 24' | recnum==' 92'
      snum=strjust(rec(7:15),'left');
      if snum==oldnum
        disp([num2str(n) ': ' deblank(snum) ' -> ' deblank(newnum)]);
        rec(7:15)=newnum;
      end
    elseif recnum==' 41'
      snum=strjust(rec(7:15),'left');
      if snum==oldnum
        disp([num2str(n) ': ' deblank(snum) ' -> ' deblank(newnum)]);
        rec(7:15)=newnum;
      end
      snum=strjust(rec(16:24),'left');
      if snum==oldnum
        disp([num2str(n) ': ' deblank(snum) ' -> ' deblank(newnum)]);
        rec(16:24)=newnum;
      end
    end
  end
  fprintf(ofid,'%s\n',rec);
end
