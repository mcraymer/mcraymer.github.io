function wrdxyz(namefr,nameto,dx,dy,dz,gfile)
% WRDXYZ  Writes GHOST file containing code 41 (DXYZ) coordinate
%   difference records.
% Version: 2009-03-04
% Useage:  wrdxyz(namefr,nameto,dx,dy,dz,gfile)
% Input:   namefr - vector of "from" station names (9 chars each)
%          nameto - vector of "to" station names (9 chars each)
%          dx     - vector of Cartesian delta x components (m)
%          dy     - vector of Cartesian delta y components (m)
%          dz     - vector of Cartesian delta z components (m)
%          gfile  - optional output file name of GHOST code 41
%                   records (default = screen)

% Version History
% 2009-03-04  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<5 | nargin>6)
  error('Incorrect number of input arguments');
end

if (nargin==5)
  fid=1;
else
  fid=fopen(gfile,'w');
  if fid==-1
    error(['Error opening file ' gfile]);
  end
end

n=length(x);
rec=blanks(80);
for i=1:n
  rec(2:3)=sprintf('41');
  rec(7:15)=sprintf('%-24s',namefr(i,:));
  rec(16:25)=sprintf('%-24s',nameto(i,:));
  rec(36:80)=sprintf('%15.4f%15.4f%15.4f',[dx(i),dy(i),dz(i)]);
  fprintf(fid,'%s\n',rec);
end
