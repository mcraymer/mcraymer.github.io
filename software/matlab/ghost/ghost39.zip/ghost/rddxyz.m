function [namefr,nameto,dx,dy,dz]=rddxyz(gfile)
% RDDXYZ Reads GHOST file containing code 41 (DXYZ) coordinate
%   difference records.
% Version: 2009-03-04
% Useage:  [namefr,nameto,dx,dy,dz]=rddxyz(gfile)
% Input:   gfile  - file name of GHOST code 4 or 96 records
% Output:  namefr - vector of "from" station names (9 chars each)
%          nameto - vector of "to" station names (9 chars each)
%          dx     - vector of Cartesian delta x components (m)
%          dy     - vector of Cartesian delta y components (m)
%          dz     - vector of Cartesian delta z components (m)

% Version History
% 2009-03-04  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=5)
  error('Incorrect number of output arguments');
end

fid=fopen(gfile,'r');
if fid==-1
  error(['Error opening file ' gfile]);
end

n=0;
namefr=[];
nameto=[];
dx=[];
dy=[];
dz=[];

while 1
  rec=fgetl(fid);
  if ~isstr(rec)
    fclose(fid);
    return;
  end
  
  if length(rec)<3       % ignore record

  elseif rec(1:3)==' 41'
    n=n+1;
    namefr=[name;sscanf(rec(7:15),'%9c')];
    nameto=[name;sscanf(rec(16:25),'%9c')];
    x(n,1)=sscanf(rec(36:50),'%f');
    y(n,1)=sscanf(rec(51:65),'%f');
    z(n,1)=sscanf(rec(66:length(rec)),'%f');
  end
end
