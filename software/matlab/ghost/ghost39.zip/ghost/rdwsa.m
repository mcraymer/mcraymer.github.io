function [name,lat,lon,h,Clg,epoch]=rdwsa(gfile)
% RDWSA  Reads GHOST WSA file containing 93 (PRN) or 95 (3DC)
%   coordinate set with 96 or 92 coordinate records and LG
%   covariance (POV) or weight (RNE) matrix. Requires functions
%   jd2yr and refell.
% Version: 2010-11-10
% Useage:  [name,lat,lon,h,Clg,epoch]=rdwsa(gfile)
% Input:   gfile - file name of GHOST WSA file
% Output:  name  - vector of station numbers/names (24 chars each)
%          lat   - vector of latitudes (rad)
%          lon   - vector of longitudes (rad)
%          h     - vector of ellipsoidal heights (m)
%          Clg   - LG covariance matrix (m^2)
%          epoch - optional coordinate epoch (years)

% Version History
% 2009-05-10  Initial version.
% 2003-04-01  Modified rdwsa to also read 95 record sets, 92 (XYZ)
%             coordinate records and both covariance (POV) and weight
%             (POW,RNE) matrices, and expanded station id to include
%             station number and name.
%             Removed trimming of leading blanks.
% 2010-11-10  Modified to read optional epoch on 93 & 95 records, and
%             suppressed inadvertent output of h.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=5 & nargout~=6)
  error('Incorrect number of output arguments');
end
log=0; % status output (0=none, >0=yes)
[a,b,e2,finv]=refell('grs80');

fid=fopen(gfile,'r');
cflag=0;
nrec=0;
while 1
  rec=fgetl(fid);
  nrec=nrec+1;
  if ~isstr(rec)
    fclose(fid);
    if ~cflag
      error('Incomplete or no 93 (RNE) record set found');
    end
    return;
  end
  
  if length(rec)==0       % blank record

  elseif rec(1:1)~=' '    % comment record

  elseif rec(1:3)==' 93' | rec(1:3)==' 95'
    n=0;
    name=[];
    lat=[];
    lon=[];
    h=[];
    cov=[];
    yr=[];
    doy=[];

    if length(rec) >= 15
      if strfind(rec(8:15),':')
        yr=sscanf(rec(8:11),'%f');
        doy=sscanf(rec(13:15),'%f');
        if isempty(yr) || isempty(doy)
          epoch=[];
          warning('No epoch found on 91/95 record in file: %s\n',ifile);
        end
        epoch=jd2yr(doy2jd(yr,doy));
      elseif strfind(rec(8:15),'.')
        epoch=sscanf(rec(8:15),'%f');
        if isempty(epoch)
          warning('No epoch found on 91/95 record in file: %s\n',ifile);
        end
      else
        error('Invalid date format on input record %d\n',nrec);
      end
    end
    if log
      disp(['91/95 header record found -- epoch = ' num2str(epoch)]);
    end

  elseif rec(1:3)==' 96'
    n=n+1;
    name=[name;sscanf(rec(7:30),'%24c')];
    if log
      disp(['96 record found -- station [' name(n,:),']']);
    end
    latsgn=sscanf(rec(40),'%s');
    latd=sscanf(rec(41:42),'%i');
    latm=sscanf(rec(43:45),'%i');
    lats=sscanf(rec(46:54),'%f');
    lonsgn=sscanf(rec(55),'%s');
    lond=sscanf(rec(56:58),'%i');
    lonm=sscanf(rec(59:61),'%i');
    lons=sscanf(rec(62:70),'%f');
    lati=dms2rad([latd latm lats]);
    loni=dms2rad([lond lonm lons]);
    if upper(latsgn)=='S'
      lati=-lati;
    end
    if upper(lonsgn)=='W' | lonsgn==' '
      loni=-loni;
    end
    hi=sscanf(rec(71:length(rec)),'%f');
    lat=[lat;lati];
    lon=[lon;loni];
    h=[h;hi];

  elseif rec(1:3)==' 92'
    n=n+1;
    name=[name;sscanf(rec(7:30),'%24c')];
    if log
      disp(['92 record found -- station [' name(n,:),']']);
    end
    x=sscanf(rec(36:50),'%f');
    y=sscanf(rec(51:65),'%f');
    z=sscanf(rec(66:length(rec)),'%f');
    [lati,loni,hi]=xyz2ell(x,y,z,a,e2);
    lat=[lat;lati];
    lon=[lon;loni];
    h=[h;hi];

  elseif rec(1:3)==' 41'
    fclose(fid);
    error('41 (DXYZ) coordinate difference records not supported');

  elseif rec(1:3)==' 97'
    cflag=1;
    ctype=upper(rec(4:6));
    if ctype~='POV' & ctype~='POW' & ctype~='RNE'
      error('Matrix type ',ctype,' not supported');
    end
    if upper(strtrim(rec(7:14)))~='UPPER'
      error('Matrix not in UPPER format');
    end
    if length(rec)>71 & rec(72:min([80;length(rec)]))~=blanks(10)
      scale=sscanf(rec(72:min([80;length(rec)])),'%f');
    end

    nrow=n*3;
    Clg=zeros(nrow,nrow);
    for i=1:nrow
      ncol=nrow-i+1;
      nrec=fix(ncol/4);
      if rem(ncol,4)~=0
        nrec=nrec+1;
      end
      for irec=1:nrec
        ibeg=i+(irec-1)*4;
        iend=min([ibeg+3;nrow]);
        rec=fgetl(fid);
        if isstr(rec)
          Clg(i,[ibeg:iend])=(sscanf(rec,'%f'))';
        else
          fclose(fid);
          error('Premature end of file reading matrix');
        end
      end
    end
    Clg=(Clg+Clg'-diag(diag(Clg)));
    if ctype=='POW' | ctype=='RNE'
      Clg=inv(Clg);
    end
  end
end
