function [name,lat,lon,h]=rdplh(gfile)
% RDPLH  Reads GHOST file containing code 4 or code 96 (PLH)
%   coordinate records.
% Version: 2007-06-16
% Useage:  [name,lat,lon,h]=rdplh(gfile)
% Input:   gfile - file name of GHOST code 4 or 96 records
% Output:  name  - vector of station numbers & names (24 chars each)
%          lat   - vector of latitudes (rad)
%          lon   - vector of longitudes (rad)
%          h     - vector of ellipsoidal heights (m)

% Version History
% 1996-06-09  Initial version (rdgho4).
% 1996-11-30  Corrected.
% 2002-05-06  Changed name from rdgho4 to rdplh and expanded station
%             name to include GHOST station number and name (24
%             chars).
% 2004-04-26  Replaced use of obsolete function triml with strjust.
% 2007-06-16  Modified not to left-justify station number.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=4)
  error('Incorrect number of output arguments');
end

fid=fopen(gfile,'r');
if fid==-1
  error(['Error opening file ' gfile]);
end

n=0;
name=[];
lat=[];
lon=[];
h=[];

while 1
  rec=fgetl(fid);
  if ~isstr(rec)
    fclose(fid);
    return;
  end
  
  if length(rec)<3       % ignore record

  elseif rec(1:3)=='  4' | rec(1:3)==' 96'
    n=n+1;
    name=[name;sscanf(rec(7:30),'%24c')];
    latsgn=sscanf(rec(40),'%s');
    latd=sscanf(rec(41:42),'%i');
    latm=sscanf(rec(43:45),'%i');
    lats=sscanf(rec(46:54),'%f');
    lonsgn=sscanf(rec(55),'%s');
    lond=sscanf(rec(56:58),'%i');
    lonm=sscanf(rec(59:61),'%i');
    lons=sscanf(rec(62:70),'%f');
    lati=dms2rad([latd latm lats]);
    loni=dms2rad([lond lonm lons]);
    if isequal(upper(latsgn),'S')
      lati=-lati;
    end
    if isequal(upper(lonsgn),'W') | isempty(lonsgn)
      loni=-loni;
    end
    if loni>pi
      loni=loni-2*pi;
    end
    lat=[lat;lati];
    lon=[lon;loni];
    h=[h;sscanf(rec(71:length(rec)),'%f')];

  elseif rec(1:3)==' 92'
    flcose(fid);
    error('92 (XYZ) coordinate records not supported; use RDXYZ.M');

  elseif rec(1:3)==' 41'
    fclose(fid);
    error('41 (DXYZ) coordinate difference records not supported');
  end
end
