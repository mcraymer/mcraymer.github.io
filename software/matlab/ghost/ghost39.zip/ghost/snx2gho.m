function snx2gho2(sfile,gfile,ref)
% SNX2GHO  Converts SINEX file to GHOST format (code 95 set). Only
%   converts SOLUTION blocks.
% Version: 2012-01-15
% Usage:  snx2gho(sfile,gfile,ref)
%         snx2gho  (prompts for input)
% Input:  sfile - input SINEX file name
%         gfile - output GHOST 3DC/PEQ file name
%         ref   - reference frame ID (metadata only)
% Output: GHOST file (code 95 position equation set)

% Version History
% 1998.06.10  Initial version.
% 2000-10-23  Added error traps for opening i/o files.
%             Added automatic detection of velocity estimates.
% 2001-03-28  Changed program discription comments and script banner.
% 2006-12-19  Modified comments.
%             Removed option to scale covariance matrix.
%             Output site code + point code + soln number as station
%             number and name.
%             Get reference epoch from coordinate records and report
%             error if all coordinates not at same epoch.
%             Increased number of significant figure output in GHOST
%             covariance matrix.
% 2008-06-04  Added check for solution type S on header record.
% 2011-11-13  Modified for function use with optional interactive input.
% 2012-01-15  Corrected to not report incorrect number of input parameters
%             for interactive input.
%             Corrected check for valid paramter types on SINEX header
%             record.
%             Added error trap for no covariance matrix.

% Copyright (c) 2012, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin~=0 & nargin~=3
  disp('Incorrect number of input arguments');
  return;
end

%----- Prompt for input

if nargin==0
  fprintf('\n');
  disp('SNX2GHO  Converts SINEX file to GHOST format (code 95 set).');
  disp('  Only converts SOLUTION blocks.');
  disp('  M.Craymer, 2011-11-13');
  fprintf('\n');
end

%----- Get input file
while (1)
  if nargin==0
    sfile=input('Enter input SINEX file > ','s');
  end
  if isempty(sfile)
    return;
  end
  sfid=fopen(sfile,'r');
  if sfid<0
    disp('*** Error: Input SINEX file not found');
    if nargin~=0
      return;
    end
  else
    break;
  end
end

% Get output file
while (1)
  if nargin==0
    gfile=input('Enter output GHOST file > ','s');
  end
  gfid=fopen(gfile,'r');
  if gfid>0
    if nargin~=0
      disp('*** Output GHOST file already exists');
      return;
    else
      reply=input('*** Error: File already exists; overwrite it? [y,n] > ','s');
      if isempty(reply)
        reply='n';
      else
        reply=lower(reply);
      end
      if reply=='y'
        fclose(gfid);
        gfid=-1;
      end
    end
  end
  if gfid<0  
    gfid=fopen(gfile,'w');
    if gfid<0
      disp('Cannot open output GHOST file');
      return;
    else
      break;
    end
  end
end

% Get reference frame
if nargin==0
  ref=input('Enter reference frame (e.g., ITRF2005) > ','s');
end

%----- Echo function input

if nargin~=0
  disp(['Input SINEX file:  ' sfile]);
  disp(['Output GHOST file: ' gfile]);
  disp(['Reference frame:   ' ref]);
end

%---------- READING SINEX FILE

fprintf('\n');
disp('Reading SINEX file...');
rec = fgetl(sfid);
n = sscanf(rec(61:65),'%d');   % number parameters

if ~isempty(findstr(rec(68:length(rec)),'S'))
  ns=n/6;
else
  if ~isempty(findstr(rec(68:length(rec)),'X')) & ~isempty(findstr(rec(68:length(rec)),'V'))
    ns=n/6;
  elseif ~isempty(findstr(rec(68:length(rec)),'X')) & isempty(findstr(rec(68:length(rec)),'V'))
    ns=n/3;
  else
    disp('*** Error: No coordinate solution type X or S found on SINEX header record');
    return;
  end
end

%if ~isempty(findstr(rec(68:length(rec)),'X')) | ~isempty(findstr(rec(68:length(rec)),'S'))    % check for coordinate estimates
%  if isempty(findstr(rec(68:length(rec)),'V')) & isempty(findstr(rec(68:length(rec)),'S'))    % check for velocity estimates
%    ns=n/3;  % number of stations w/o velocity estimates
%  else
%    ns=n/6;  % number of stations with velocity estimates
%  end
%else
%  disp('*** Error: No coordinate solution type X or S found on SINEX header record');
%  return;
%end

disp(['Number of parameters: ' num2str(n)]);
disp(['Number of stations: ' num2str(ns)]);

%----- Find & read estimated coordinates

while (1)
  if (length(rec) >= 18)
    if (rec(1:18) == '+SOLUTION/ESTIMATE')
      break;
    end
  end
  rec = fgetl(sfid);
end

disp('Reading station codes, epoch and coordinates...');
is = 0;
indx = zeros([3 ns]);
scode = zeros([ns 4]);
pcode = zeros([ns 1]);
soln = zeros([ns 1]);
epoch = zeros([1 12]);
XYZ = zeros([ns 3]);
fgetl(sfid);  %skip header

rec = fgetl(sfid);  %get first station
while (rec(1) ~= '-')

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAX')
      is = is+1;
      indx(1,is) = sscanf(rec(1:6),'%d');
      scode(is,:) = sscanf(rec(15:18),'%s');
      pcode(is,:) = sscanf(rec(21:21),'%s');
      soln(is,:) = sscanf(rec(26:26),'%s');
      epoch = sscanf(rec(28:39),'%s');
      XYZ(is,1) = sscanf(rec(48:68),'%f');
      if (is == 1)
        refepoch = epoch;
      end
      if (refepoch ~= epoch)
        disp('***** Error: Coordinate reference epochs not the same');
        return;
      end
      rec = fgetl(sfid);
      break;
    else
      rec = fgetl(sfid);
    end
  end
  if (rec(1) == '-')
    break;
  end

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAY')
      indx(2,is) = sscanf(rec(1:6),'%d');
      XYZ(is,2) = sscanf(rec(48:68),'%f');
      rec = fgetl(sfid);
      break;
    else
      rec = fgetl(sfid);
    end
  end
  if (rec(1) == '-')
    break;
  end

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAZ')
      indx(3,is) = sscanf(rec(1:6),'%d');
      XYZ(is,3) = sscanf(rec(48:68),'%f');
      rec = fgetl(sfid);
      disp([int2str(is) ':' scode(is,:) '_' pcode(is,:) '_' soln(is,:) ':' epoch(1,:) ':' ...
           int2str(indx(1,is)) ',' int2str(indx(2,is)) ',' int2str(indx(3,is))]);
      break;
    else
      rec = fgetl(sfid);
    end
  end
end
ns = is;
indx = indx(:,1:ns);
scode = char(scode(1:ns,:));
pcode = char(pcode(1:ns,:));
soln = char(soln(1:ns,:));
epoch = char(epoch(1,:));
XYZ = XYZ(1:ns,:);
disp([int2str(ns) ' stations found']);

%----- Find & read estimated covariance matrix

while (1)
  if rec == -1
    disp('***** Error: Covariance matrix not found');
    return;
  end
  if (length(rec) > 25)
    if (rec(1:25) == '+SOLUTION/MATRIX_ESTIMATE')
      break;
    end
  end
  rec = fgetl(sfid);
end

disp('Reading covariance matrix...');
C = zeros(n,n);
fgetl(sfid);  %skip header
rec = fgetl(sfid);  %get first cov record
while (rec(1) ~= '-')
  %if (rec(1) ~= '-')
    indc = sscanf(rec(1:12),'%d');
    c = sscanf(rec(14:length(rec)),'%f');
    row = indc(1);
    col = [ indc(2) : indc(2)+length(c)-1 ];
    C(row,col) = c';
  %end
  rec = fgetl(sfid);
end

C = C + C' - diag(diag(C));
C = C(indx(:),indx(:));
fclose(sfid);

%---------- WRITING GHOST FILE (CODE 95 SET)

fprintf('\n');
disp('Writing GHOST data file...');
disp('Writing code 95 header and coordinate records...');
fprintf(gfid,'* SINEX file: %s\n',sfile);
fprintf(gfid,'* Reference frame: %s\n',ref);
fprintf(gfid,'* Reference epoch: %s\n',epoch);
fprintf(gfid,' 953DC\n');

%----- Write position records

[n,m]=size(XYZ);
for i=1:n
  id = [scode(i,:) '_' pcode(i,:) '_' soln(i,:)];
  fprintf(gfid,' 92   %-8s %-15s     %15.4f%15.4f%15.4f\n',id,id,XYZ(i,1),XYZ(i,2),XYZ(i,3));
end

%----- Write covariance matrix

disp('Writing covariance matrix...');
fprintf(gfid,' 97POV UPPER');
[n,m]=size(C);
for i=1:n
  fprintf(gfid,'\n%20.13e%20.13e%20.13e%20.13e',C(i,i:n));
end
fprintf(gfid,'\n');
fclose(gfid);
