function wrplh(code,name,lat,lon,h,gfile)
% WRPLH  Writes GHOST file containing code 4 or code 96 (PLH)
%   coordinate records.
% Version: 2002-05-05
% Useage:  wrplh(code,name,lat,lon,h,gfile)
% Input:   code  - output record code to write (4 or 96)
%          name  - vector of station names (24 chars each)
%          lat   - vector of latitudes (rad)
%          lon   - vector of longitudes (rad)
%          h     - vector of ellipsoidal heights (m)
%          gfile - optional output file name of GHOST code 4/96
%                  records (default = screen)

% Version History
% 2002-05-05  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<5 | nargin>6)
  error('Incorrect number of input arguments');
end

if code~=4 & code~=96
  error(['Incorrect code argument; must be 4 or 96']);
end

if (nargin==5)
  fid=1;
else
  fid=fopen(gfile,'w');
  if fid==-1
    error(['Error opening file ' gfile]);
  end
end

n=length(h);
rec=blanks(80);
for i=1:n
  rec(2:3)=sprintf('%2d',code);
  rec(7:30)=sprintf('%-24s',name(i,:));

  if (lat(i)<0)
    rec(40:40)=sprintf('%s','S');
  else
    rec(40:40)=sprintf('%s','N');
  end
  latdms=rad2dms(lat(i));
  rec(41:42)=sprintf('%2d',abs(latdms(1)));
  rec(43:45)=sprintf('%3d',abs(latdms(2)));
  rec(46:54)=sprintf('%9.6f',abs(latdms(3)));

  if (lon(i)<0)
    rec(55:55)=sprintf('%s','W');
  else
    rec(55:55)=sprintf('%s','E');
  end
  londms=rad2dms(lon(i));
  rec(56:58)=sprintf('%3d',abs(londms(1)));
  rec(59:61)=sprintf('%3d',abs(londms(2)));
  rec(62:70)=sprintf('%9.6f',abs(londms(3)));
  rec(71:79)=sprintf('%9.4f',h(i));

  fprintf(fid,'%s\n',rec);
end
