function [id,snum,name,latd,lond,h,dn,de,dh]=rdcompos2(cfile,skip)
% RDCOMPOS2  Reads coordinate differences given in GHOST COMPOS
%   output listing (Mar2005 version). Must leave complete headers
%   in listing. Reads total number of stations from header.
% Version: 2009-01-05
% Usage:  [id,snum,name,latd,lond,h,dn,de,dh]=rdcompos2(cfile,skip)
% Input:  cfile - file name of COMPOS listing
%         skip  - number of header lines to skip (default = 36)
% Output: id    - vector of station sequence numbers in listing
%         snum  - vector of station numbers
%         name  - vector of station names
%         latd  - vector of latitudes (deg)
%         lond  - vector of longitudes (deg)
%         h     - vector of heights (m)
%         dn    - vector of local geodetic x (north) component (m)
%         de    - vector of local geodetic y (east) component (m)
%         dh    - vector of local geodetic z (vertical) component (m)

% Version History
% 2009-01-05  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<1)
  error('Too few input arguments');
end
if (nargin==1)
  skip=36;
end
if (nargin>2)
  error('Too many input arguments');
end

%----- Open COMPOS listing file
fid=fopen(cfile,'r');
if fid==-1
  error(['Error opening file ' cfile]);
end

%---------- Skip header
n=0;
for i=1:36
  rec=fgetl(fid);
  if i==17
    n=sscanf(rec(55:62),'%d');
  end
end
disp(['Number of stations: ' num2str(n)]);

%----- Initialize arrays
id=zeros(n,1);
snum=zeros(n,9);
name=zeros(n,11);
latd=zeros(n,1);
lond=zeros(n,1);
h=zeros(n,1);
dn=zeros(n,1);
de=zeros(n,1);
dh=zeros(n,1);

%----- Begin reading data, skipping any headers
disp('Reading data from COMPOS listing...');
for i=1:n
  rec=fgetl(fid);
  %----- Skip any page headers & check for end of list
  if rec(1:59)=='                     Department of NATURAL RESOURCES Canada'
    for j=1:14
      rec=fgetl(fid);
    end
  end
  if rec(1:28)=='     Standard deviation    ='  % End of data, break out of while loop
    break;
  end
  %----- Read record
  %disp(rec);         %debug
  id(i,1)=sscanf(rec(1:6),'%i');
  snum(i,:)=rec(12:20);
  name(i,:)=rec(21:31);
  latsign=upper(rec(36));
  latdms=sscanf(rec(37:51),'%i %i %f');
  latd(i,1)=dms2deg(latdms');
  if (latsign=='S'), latd(i,1)=-latd(i,1); end
  lonsign=upper(rec(63));
  londms=sscanf(rec(64:79),'%i %i %f');
  lond(i,1)=dms2deg(londms');
  if (lonsign=='W' | lonsign==' '), lond(i,1)=-lond(i,1); end
  h(i,1)=sscanf(rec(90:99),'%f');
  dh(i,1)=sscanf(rec(110:118),'%f');
  daz=sscanf(rec(119:125),'%f');
  dhz=sscanf(rec(126:136),'%f');
  daz=(fix(daz)+(daz-fix(daz))*100/60) * pi/180;
  dn(i,1)=dhz*cos(daz);
  de(i,1)=dhz*sin(daz);
  if rem(i,100)==0
    disp([int2str(i) ' records processed']);
  end
end
name=char(name);  % Convert name array to character
if rem(i,100)~=0
  disp([int2str(n) ' records processed']);
end
%disp('*** Save workspace !!');
