function pltdiff(latd,lond,dn,de,du,hscale,vscale)
% PLTDIFF  Plots 3D coordinate differences for a network.
% Version: 1998-04-03
% Usage:  pltdiff(latd,lond,dn,de,du,scale);
% Input:  latd - vector of latitudes (deg)
%         lond - vector of longitudes (deg)
%         dn   - vector of local north discrepancies (m)
%         de   - vector of local east discrepancies (m)
%         du   - vector of local vertical discrepancies (m)
%         hscale - scale factor for horizontal discrepances (optional)
%         vscale - scale factor for vertical discrepances (optional)
% Output: plot

% Version History
% 1998-04-03  Initial version based on pltcomp.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<5
  error('Too few input arguments');
end

% Set discrepancy scale factors 1/10 plot size
if nargin==5
  dlat=max(latd)-min(latd);
  dlon=max(lond)-min(lond);
  dmax=max([dlat;dlon]);
  dhmax=max(sqrt(dn.^2+de.^2));
  hscale=dmax/10/dhmax;
  dumax=max(du);
  vscale=dmax/10/dumax;
end

% Plot discrepancies
clf;
whitebg('w');
plot(lond,latd,'go');
xlabel('Longitude (deg)');
ylabel('Latitude (deg)');
hold on;
axis('equal');
pltvec(lond,latd,de,dn,hscale,'b-');
pause;
pltvec(lond,latd,zeros(size(du)),du,vscale,'r-');
hold off;

% Plot scale legend
ax=axis;
text(ax(1)+(ax(2)-ax(1))/20,ax(3)+(ax(4)-ax(3))/20,['Max Horz/Vert Vectors = ' num2str(dhmax) ' / ' num2str(dumax) ' (m)']);
