function [name,x,y,z]=rdxyz(gfile)
% RDXYZ Reads GHOST file containing code 24 or code 92 (XYZ)
%   coordinate records.
% Version: 2004-04-26
% Useage:  [name,x,y,z]=rdxyz(gfile)
% Input:   gfile - file name of GHOST code 4 or 96 records
% Output:  name  - vector of station names (9 chars each)
%          x     - vector of Cartesian x components (m)
%          y     - vector of Cartesian y components (m)
%          z     - vector of Cartesian z components (m)

% Version History
% 2002-05-06  Initial version.
% 2004-04-26  Replaced use of obsolete function triml with strjust.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=4)
  error('Incorrect number of output arguments');
end

fid=fopen(gfile,'r');
if fid==-1
  error(['Error opening file ' gfile]);
end

n=0;
name=[];
x=[];
y=[];
z=[];

while 1
  rec=fgetl(fid);
  if ~isstr(rec)
    fclose(fid);
    return;
  end
  
  if length(rec)<3       % ignore record

  elseif rec(1:3)==' 24' | rec(1:3)==' 92'
    n=n+1;
    name=[name;sscanf(rec(7:30),'%24c')];
    x(n,1)=sscanf(rec(36:50),'%f');
    y(n,1)=sscanf(rec(51:65),'%f');
    z(n,1)=sscanf(rec(66:length(rec)),'%f');

  elseif rec(1:3)=='  4' | rec(1:3)==' 96'
    flcose(fid);
    error('4 & 96 (PLH) coordinate records not supported; use RDPLH.M');

  elseif rec(1:3)==' 41'
    fclose(fid);
    error('41 (DXYZ) coordinate difference records not supported');
  end
end
