function [id,snum,name,latd,lond,h,dn,de,dh]=rdcompos(cfile,skip)
% RDCOMPOS  Reads coordinate differences given in GHOST COMPOS
%   output listing (Mar2005 version). Must leave complete headers
%   in listing.
% Version: 2007-09-23
% Usage:  [id,snum,name,latd,lond,h,dn,de,dh]=rdcompos(cfile,skip)
% Input:  cfile - file name of COMPOS listing
%         skip  - number of header lines to skip (default = 36)
% Output: id    - vector of station sequence numbers in listing
%         snum  - vector of station numbers
%         name  - vector of station names
%         latd  - vector of latitudes (deg)
%         lond  - vector of longitudes (deg)
%         h     - vector of heights (m)
%         dn    - vector of local geodetic x (north) component (m)
%         de    - vector of local geodetic y (east) component (m)
%         dh    - vector of local geodetic z (vertical) component (m)

% Version History
% 2007-09-23  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<1)
  error('Too few input arguments');
end
if (nargin==1)
  skip=36;
end
if (nargin>2)
  error('Too many input arguments');
end

%----- Open COMPOS listing file
fid=fopen(cfile,'r');
if fid==-1
  error(['Error opening file ' cfile]);
end

%---------- Skip header
for i=1:36
  rec=fgetl(fid);
end

%----- Initialize arrays
n=0;
id=zeros(n,1);
snum=zeros(n,9);
name=zeros(n,11);
latd=zeros(n,1);
lond=zeros(n,1);
h=zeros(n,1);
dn=zeros(n,1);
de=zeros(n,1);
dh=zeros(n,1);

%----- Begin reading data, skipping any headers
disp('Reading data from COMPOS listing...');
n=0;
while 1
  rec=fgetl(fid);
  %if rec(1:1)=='1'    %skip header
  if rec(1:59)=='                     Department of NATURAL RESOURCES Canada'
    for j=1:14
      rec=fgetl(fid);
    end
  end
  if rec(1:28)=='     Standard deviation    ='  % End of data, break out of while loop
    break;
  end
  n=n+1;
  %disp(rec);         %debug
  id(n,1)=sscanf(rec(1:6),'%i');
  snum(n,:)=rec(12:20);
  name(n,:)=rec(21:31);
  latsign=upper(rec(36));
  latdms=sscanf(rec(37:51),'%i %i %f');
  latd(n,1)=dms2deg(latdms');
  if (latsign=='S'), latd(n,1)=-latd(n,1); end
  lonsign=upper(rec(63));
  londms=sscanf(rec(64:79),'%i %i %f');
  lond(n,1)=dms2deg(londms');
  if (lonsign=='W' | lonsign==' '), lond(n,1)=-lond(n,1); end
  h(n,1)=sscanf(rec(90:99),'%f');
  dh(n,1)=sscanf(rec(110:118),'%f');
  daz=sscanf(rec(119:125),'%f');
  dhz=sscanf(rec(126:136),'%f');
  daz=(fix(daz)+(daz-fix(daz))*100/60) * pi/180;
  dn(n,1)=dhz*cos(daz);
  de(n,1)=dhz*sin(daz);
  if rem(n,100)==0
    disp([int2str(n) ' records processed']);
  end
end
name=char(name);  % Convert name array to character
if rem(i,100)~=0
  disp([int2str(n) ' records processed']);
end
%disp('*** Save workspace !!');
