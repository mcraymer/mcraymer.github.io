function wrxyz(code,name,x,y,z,gfile)
% WRXYZ  Writes GHOST file containing code 24 or code 92 (XYZ)
%   coordinate records.
% Version: 2002-05-05
% Useage:  wrxyz(code,name,x,y,z,gfile)
% Input:   code  - output record code to write (24 or 92)
%          name  - vector of station names (24 chars each)
%          x     - vector of Cartesian x components (m)
%          y     - vector of Cartesian y components (m)
%          z     - vector of Cartesian z components (m)
%          gfile - optional output file name of GHOST code 24/92
%                  records (default = screen)

% Version History
% 2002-05-05  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<5 | nargin>6)
  error('Incorrect number of input arguments');
end

if code~=24 & code~=92
  error(['Incorrect code argument; must be 24 or 92']);
end

if (nargin==5)
  fid=1;
else
  fid=fopen(gfile,'w');
  if fid==-1
    error(['Error opening file ' gfile]);
  end
end

n=length(x);
rec=blanks(80);
for i=1:n
  rec(2:3)=sprintf('%d',code);
  rec(7:30)=sprintf('%-24s',name(i,:));
  rec(36:80)=sprintf('%15.4f%15.4f%15.4f',[x(i),y(i),z(i)]);
  fprintf(fid,'%s\n',rec);
end
