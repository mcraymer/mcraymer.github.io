function [lat,lon,h,slat,slon,sh,smaj,smed,smin,dist]=rdconfel(cfile,iref)
% RDCONFEL  Reads abs confidence region records from CONFEL.LIS. Must edit
%   CONFEL.LIS file to have number of stations on first line followed by 6
%   header records, and no header lines between station records.
% Version: 2000-12-14
% Usage:  [lat,lon,h,slat,slon,sh,smaj,smed,smin,dist]=rdconfel(cfile,iref)
% Input:  cfile - file name of CONFEL listing
%         iref  - index number of reference station for distances
% Output: lat  - vector of latitudes (rad)
%         lon  - vector of longitudes (rad)
%         h    - vector of ellipsoidal heights (m)
%         slat - vector of std of latitudes (m)
%         slon - vector of std of longitudes (m)
%         sh   - vector of std of heights (m)
%         smaj - vector of semi major axes (m) - assumed vert.
%         smed - vector of semi major axes (m)
%         smin - vector of semi major axes (m)
%         dist - distance from fixed station (m)

% Version History
% 1998.04.19  Initial version.
% 2000-12-14  Corrected to output lat,lon in radians.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<2
  error('Incorrect number of input arguments');
end
if (nargout~=10)
  error('Incorrect number of output arguments');
end

%----- Open CONFEL listing, get total number pts and skip header
fid=fopen(cfile,'r');
rec=fgetl(fid);
n=sscanf(rec,'%i');
for i=1:6
  rec=fgetl(fid);
end
disp(['Number of records to read: ' int2str(n)]);

%----- Check for valid iref
if iref>n
  error('Invalid iref (greater than number of stations)');
end

%----- Initialize data
lat=zeros(n,1);
lon=zeros(n,1);
h=zeros(n,1);
slat=zeros(n,1);
slon=zeros(n,1);
sh=zeros(n,1);
smaj=zeros(n,1);
smed=zeros(n,1);
smin=zeros(n,1);

%----- Read data
disp('Reading data...');
for i=1:n
  rec=fgetl(fid);
  num=sscanf(rec(1:5),'%i');
  if num~=i
    error(['Point number ' int2str(num) ' encountered. Expecting ' int2str(i)]);
  end

  latsign=upper(rec(34));
  latdms=sscanf(rec(36:50),'%i %i %f');
  lat(i)=dms2rad(latdms');
  if (latsign=='S'), lat(i)=-lat(i); end
  lonsign=upper(rec(63));
  londms=sscanf(rec(64:76),'%i %i %f');
  lon(i)=dms2rad(londms');
  if (lonsign=='W' | lonsign== ' '), lon(i)=-lon(i); end
  h(i)=sscanf(rec(91:100),'%f');

  slat(i)=sscanf(rec(52:59),'%f');
  slon(i)=sscanf(rec(81:88),'%f');
  sh(i)=sscanf(rec(102:109),'%f');

  smaj(i)=sscanf(rec(111:117),'%f');
  smed(i)=sscanf(rec(118:125),'%f');
  smin(i)=sscanf(rec(126:132),'%f');

  if (rem(i,10)==0), disp([int2str(i) ' records read']); end;
end
disp([int2str(n) ' total records read']);

%----- Compute distance from fixed
[a,b,e2,finv]=refell('GRS80');
[X,Y,Z]=ell2xyz(lat,lon,h,a,e2);
dX=X-X(iref);
dY=Y-Y(iref);
dZ=Z-Z(iref);
dist=sqrt(dX.^2+dY.^2+dZ.^2);

disp('*** Save workspace !!');
