function wrwsa(setcode,reccode,name,pos1,pos2,pos3,Mlg,gfile)
% WRXYZ  Writes GHOST 93 (WSA) or 95 (3DC) record set code 92 (X,Y,Z)
%   or code 96 (lat,lon,h) coordinate records and covariance matrix.
% Version: 2003-04-01
% Useage:  wrwsa(setcode,reccode,name,pos1,pos2,pos3,Mlg,gfile)
% Input:   setcode - output set code to write (93 or 95)
%          reccode - output coordinate record code (92 or 96)
%          name  - vector of station numbers/names (24 chars each)
%          pos1  - vector of latitudes (rad) or Cartesian x components (m)
%          pos2  - vector of longitudes (rad) or Cartesian y components (m)
%          pos3  - vector of ell. heights (m) or Cartesian z components (m)
%          Mlg   - matrix of local geodetic covariance or weight matrix
%          gfile - optional output file name of GHOST code 24/92
%                  records (default = screen)

% Version History
% 2003-04-01  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<7 | nargin>8)
  error('Incorrect number of input arguments');
end

if setcode~=93 & setcode~=95
  error(['Incorrect set code; must be 93 or 95']);
end

if reccode~=92 & reccode~=96
  error(['Incorrect coordinate record code; must be 92 or 96']);
end

if (nargin==7)
  fid=1;
else
  fid=fopen(gfile,'w');
  if fid==-1
    error(['Error opening file ' gfile]);
  end
end

if setcode==93
  fprintf(fid,' 93PRN\n');
elseif setcode==95
  fprintf(fid,' 953DC\n');
end

n=length(pos1);
rec=blanks(80);
if reccode==92
  for i=1:n
    if setcode==93
      rec(1:6)=' 92WSA';
    elseif setcode==95
      rec(1:3)=' 92';
    end
    rec(7:30)=sprintf('%-24s',name(i,:));
    rec(36:80)=sprintf('%15.4f%15.4f%15.4f',[pos1(i),pos2(i),pos3(i)]);
    fprintf(fid,'%s\n',rec);
  end
elseif reccode==96
  for i=1:n
    if setcode==93
      rec(1:6)=' 96WSA';
    elseif setcode==95
      rec(1:3)=' 96';
    end
   rec(7:30)=sprintf('%-24s',name(i,:));

    if (pos1(i)<0)
      rec(40:40)=sprintf('%s','S');
    else
      rec(40:40)=sprintf('%s','N');
    end
    latdms=rad2dms(pos1(i));
    rec(41:42)=sprintf('%2d',abs(latdms(1)));
    rec(43:45)=sprintf('%3d',abs(latdms(2)));
    rec(46:54)=sprintf('%9.6f',abs(latdms(3)));

    if (pos2(i)<0)
      rec(55:55)=sprintf('%s','W');
    else
      rec(55:55)=sprintf('%s','E');
    end
    londms=rad2dms(pos2(i));
    rec(56:58)=sprintf('%3d',abs(londms(1)));
    rec(59:61)=sprintf('%3d',abs(londms(2)));
    rec(62:70)=sprintf('%9.6f',abs(londms(3)));
    rec(71:79)=sprintf('%9.4f',pos3(i));

    fprintf(fid,'%s\n',rec);
  end
end

if setcode==93
  fprintf(fid,' 97RNE   UPPER\n');
elseif setcode==95
  fprintf(fid,' 97POV   UPPER\n');
end
nc=n*3;
for i=1:nc
  fprintf(fid,'%20.13e%20.13e%20.13e%20.13e\n',Mlg(i,[i:nc]));
  if rem(nc-i+1,4)~=0
    fprintf(fid,'\n');
  end
end
