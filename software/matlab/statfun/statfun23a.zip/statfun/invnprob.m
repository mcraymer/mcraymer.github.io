function x=invnprob(p);
% INVNPROB  Inverse of normal probability. Computes abscissa x of the
%   normal distribution for probability from -infinity to x. Uses
%   inverse error function inverf.
% Version: 1992-10-19
% Useage:  x=invnprob(p)
% Input:   p - probability from -inf to x
% Output:  x - abscissa of normal distribution

% Version History
% 1992-10-19  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if p>0.5
  x=sqrt(2)*inverf(2*(p-0.5));
else
  x=-sqrt(2)*inverf(2*(1-p-0.5));
end
