function x=mrand(xm,Cx,n,seed)
% MRAND  Multivariate Random Numbers
%   Generates multivariate normal random numbers given mean and
%   covariance of distribution. To check distribution, run mean(x)
%   and cov(x) after this routine.
% Version 1994-09-28
% Useage: x=mrand(xm,Cx,n,seed)
% Input:  xm   - desired mean (col) vector
%         Cx   - desired covariance matrix
%         seed - random number generator seed (0 used if not
%                specified)
% Output: x - matrix of random numbers with mean xm and cov matrix Cx
%             (each row is an observation and each column is a random
%             variable).

% Version History
% 1994-09-28  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<3
  error('Incorrect number of arguments');
elseif nargin==3
  rand('seed',0);
else
  rand('seed',seed);
end
rand('normal');
p=length(xm);
u=rand(n,p);
R=chol(Cx);
x=ones(n,p)*diag(xm)+u*R;
