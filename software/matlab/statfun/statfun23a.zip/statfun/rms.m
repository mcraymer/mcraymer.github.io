function xrms=rms(x)
% RMS  Computes root mean square (rms) of a vector or matrix (column-
%   wise).
% Version: 1996-01-24
% Useage:  xrms=rms(x)
% Input:   x  - data vector or array
% Output:  xr - rms of x vector or row vector of column-
%               wise rmses of x array

% Version History
% 1996-01-24  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

[n,m]=size(x);
if m==1
  xrms=sqrt((x'*x)/n);
else
  xrms=sqrt(mean(x.*x));
end
