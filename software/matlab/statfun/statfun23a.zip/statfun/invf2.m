function x=invf2(p,v2);
% INVF2  Inverse Fisher distribution for 2 degrees of freedom.
%   Computes abscissa x of Fisher distn for 2 degrees of freedom and
%   probability from -infinity to x.  Uses approximation for F distn
%   found in Steeves R.R., "A statistical test for significant peaks
%   in the least squares spectrum", in Collected Papers, Geodetic
%   Survey of Canada, 1981.
% Version: 1995-02-21
% Useage:  x=invchi2(p)
% Input:   p  - probability from -inf to x
%          v2 - 2nd degrees of freedom
% Output:  x  - abscissa of chi-square dist'n

% Version History
% 1995-02-21  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<2
  error('Too few input arguments');
end
x=((1-p).^(-2/v2)-1)*v2/2;
