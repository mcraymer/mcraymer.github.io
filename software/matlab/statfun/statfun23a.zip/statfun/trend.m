function [b,Cb,vf,yest,r]=trend(t,y,dat,lin,per,Cy)
% TREND
%   Estimates trend for a given time series defined by multiple datum
%   biases (y offsets), a common linear trend, and multiple periodic
%   components. Optionally weights observations. Note that the y-
%   intecept is considered to be the intial y offset at starting time
%   of series t(1). The true y-intercept is the value of the linear
%   trend at absolute time zero (t=0).
% Version 2007-05-26
% Usage:  [b,Cb,vf,yest,r]=trend(t,y,dat,lin,per,Cy)
% Input:  t  - vector of time (independent variable)
%         y  - vector of observations (dependent variable)
%         dat- optional vector of times of datum biases (y offsets),
%              including any y-intercept; empty vector [] = no offsets
%              or y-intercept (default y-intercept only)
%         lin- optional linear trend flag; 0 = no linear trend, other
%              value indicates linear trend (default = 1)
%         per- vector of periods for periodic components; empty vector
%              [] = no periodic components (default = no periods)
%         Cy - optional a priori covariance matrix for y observations
%              (default = identity matrix)
% Output: b  - estimated parameters:
%              b(1...nd) = datum offsets (nd = # offsets)
%              b(nd+1) = linear trend
%              b(nd+2...nd+np+1) = ampl of sine terms (np = # periods)
%              b(nd+np+2...nd+2*np+1) = ampl of cosine terms
%         Cb - covariance matrix for b (not scaled by vf)
%         vf - estimated variance factor
%         yest - estiamted observations
%         r  - observation residuals (estimated yest=y-r)

% Version History
% 2007-05-26  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<2 | nargin>6
  error('Incorrect number of arguments');
end
if nargin<3
  dat=t(1);
end
if nargin<4
  lin=1;
end
if nargin<5
  per=[];
end

% Ensure t is a column vector
[n,m]=size(t);
if n>1 && m>1
  error('Input times (t) not a vector');
end
if n<m
  t=t';
end

% Ensure y is a column vector
[n,m]=size(y);
if n>1 && m>1
  error('Input observations (y) not a vector');
end
if n<m
  y=y';
end

% Ensure dat is a column vector
[n,m]=size(dat);
if n>1 && m>1
  error('Input datum biases (dat) not a vector');
end
if n<m
  dat=dat';
end

% Ensure lin is either 0 or 1
if lin
  lin=1;
end

% Ensure per is a column vector
[n,m]=size(per);
if n>1 && m>1
  error('Input periods (per) not a vector');
end
if n<m
  per=per';
end

% Design matrix -- vectorized
n=max(size(y));
nd=length(dat);
np=length(per);
kt=kron(ones(1,nd),t);
ktmin=kron(ones(n,1),dat');
ktmax=kron(ones(n,1),[dat(2:nd);max(t)+1]');
kp=kron(t,2*pi./per');
A=(kt>=ktmin & kt<ktmax);
if lin
  A=[A t];
end
if np>0
  A=[A sin(kp) cos(kp)];
end

% Least squares solution
df=n-nd-lin-2*np;
if nargin<6     % Weighted by inv(Cy)
  Cb=inv(A'*A);
  b=Cb*A'*y;
  yest=A*b;
  r=y-yest;
  vf=(r'*r)/df;
else            % Equally weighted
  P=inv(Cy);
  AtP=A'*P;
  Cb=inv(AtP*A);
  b=Cb*AtP*y;
  yest=A*b;
  r=y-yest;
  vf=(r'*P*r)/df;
end
