function R=corr(C)
% CORR  Correlation matrix. Computes correlation matrix (R) from
%   covariance matrix (C).
% Version 1994-07-07
% Useage: R=corr(C)
% Input:  C - covariance matrix
% Output: R - correlation matrix

% Version History
% 1994-07-07  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

d=diag(C);
R=C./sqrt(d*d');
