function [b,Cb,vf,r,yest]=lreg2(x,y,xo,Cy)
% LREG2  Linear regression with optional multiple offsets. Computes
%   slope and optional multiple y offsets for a linear regression of y
%   on x.
% Version 2009-02-21
% Usage:  [b,Cb,vf,yest,r]=lreg2(x,y,xo,Cy)
% Input:  x  - vector of independent variable
%         y  - vector of dependent variable
%         xo - optional vector of x values of y offsets, including
%              y-intercept (default y-intercept; []=no intercept)
%         Cy - optional a priori covariance matrix for y (default
%              identity matrix)
% Output: b  - estimated parameters
%              b(1...no) = y offsets (no=length(xo))
%              b(no+1) = slope
%         Cb - covariance matrix for b (not scaled by vf)
%         vf - estimated variance factor
%         r  - y residuals
%         yest - estimated y values (for plotting trend)

% Version History
% 2005-02-17  Initial version.
% 2006-11-27  Vectorized, added wtd soln.
% 2007-05-26  Corrected usage comment and nargin check.
% 2009-02-21  Added no intercept solution (default).

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<2 | nargin>4
  error('Incorrect number of arguments');
end
if nargin==2
  xo=x(1);
end

% Ensure xo is a column vector
[n,m]=size(xo);
if n<m
  xo=xo';
end

% Design matrix -- vectorized
n=max(size(y));
no=length(xo);
if no==0
  A=x;
else
  kx=kron(ones(1,no),x);
  kxmin=kron(ones(n,1),xo');
  kxmax=kron(ones(n,1),[xo(2:no);max(x)+1]');
  A=[(kx>=kxmin & kx<kxmax) x];
end

% Least squares solution
if nargin<4         % Equally weighted
  Cb=inv(A'*A);
  b=Cb*A'*y;
  yest=A*b;
  r=y-yest;
  vf=(r'*r)/(n-no-1);
elseif nargin==4    % Weighted by Cy
  P=inv(Cy);
  AtP=A'*P;
  Cb=inv(AtP*A);
  b=Cb*AtP*y;
  yest=A*b;
  r=y-yest;
  vf=(r'*P*r)/(n-no-1);
end
