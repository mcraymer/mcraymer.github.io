function [m,s,vf]=wmean(x,C)
% WMEAN  Weighted Mean
%   Computes weighted mean of vector x using weights derived from a
%   priori covariance matrix or variance vector.
% Version 2002-11-11
% Usage:  [m,s,vf]=wmean(x,C)
% Input:  x  - vector of observations
%         C  - a priori covariance matrix or vector of variances of x
%              (default = identity matrix)
% Output: m  - estimated weighted least squares mean
%         s  - estimated standard deviation of m (not scaled by vf)
%         vf - estimated variance factor
% Required M-File: ncols

% Version History
% 2002-11-11  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin<1
  error('Two few input arguments');
end

n=max(size(x));
A=ones(n,1);
if nargin==1
  Ninv=inv(A'*A);
  m=Ninv*A'*x;
  r=x-m;
  vf=(r'*r)/(n-1);
else
  if ncols(C)==1
    Ninv=inv(A'*(A./C));
    m=Ninv*A'*(x./C);
    r=x-m;
    vf=(r'*(r./C))/(n-1);
  else
    P=inv(C);
    Ninv=inv(A'*P*A);
    m=Ninv*A'*P*x;
    r=x-m;
    vf=(r'*P*r)/(n-1);
  end
end
s=sqrt(Ninv);
