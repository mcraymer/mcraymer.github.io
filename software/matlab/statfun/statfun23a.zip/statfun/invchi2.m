function x=invchi2(p);
% INVCHI2  Inverse Chi-Square for 2 degrees freedom. Computes abscissa
%   x of chi-square distn for 2 degrees of freedom and probability
%   from -infinity to x.  Uses approximation for F distn found in
%   Steeves R.R., "A statistical test for significant peaks in the
%   least squares spectrum", in Collected Papers, Geodetic Survey,
%   1981.
% Version: 1995-02-21
% Useage:  x=invchi2(p)
% Input:   p - probability from -inf to x
% Output:  x - abscissa of chi-square dist'n

% Version History
% 1995-02-21  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

v=1e6;  % define a very large 2nd deg. of freedom
x=2*((1-p).^(-2/v)-1)*v/2;  % Chi=2*F
