function p=nprob(x);
% NPROB  Normal Probability
%   Computes probability for the normal distribution from minus
%   infinity to x. Uses error function erf.
% Version: 1992-10-19
% Useage:  p=nprob(x)
% Input:   x - abscissa of normal distribution
% Output:  p - probability from -inf to x

% Version History
% 1992-10-19  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

p=0.5*erf(-inf,x/sqrt(2));
