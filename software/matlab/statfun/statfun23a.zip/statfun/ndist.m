function y=ndist(x,m,s);
% NDIST  Normal Probability Distribution
%   Computes values of the curve for the normal distribution for a
%   given set of random varibles.
% Version: 1999-05-24
% Usage:   y=ndist(x,m,s)
% Input:   x - normally distributed random varibles
%          m - mean of x (default = 0)
%          s - std of x (default = 1)
% Output:  y - values of the normal distribution curve

% Version History
% 1999-05-24  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin>3
  error('Too many input arguments');
elseif nargin==2
  s = 1;
elseif nargin==1
  m = 0;
  s = 1;
elseif nargin <1
  error('Too few input arguments');
end

z = (x-m)/s;
y = 1/(s*sqrt(2*pi)) * exp(-0.5*z.^2);
