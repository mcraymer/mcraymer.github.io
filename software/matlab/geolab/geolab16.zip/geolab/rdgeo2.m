function [id,lat,lon,h,Clg]=rdgeo2(gfile)
% RDGEO2  Reads GeoLab v2 ADJ file containing 3DC coordinate set
%   with PLH coordinate records and LG COV matrix; created by
%   "Extract Obs..." option in GeoLab program.
% Version: 2003-04-08
% Useage:  [id,lat,lon,h,Clg]=rdgeo2(gfile)
% Input:   gfile - file name of GeoLab v2 ADJ file
% Output:  id    - vector of station id's (12 chars each)
%          lat   - vector of latitudes (rad)
%          lon   - vector of longitudes (rad)
%          h     - vector of ellipsoidal heights (m)
%          Clg   - LG covariance matrix (m^2)

% Version History
% 1996-09-08  Initial version.
% 2003-04-08  Changed variable "name" to "id".

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=5)
  error('Incorrect number of output arguments');
end

fid=fopen(gfile,'r');
cflag=0;
while 1
  rec=fgetl(fid);
  if ~isstr(rec)
    fclose(fid);
    if ~cflag
      error('Incomplete or no 3DC record set found');
    end
    return;
  end
  
  if length(rec)==0       % blank record

  elseif rec(1:1)~=' '    % comment record

  elseif upper(rec(1:4))==' 3DC'
    n=0;
    id=[];
    lat=[];
    lon=[];
    h=[];
    cov=[];

  elseif upper(rec(1:4))==' PLH'
    n=n+1;
    id=[id;sscanf(rec(11:22),'%12c')];
    latsgn=sscanf(rec(24),'%s');
    latdms=sscanf(rec(25:40),'%i %i %f');
    lonsgn=sscanf(rec(42),'%s');
    londms=sscanf(rec(43:58),'%i %i %f');
    lati=dms2rad(latdms');
    loni=dms2rad(londms');
    if upper(latsgn)=='S'
      lati=-lati;
    end
    if upper(lonsgn)=='W'
      loni=-loni;
    end
    lat=[lat;lati];
    lon=[lon;loni];
    h=[h;sscanf(rec(60:length(rec)),'%f')];

  elseif upper(rec(1:4))==' XYZ'
    flcose(fid);
    error('XYZ coordinate records not supported');

  elseif upper(rec(1:5))==' DXYZ'
    fclose(fid);
    error('DXYZ coordinate difference records not supported');

  elseif upper(rec(1:4))==' COV'
    cflag=' COV';
    if upper(rec(7:8))~='LG'
      error('COV matrix not in LG system');
    end
    if upper(rec(10:13))~='UPPR'
      error('COV matrix not in UPPR format');
    end
    if length(rec)>15 & rec(15:min([24;length(rec)]))~=blanks(10)
      error('Addition for entire COV matrix not supported');
    end
    if length(rec)>26 & rec(26:min([35;length(rec)]))~=blanks(10)
      scale=sscanf(rec(26:min([35;length(rec)])),'%f');
    end
    if length(rec)>48 & rec(48:min([57;length(rec)]))~=blanks(10)
      error('Scale factor for COV matrix diagonal not supported');
    end
    if length(rec)>59 & rec(59:min([68;length(rec)]))~=blanks(10)
      error('PPM addition for COV matrix diagonal not supported');
    end

    nrow=n*3;
    Clg=zeros(nrow,nrow);
    for i=1:nrow
      ncol=nrow-i+1;
      nrec=fix(ncol/3);
      if rem(ncol,3)~=0
        nrec=nrec+1;
      end
      for irec=1:nrec
        ibeg=i+(irec-1)*3;
        iend=min([ibeg+2;nrow]);
        rec=fgetl(fid);
        if isstr(rec)
          if rec(1:5)==' ELEM'
            Clg(i,[ibeg:iend])=(sscanf(rec(6:length(rec)),'%f'))';
          else
            fclose(fid);
            error('Too few COV matrix ELEM records');
          end
        else
          fclose(fid);
          error('Premature end of file reading COV matrix');
        end
      end
    end
    Clg=Clg+Clg'-diag(diag(Clg));
  end
end
