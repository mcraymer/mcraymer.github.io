% TRNIOB  Script to transforms GeoLab IOB observation file from one
%   reference system to another. Supports 92 (XYZ), 41 (DXYZ) records.
%   Transforms covariance matrices.
% Version: 1996-06-05
% Usage:   Script prompts for input
% Input:   GeoLab IOB file to transform
%          Console;
%            Input GeoLab IOB file name
%            Output (transformed) GeoLab IOB file name
%            Transformation type
%            Epoch of input GeoLab observations
% Outpu:   Transformed GeoLab IOB file
% Required M-files: caldate, ell2xyz, juldate, refell

% Version History
% 1996-04-28  Initial version.
% 1996-04-30  Transformed covariance matrices.
%             Added Octave-specific statements.
% 1996-05-01  Changed to left-handed rotation matrix following
%             TRNFSP3N convention.
%             Added 95 3DC records.
%             Input date as yr,mn,dy.
% 1996-05-02  Corrected bug in assignment of ITRF92->NAD83 parms.
%             Added two debug levels:
%                1 = trans. cov
%                2 = trans. cov + print debugs
% 1006-05-24  Support input of date in either yyyy.yy, yyyy ddd,
%             yyyy mm dd formats.
% 1996-06-02  Converted to PC and MATLAB.
%             Converted to GeoLab v1 & v2.
% 1996-06-05  Changed name to trniob.
%             Fixed miscellaneous bugs.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

clear;
clear functions;
fclose('all');
ver = 'MatLab 5 Jun 96';
dbg = 0;   % debug flag (1=transform cov matrices, 2=print all debug output)

%--------------------------------------------------------------------------
% Transformation parameter definitions, obtained from TRNFSP data files
% and defined by:
%   ITRF92->NAD83 (Kouba & Popelar, 1994, KIS94, pp.79-86, Table2)
%   ITRF93->ITRF92 (IGS AC report, Table 9, 1st line)
%   ITRF94->NAD83 (Kouba & Popelar, 1994, KIS94, pp.79-86, Table2)
%--------------------------------------------------------------------------

%epoch(yr), tx(cm), ty(cm), tz(cm), ds(ppb), rx(mas), ry(mas), rz(mas)
B=zeros(4,8);
B(1,:)=[1988.0  93.6  -198.4  -54.3  5.0  -27.5   -15.5   -10.7];   % ITRF92->NAD83 (Kouba & Popelar, 1994, KIS94, pp.79-86, Table2)
B(2,:)=[1988.0  94.0  -197.9  -53.4  4.1  -27.09  -16.22  -9.87];   % ITRF93->NAD83 (IGS AC report, Table 9, 1st line)
B(3,:)=[1988.0  94.2  -197.9  -53.4  4.9  -27.3   -15.4   -10.7];   % ITRF94->NAD83 (Kouba & Popelar, 1994, KIS94, pp.79-86, Table2)
B(4,:)=[1996.0   2.0      .0     .0   .0    1.21     .77     .55];  % ITRF93-ITRF94 (Weighted transf. of the 13 ITRF(IGS) stations)

%dtx(cm/y), dty(cm/y), dtz(cm/y), dds(ppb/y), drx(mas/y), dry(mas/y), drz(mas/y)
dB=zeros(4,7);
dB(1,:)=[ .00  .00   .00  .0   -.052  .742   .032];  % ITRF92->NAD83 (Kouba & Popelar, 1994, KIS94, pp.79-86,Table2)
dB(2,:)=[ .23  .04  -.08  .11   .078  .962  -.008];  % ITRF93->NAD83 (IGS AC report, Table 9, 1st line)
dB(3,:)=[-.04  .04  -.08  .0   -.052  .762   .022];  % ITRF94->NAD83 (Kouba & Popelar, 1994, KIS94, pp.79-86, Table2, corrected drz)
dB(4,:)=[ .27  .0    .0   .10   .13   .20   -.03];   % ITRF93-ITRF94 (Weighted transf. of the 13 ITRF(IGS) stations, corrected dtx)

%--------------------------------------------------------------------------
% User I/O
%--------------------------------------------------------------------------

%----- Get transformation type

disp(' ');
disp('TRNIOB: Transforms GeoLab IOB observation file to new reference system');
disp(['        Version: ', ver]);

while 1
  disp(' ');
  disp('Available Transformations:');
  disp(' ');
  disp('1) ITRF92 -> NAD83       7) NAD83  -> ITRF92');
  disp('2) ITRF93 -> NAD83       8) NAD83  -> ITRF93');
  disp('3) ITRF94 -> NAD83       9) NAD83  -> ITRF94');
  disp('4) ITRF92 -> ITRF93     10) ITRF93 -> ITRF92');
  disp('5) ITRF92 -> ITRF94     11) ITRF94 -> ITRF92');
  disp('6) ITRF93 -> ITRF94     12) ITRF94 -> ITRF93');
  itrn=input('Enter transformation number [0=quit] > ');

  if (itrn == [])
    itrn = 0;
  end

  if (itrn == 0)                          % Exit program
    return;   %MATLAB
  elseif (itrn == 1)                      % ITRF92 -> NAD83
    trn = 'ITRF92 -> NAD83';
    to = B(1,1);
    po = B(1,2:8);
    dp = dB(1,1:7);
    break;
  elseif (itrn == 2)                      % ITRF93 -> NAD83
    trn = 'ITRF93 -> NAD83';
    to = B(2,1);
    po = B(2,2:8);
    dp = dB(2,1:7);
    break;
  elseif (itrn == 3)                      % ITRF94 -> NAD83
    trn = 'ITRF94 -> NAD83';
    to = B(3,1);
    po = B(3,2:8);
    dp = dB(3,1:7);
    break;
  elseif (itrn == 6)                      % ITRF93 -> ITRF94
    trn = 'ITRF93 -> ITRF94';
    to = B(4,1);
    po = B(4,2:8);
    dp = dB(4,1:7);
    break;
  elseif (itrn == 7)                      % NAD83 -> ITRF92
    trn = 'NAD83 -> ITRF92';
    to = B(1,1);
    po = -B(1,2:8);
    dp = -dB(1,1:7);
    break;
  elseif (itrn == 8)                      % NAD83 -> ITRF93
    trn = 'NAD83 -> ITRF93';
    to = B(2,1);
    po = -B(2,2:8);
    dp = -dB(2,1:7);
    break;
  elseif (itrn == 9)                      % NAD83 -> ITRF94
    trn = 'NAD83 -> ITRF94';
    to = B(3,1);
    po = -B(3,2:8);
    dp = -dB(3,1:7);
    break;
  elseif (itrn == 12)                     % ITRF94 -> ITRF93
    trn = 'ITRF94 -> ITRF93';
    to = B(4,1);
    po = -B(4,2:8);
    dp = -dB(4,1:7);
    break;
  else
    fprintf(1,'*** Undefined transformation selected\a\n');
  end
end %while

%----- Get input 3DD file

while 1
  fnin=input('Enter file for input GeoLab 3DD observation sets > ','s');
  if exist(fnin)
    fin=fopen(fnin,'r');
    break;
  else
    fprintf(1,'*** Error: File not found\a\n');
  end
end %while

%----- Get output 3DD file

while 1
  while 1
    fnout=input('Enter file for output 3DD observation sets > ','s');
    if exist(fnout)
      if strcmp(upper(input('*** File exists, overwrite it [y,N]? ','s')),'Y');
        break;
      end
    else
      break;
    end
  end %while

  fout=fopen(fnout,'wt');
  if (fout == -1)
    disp('*** Error opening file');
  else
    break;
  end
end %while

%----- Get epoch of observation file and convert to decimal years

while 1
  rec = input('Enter epoch of 3DD obs (yyyy mm dd, yyyy ddd, yyyy.yy) > ','s');
  [cdate nd] = sscanf(rec,'%f');
  if (cdate(1) < 1900)
    disp('*** Error: Invalid year, less than 1900');
  else
    break;
  end
end
  
if (nd == 1)
  t = cdate;
  [yr mn dy] = caldate( juldate(floor(t),1,0) + (t-floor(t))*365.25 );
elseif (nd == 2)
  t = cdate(1) + cdate(2)/365.25;
  [yr mn dy] = caldate( juldate(cdate(1),1,0) + cdate(2) );
elseif (nd == 3)
  yr = cdate(1);
  mn = cdate(2);
  dy = cdate(3);
  t = yr + (juldate(yr,mn,dy) - juldate(yr,1,0)) / 365.25;
end

%----- Get reference ellipsoid

while 1
  rell = input('Enter reference ellipsoid (NAD27,NAD83) [NAD83] > ','s');
  if (strcmp(rell,''))
    rell = 'NAD83';
  end
  [a,b,e2,finv]=refell(rell);
  if exist('a')
    break;
  end
end

%----- Get debug level

%dbg = input('Enter debug level > ');

%----- Compute transformation parameters for target epoch

p = po + dp*(t-to);
tx = p(1:3)'/100;
ds = p(4)/1e9;
r = p(5:7)*pi/3600000/180;
cosx = cos(r(1));
sinx = sin(r(1));
cosy = cos(r(2));
siny = sin(r(2));
cosz = cos(r(3));
sinz = sin(r(3));
% Following R uses TRNFSP3 left-handed rotations
R = [1 0 0; 0 cosx -sinx; 0 sinx cosx] * ...
    [cosy 0 siny; 0 1 0; -siny 0 cosy] * ...
    [cosz -sinz 0; sinz cosz 0; 0 0 1];

%----- List transformation parameters used

disp(' ');
disp(['Transformation Parameters: ' num2str(to) ' - ' num2str(t)]);
disp(['dx = ' num2str(p(1)) ' (cm)']);
disp(['dy = ' num2str(p(2)) ' (cm)']);
disp(['dz = ' num2str(p(3)) ' (cm)']);
disp(['ds = ' num2str(p(4)) ' (ppb)']);
disp(['rx = ' num2str(p(5)) ' (mas)']);
disp(['ry = ' num2str(p(6)) ' (mas)']);
disp(['rz = ' num2str(p(7)) ' (mas)']);

%R  %debug output

%--------------------------------------------------------------------------
% Main loop to read, transform, and write each 3DD set
%--------------------------------------------------------------------------

fprintf(fout,'* Modified by TRNIOB: %s, Epoch %i-%i-%5.2f\n',trn,yr,mn,dy);
eof = 0;
nset = 0;

while 1
  rec = fgetl(fin);
  if (dbg > 1)
    disp(rec);
  end
  if isstr(rec)
    reclen = length(rec);

%----- GeoLab v1 or v2 3D observation header record (rec=91,95,3DD,3DC)

    if ( strcmp(rec(1:min(reclen,3)),' 91') | ...
         strcmp(rec(1:min(reclen,3)),' 95') | ...
         strcmp(rec(1:min(reclen,4)),' 3DD') | ...
         strcmp(rec(1:min(reclen,4)),' 3DC') )
      nset = nset + 1;
      disp(' ');
      fprintf(1,'Transforming 3D observation set %i...\n',nset);
      ns = 0;
      disp(rec);
      fprintf(fout,'%s\n',rec);

%----- GeoLab v1 ellipsoidal coordinate record (rec=96)

    elseif strcmp(rec(1:min(reclen,3)),' 96')
      disp('*** Warning: Ellipsoidal coordinates found -- not transformed');
      fprintf(fout,'%s\n',rec);

%----- GeoLab v2 ellipsoidal coordinate record (rec=PLH)

    elseif strcmp(rec(1:min(reclen,4)),' PLH')
      ns = ns + 1;
      staname = sscanf(rec(11:22),'%s');
      disp([rec(1:4),'   ',staname]);
      latdms = sscanf(rec(25:40),'%f')';
      londms = sscanf(rec(43:58),'%f')';
      h = sscanf(rec(60:length(rec)),'%f');

      lat = dms2rad(latdms);
      if (upper(rec(24:24)) == 'S')
        lat = -lat;
      end
      lon = dms2rad(londms);
      if (upper(rec(24:24)) == 'W')
        lon = -lon;
      end

      [x,y,z] = ell2xyz(lat,lon,h,a,e2);
      x1 = [x;y;z];
      x2 = (1+ds)*R*x1 + tx;
      x = x2(1);
      y = x2(2);
      z = x2(3);
      [lat,lon,h] = xyz2ell(x,y,z,a,e2);

      if (lat < 0)
        rec(24:24) = 's';
      else
        rec(24:24) = 'n';
      end
      if (lon < 0)
        rec(42:42) = 'w';
      else
        rec(42:42) = 'e';
      end
      latdms = rad2dms(abs(lat));
      londms = rad2dms(abs(lon));

      if (lat<0) lat = lat + 2*pi; end
      if (lon<0) lon = lon + 2*pi; end
      latdms = rad2dms(lat);
      londms = rad2dms(lon);
      rec(24:24) = 'n';
      rec(42:42) = 'e';

      rec(25:40) = sprintf('%3i %2i %9.6f', latdms);
      rec(43:58) = sprintf('%3i %2i %9.6f', londms);
      rec(60:71) = sprintf('%12.4f',h);
      fprintf(fout,'%s\n',rec);

%----- GeoLab v1 cartesian coordinate record (rec=92)

    elseif strcmp(rec(1:min(reclen,3)),' 92')
      ns = ns + 1;
      staname = sscanf(rec(7:15),'%s');
      disp([rec(1:3),'   ',staname]);
      x1=zeros(3,1);
      x1(1) = sscanf(rec(36:50),'%f');
      x1(2) = sscanf(rec(51:65),'%f');
      x1(3) = sscanf(rec(66:length(rec)),'%f');

      x2 = (1+ds)*R*x1 + tx;

      rec(36:50) = sprintf('%15.4f', x2(1));
      rec(51:65) = sprintf('%15.4f', x2(2));
      rec(66:80) = sprintf('%15.4f', x2(3));
      fprintf(fout,'%s\n',rec);

%----- GeoLab v2 cartesian coordinate record (rec=XYZ)

    elseif strcmp(rec(1:min(reclen,4)),' XYZ')
      ns = ns + 1;
      staname = sscanf(rec(11:22),'%s');
      disp([rec(1:4),'   ',staname]);
      x1 = sscanf(rec(24:79),'%f');

      x2 = (1+ds)*R*x1 + tx;

      rec(24:79) = sprintf('%18.4f %18.4f %18.4f', x2);
      fprintf(fout,'%s\n',rec);

%----- GeoLab v1 cartesian coordinate difference record (rec=41)

    elseif strcmp(rec(1:min(reclen,3)),' 41')
      ns = ns + 1;
      if (ns == 1)
        ns = ns + 1;
      end
      from = sscanf(rec(7:15),'%s');
      to = sscanf(rec(16:24),'%s');
      disp([rec(1:3),'   ',from,'   ',to]);
      x1=zeros(3,1);
      x1(1) = sscanf(rec(36:50),'%f');
      x1(2) = sscanf(rec(51:65),'%f');
      x1(3) = sscanf(rec(66:length(rec)),'%f');

      x2 = (1+ds)*R*x1;
      rec(36:80) = sprintf('%15.4f%15.4f%15.4f', x2);
      fprintf(fout,'%s\n',rec);

%----- GeoLab v2 cartesian coordinate difference record (rec=DXYZ)

    elseif strcmp(rec(1:min(reclen,5)),' DXYZ')
      ns = ns + 1;
      if (ns == 1)
        ns = ns + 1;
      end
      from = sscanf(rec(11:22),'%s');
      to = sscanf(rec(24:35),'%s');
      disp([rec(1:5),'   ',from,'   ',to]);
      x1 = sscanf(rec(37:77),'%f');

      x2 = (1+ds)*R*x1;

      rec(37:77) = sprintf('%13.4f %13.4f %13.4f', x2);
      fprintf(fout,'%s\n',rec);

%----- GeoLab v1 matrix header record (rec=97)

    elseif strcmp(rec(1:min(reclen,3)),' 97')
      disp(rec);
      fprintf(fout,'%s\n',rec);

      if (dbg == 1)
      % Read original matrix
      nx = (ns-1)*3;
      C1 = zeros(nx,nx);
      for i=1:nx
        for j=i:nx
          C1(i,j) = fscanf(fin,'%f',1);
          if ( (rem(j-i+1,4) == 0) | (j == nx) )
            fgetl(fin);
          end
        end
      end
      C1 = C1 + C1' - diag(diag(C1));

      % Transform original matrix
      T = [];
      for i=1:ns-1
        [nr,nc]=size(T);
        T = [T zeros(nr,3); zeros(3,nc) (ds+1)*R];
      end
      C2 = T*C1*T';

      % Write transformed matrix
      for i=1:nx
        for j=i:nx
          fprintf(fout,' %19.12e',C2(i,j));
          if ( (rem(j-i+1,4) == 0) | (j == nx) )
            fprintf(fout,'\n');
          end
        end %for
      end %for

      disp(['Max change in cov matrix = ' num2str( max(abs( C1(:)-C2(:) )) )]);

      else %debug~=1
        disp('*** Warning: Covariance matrix not transformed');
      end %if debug

%----- GeoLab v2 matrix header record (rec=COV)

    elseif strcmp(rec(1:min(reclen,4)),' COV')
      disp(rec);
      fprintf(fout,'%s\n',rec);

%----- Other records

    else
      fprintf(fout,'%s\n',rec);
    end

%----- End of file, exit

  else
    if (rec == -1)
      break;
    else
      error('Error reading file');
    end
  end
end %while
fclose(fin);
fclose(fout);
fprintf(1,'\nTRNIOB finished\a\n\n');
