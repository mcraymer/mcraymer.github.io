function [id,lat,lon,h,Clg]=rdgeo1(gfile)
% RDGEO1  Reads GeoLab v1 ADJ file containing 95 coordinate
%   set with code 96 ellipsoidal coordinate records and LG
%   covariance matrix; created by GeoLab utility program
%   Toolkit.
% Version: 2003-04-08
% Useage:  [id,lat,lon,h,Clg]=rdgeo1(gfile)
% Input:   gfile - file name of GeoLab v1 ADJ file
% Output:  id    - vector of station id's (12 chars each)
%          lat   - vector of latitudes (rad)
%          lon   - vector of longitudes (rad)
%          h     - vector of ellipsoidal heights (m)
%          Clg   - LG covariance matrix (m^2)

% Version History
% 2003-04-08  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin~=1)
  error('Incorrect number of input arguments');
end
if (nargout~=5)
  error('Incorrect number of output arguments');
end

fid=fopen(gfile,'r');
cflag=0;
while 1
  rec=fgetl(fid);
  if ~isstr(rec)
    fclose(fid);
    if ~cflag
      error('Incomplete or no 3DC record set found');
    end
    return;
  end
  
  if length(rec)==0       % blank record

  elseif rec(1:1)~=' '    % comment record

  elseif upper(rec(1:3))==' 95'
    n=0;
    id=[];
    lat=[];
    lon=[];
    h=[];
    cov=[];

  elseif upper(rec(1:3))==' 96'
    n=n+1;
    id=[id;sscanf(rec(7:14),'%8c')];
    latsgn=sscanf(rec(40),'%s');
%   latdms=sscanf(rec(41:54),'%2i%3i%9.6f');
    latd=sscanf(rec(41:42),'%i');
    latm=sscanf(rec(43:45),'%i');
    lats=sscanf(rec(46:54),'%f');
    lonsgn=sscanf(rec(55),'%s');
%   londms=sscanf(rec(56:70),'%3i%3i%9.6f');
    lond=sscanf(rec(56:58),'%i');
    lonm=sscanf(rec(59:61),'%i');
    lons=sscanf(rec(62:70),'%f');
    lati=dms2rad([latd latm lats]);
    loni=dms2rad([lond lonm lons]);
    if upper(latsgn)=='S'
      lati=-lati;
    end
    if upper(lonsgn)=='W'
      loni=-loni;
    end
    lat=[lat;lati];
    lon=[lon;loni];
    h=[h;sscanf(rec(71:length(rec)),'%f')];

  elseif upper(rec(1:3))==' 92'
    flcose(fid);
    error('Code 92 Cartesian coordinate records not supported');

  elseif upper(rec(1:3))==' 41'
    fclose(fid);
    error('Code 41 Cartesian coordinate difference records not supported');

  elseif upper(rec(1:6))==' 97POV'
    cflag=' COV';
    if trim(upper(rec(7:min(length(rec),14))))~='UPPER'
      error('Covariance matrix not in UPPER format');
    end
    if length(rec)>14 & rec(15:length(rec))~=blanks(length(rec)-14)
      error('Additional covariance matrix arguments not supported');
    end

    nrow=n*3;
    Clg=zeros(nrow,nrow);
    for i=1:nrow
      ncol=nrow-i+1;
      nrec=fix(ncol/3);
      if rem(ncol,3)~=0
        nrec=nrec+1;
      end
      for irec=1:nrec
        ibeg=i+(irec-1)*3;
        iend=min([ibeg+2;nrow]);
        rec=fgetl(fid);
        if isstr(rec)
          if rec(1:3)==' 98'
            Clg(i,[ibeg:iend])=(sscanf(rec(5:length(rec)),'%f'))';
          else
            fclose(fid);
            error('Too few code 98 matrix element records');
          end
        else
          fclose(fid);
          error('Premature end of file reading covariance matrix');
        end
      end
    end
    Clg=Clg+Clg'-diag(diag(Clg));
  end
end
