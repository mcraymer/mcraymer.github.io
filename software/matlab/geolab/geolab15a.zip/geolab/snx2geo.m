% SNX2GEO  Script to convert a file of XYZ coordinates and CT
%   covariance matrix from SINEX format to GeoLab 2 format (3DC
%   set). Optionally scales covariance matrix.
% Version: 2001-03-28
% Usage:   script prompts for input
% Input:   SINEX file
%          Console:
%            Input SINEX file name
%            Output GeoLab 3DC file
%            Reference frame & epoch (metadata only)
%            Scale factor to rescale cov matrix (optional)
% Output:  GeoLab file containing 3DC position observation set

% Version History
% 2001-03-28  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

clear
disp('SNX2GEO  Converts a file of XYZ coordinates and CT covariance');
disp('matrix from SINEX format to GeoLab 2 format (3DC set). Optionally');
disp('scales covariance matrix.');
disp('Version: 2001-03-28');
disp(' ');

%----- Get input file

while (1)
  sfile=input('Enter input SINEX file > ','s');
  sfid=fopen(sfile,'r');
  if sfid<0
    disp('*** Error: File not found');
  else
    break;
  end
end

%----- Get output file

while (1)
  gfile=input('Enter output GeoLab 2 file > ','s');
  gfid=fopen(gfile,'r');
  if gfid>0
    reply=input('*** Error: File already exists; overwrite it? [y,n] > ','s');
    if isempty(reply)
      reply='n';
    else
      reply=lower(reply);
    end
    if reply=='y'
      fclose(gfid);
      gfid=-1;
    end
  end
  if gfid<0  
    gfid=fopen(gfile,'w');
    if gfid<0
      error('Cannot open output file');
    else
      break;
    end
  end
end

%----- Get reference frame and scale factor

ref=input('Enter ref frame & epoch (e.g., ITRF96(1998.500) ) > ','s');
sf=input('Enter scale factor for cov matrix [1] > ');
if isempty(sf)
  sf=1;
end
fprintf(1,'\n');

%---------- READING SINEX FILE

disp('Reading SINEX file...');
rec = fgetl(sfid);
n = sscanf(rec(61:65),'%d');   % number parameters
if ~isempty(findstr(rec(68:length(rec)),'X'))    % check for coordinate estimates
  if isempty(findstr(rec(68:length(rec)),'V'))   % check for velocity estimates
    ns=n/3;  % number of stations w/o velocity estimates
  else
    ns=n/6;  % number of stations with velocity estimates
  end
else
  error('No coordinate solution type X found on SINEX header record');
end
disp(' ');
disp(['Number of parameters: ' num2str(n)]);
disp(['Number of stations: ' num2str(ns)]);

%----- Find & read estimated coordinates

while (1)
  if (length(rec) >= 18)
    if (rec(1:18) == '+SOLUTION/ESTIMATE')
      break;
    end
  end
  rec = fgetl(sfid);
end

disp('Reading station codes and coordinates...');
is = 0;
indx = zeros([3 ns]);
scode = zeros([ns 4]);
XYZ = zeros([ns 3]);
fgetl(sfid);  %skip header

rec = fgetl(sfid);  %get first station
while (rec(1) ~= '-')

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAX')
      is = is+1;
      indx(1,is) = sscanf(rec(1:6),'%d');
      scode(is,:) = sscanf(rec(15:18),'%s');
      XYZ(is,1) = sscanf(rec(48:68),'%f');
      rec = fgetl(sfid);
      break;
    else
      rec = fgetl(sfid);
    end
  end
  if (rec(1) == '-')
    break;
  end

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAY')
      indx(2,is) = sscanf(rec(1:6),'%d');
      XYZ(is,2) = sscanf(rec(48:68),'%f');
      rec = fgetl(sfid);
      break;
    else
      rec = fgetl(sfid);
    end
  end
  if (rec(1) == '-')
    break;
  end

  while (rec(1) ~= '-')
    if (rec(8:11)=='STAZ')
      indx(3,is) = sscanf(rec(1:6),'%d');
      XYZ(is,3) = sscanf(rec(48:68),'%f');
      rec = fgetl(sfid);
      disp([scode(is,:) ':' int2str(is) ':' int2str(indx(1,is)) ',' int2str(indx(2,is)) ',' int2str(indx(3,is))]);
      break;
    else
      rec = fgetl(sfid);
    end
  end
end
ns = is;
indx = indx(:,1:ns);
scode = char(scode(1:ns,:));
XYZ = XYZ(1:ns,:);
disp([int2str(ns) ' stations found']);

%----- Find & read estimated covariance matrix

while (1)
  if (length(rec) > 25)
    if (rec(1:25) == '+SOLUTION/MATRIX_ESTIMATE')
      break;
    end
  end
  rec = fgetl(sfid);
end

disp('Reading covariance matrix...');
C = zeros(n,n);
fgetl(sfid);  %skip header
rec = fgetl(sfid);  %get first cov record
while (rec(1) ~= '-')
  %if (rec(1) ~= '-')
    indc = sscanf(rec(1:12),'%d');
    c = sscanf(rec(14:length(rec)),'%f');
    row = indc(1);
    col = [ indc(2) : indc(2)+length(c)-1 ];
    C(row,col) = c';
  %end
  rec = fgetl(sfid);
end

C = C + C' - diag(diag(C));
C = C(indx(:),indx(:));
fclose(sfid);

%---------- WRITING GEOLAB2 FILE (3DC SET)

fprintf(1,'\n');
disp('Writing GeoLab data file...');
disp('Writing 3DC header and coordinate records...');
fprintf(gfid,'* SINEX solution: %s\n',sfile);
fprintf(gfid,'* Reference frame: %s\n',ref);
fprintf(gfid,'* Cov matrix scaled by: %6.4f\n',sf);
fprintf(gfid,' 3DC\n');

%----- Write position records

[n,m]=size(XYZ);
for i=1:n
  fprintf(gfid,' XYZ      %-12s %18.4f %18.4f %18.4f\n',scode(i,:),XYZ(i,1),XYZ(i,2),XYZ(i,3));
end

%----- Write covariance matrix

disp('Writing covariance matrix...');
fprintf(gfid,' COV  CT UPPR');
[n,m]=size(C);
for i=1:n
  fprintf(gfid,'\n ELEM %23.15e %23.15e %23.15e',C(i,i:n)*sf);
end
fprintf(gfid,'\n');
fclose(gfid);
