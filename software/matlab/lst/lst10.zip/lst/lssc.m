function s=lssc(x,t,f,opt1,opt2)
% Least Squares Spectrum for Correlated Frequencies
% (For Use With Inverse Transform)
%   Computes one-sided least squares spectral values for a
%   for a given data series and set of frequencies. Accounts
%   for correlations among frequencies. Optionally weights
%   observation data series. See also LSS (for no correlations).
%
%   *** NOTE *** Use only with linearly independent frequencies
%   (i.e., omit Nyquist frequency whose design matrix components
%   are identical with the zero frequency).
%
% Version: 9 Jan 98
% Useage:  s=lssc(x,t,f)
%          s=lssc(x,t,f,'norm')
%          s=lssc(x,t,f,P)
%          s=lssc(x,t,f,P,'norm')
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
%          P - observation weight matrix (optional, P=I
%              default)
%          'norm' - flag to normalize spectrum
% Output:  s - spectral values at frequecies f

if nargin<3
  error('Too few input arguments');
elseif nargin==3
    wtd=0;      %weighted soln flag (0=unweighted,1=weighted)
    norm=0;     %normalization flag (0=unnormalized,1=normalized)
    P=eye(length(x));
elseif nargin==4
  if isstr(opt1)       %opt1='norm'
    wtd=0;
    P=eye(length(x));
    if strcmp(opt1,'norm')
      norm=1;
    else
      error('Incorrect 4th input argument');
    end
  else                 %opt1=P
    wtd=1;
    norm=0;
    P=opt1;
  end
elseif nargin==5
  wtd=1;
  P=opt1;
  if isstr(opt2)
    if strcmp(opt2,'norm')
      norm=1;
    else
      error('Incorrect 5th input argument');
    end
  end
end

A=[sin(2*pi*t*f')cos(2*pi*t*f')];
if wtd
  N=A'*P*A;
else
  N=A'*A;
end
ind=(sum(N)>eps);
Cy=inv(N(ind,ind));
if wtd
  y=Cy*A(:,ind)'*P*x;
else
  y=Cy*A(:,ind)'*x;
end

m=length(f);
s=zeros(size(f));
for i=1:m
  if m>=100 & rem(i,100)==0
    disp([int2str(i),' of ',int2str(m),' frequencies processed']);
  end
  if (ind(i)~=0) & (ind(m+i)~=0)
    j=sum(ind(1:i));
    k=sum(ind(1:m+i));
    Ni=inv(Cy([j,k],[j,k]));
    yi=y([j,k]);
  elseif (ind(i)~=0) & (ind(m+i)==0)
    j=sum(ind(1:i));
    Ni=inv(Cy(j,j));
    yi=y(j);
  end
  s(i)=yi'*Ni*yi;
end
if m>=100 & rem(i,100)~=0
  disp([int2str(i),' of ',int2str(m),' frequencies processed']);
end

if norm
  if wtd
    xnorm=x'*P*x;  % Total power (= y'*inv(Cy)*y = y'*N*y)
  else
    xnorm=x'*x;
  end
  s=s./xnorm;      % Normalized spectrum
end
