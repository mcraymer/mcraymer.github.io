function [x,t,f]=hornedat
% Horne & Baliunas Test Data
%   Generates test data used by Horne & Baliunas
%   (1986) with x=0.75*cos(0.6 t) + r, where r is
%   Gaussian noise with variance 0.902.  Ten times
%   are randomly discarded.  Note that an angular
%   frequency of 0.6 is used so that f=2*pi/0.6.
%   The period is 10.47 time units.
% Version: 12 Oct 89
% Useage:  [x,t,f]=hornedata
% Input:   none
% Output:  x - time series values
%          t - time series times
t=[1:1000]';
rand('seed',0);
rand('uniform');
for i=1:100
  d=floor(rand(1)*length(t));
  t([d])=[];
end
rand('normal');
r=rand(length(t),1)*sqrt(0.902);
x=0.75*cos(0.6*t) + r;
df=1/100;
f=[df:df:50*df]';
