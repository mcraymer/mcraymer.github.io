function x=ilsft(y,f,t1,t2,P)
% Inverse Least Squares Fourier Transform for Independent
% Frequencies
%   Computes inverse least squares Fourier transform for a
%   given series of desired times. Ignores correlations among
%   frequencies (treats frequencies independently). Optionally
%   uses weighted normals from LSFT. See also ILSFTC, ILSFTE,
%   ILSFTEC.
% Version: 9 Jan 98
% Useage:  x=ilsft(y,f,t1,t2,P)
% Input:   y  - LS Fourier transform for frequecies
%               f and times t1
%          f  - spectral frequencies used in LSFT
%          t1 - data series "times" used in LSFT
%          t2 - data series "times" for inverse transform
%          P  - observation weight matrix of x used in LSFT (optional,
%               P=I default)
%               scalar => equal weights
%               vector => diagonal weight matrix without correlations
%               matrix => fully populated weight matrix with correlations
% Output:  x  - inverse transform for times t2

if nargin<4
  error('Too few input arguments');
elseif nargin==4
  P=1;
end

Pdim=size(P);
if Pdim==[1 1]
  Ptype='scalar';
else
  if Pdim(2)==1
    Ptype='vector';
  else
    Ptype='matrix';
  end
end

m=length(f);
x=zeros(size(t2));
for i=1:m
  A=[sin(2*pi*t1*f(i)) cos(2*pi*t1*f(i))];
  if Ptype=='scalar'
    N=A'*A;
  elseif Ptype=='vector'
    N=A'*( A'*( A.* kron(P,ones(1,nc)) ));
  elseif Ptype=='matrix'
    N=A'*P*A;
  end
  A=[sin(2*pi*t2*f(i)) cos(2*pi*t2*f(i))];
  indN=max(abs(N))>eps;
  if sum(indN')==1
    indf=i;
  else
    indf=[i m+i];
  end
%  disp(['i = ' int2str(i)]);  %debug
%  disp('indN ='); disp(indN);
%  disp('indf ='); disp(indf);
%  keyboard;
  x=x+A(:,indN)*(inv(N(indN,indN))*y(indf));
end
