function C=covmat(c,tlag,t,tol)
% COVMAT  Forms covariance/correlation matrix for times t for
%   a given autocovariance/autocorrelation function at lags
%   tlag. NOTE: time differences must match time lags within
%   specified tolerance (tol).
% Version: 7 Jun 97
% Usage:   C=covmat(c,tlag,t,tol)
% Input:   c - covariance/correlation function
%          tlag - time lags for cov/corr function
%          t - times for cov/corr matrix
%          tol - tolerance in matching time lags (optional)
%                (default=1e-10)
% Output:  C - covariance/correlation matrix

if nargin<3
  error('Too few input arguments')
elseif nargin<4
  tol=1e-10;
end

n=length(t);
C=zeros(n,n);
for i=1:n
  for j=1:i
    dt=t(i)-t(j);
    %disp([i j t(i) t(j) dt])
    ind=find(abs(tlag-dt)<tol);
    if ind==[]
      error(['No match found for i,j=' int2str(i) ',' int2str(j) ' tlag=' num2str(dt)]);
    end
    C(i,j)=c( find(abs(tlag-dt)<tol) ); %allow for roundoff error
    %C(i,j)=c(find(tlag==dt)); %doesn't allow for roundoff error
    C(j,i)=C(i,j);
  end
end
