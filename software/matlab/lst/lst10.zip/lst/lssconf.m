function sconf=lssconf(n,alpha,flag)
% Least Squares Spectrum Confidence Interval
%   Computes the confidence interval for an indepedently
%   estimated one-sided least squares spectral value
%   (2 degrees of freedom)at a given significance level.
%   Assumes variance factor unknown (estimated); uses F
%   dist'n.
% Version: 21 Feb 95
% Useage:  sconf=lssconf(n)
%          sconf=lssconf(n,alpha)
%          sconf=lssconf(n,alpha,'norm')
% Input:   n      - number of data series values
%          alpha  - vector of significance levels
%          'norm' - normalized spectrum flag
% Output:  sconf  - vector of spectral value conf. intervals
%                   corresponding to alpha

if nargin<1
  error('Too few input arguments')
elseif nargin==1
  alpha=0.05;     % 5% signif (default)
  norm=0;         % Unnormalized (default)
elseif nargin==2
  norm=0;         % Unnormalized (default)
elseif nargin==3
  if strcmp(flag,'norm')
    norm=1;
  else
    error('Invalid input normalized spectrum flag')
  end
end

v2=n-2;                    % 2nd deg. of freedom
F=(alpha^(-2/v2)-1)*v2/2;  % Approx. inverse F
if norm
  sconf=1/(1+1/(F*2/v2));  % Normalized spectrum
else
  sconf=2*F;               % Unnormalized spectrum
end
