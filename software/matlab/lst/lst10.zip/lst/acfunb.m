function acfu=acfunb(acfb,tlag)
% ACFCIRC  Computes unbiased autocovariance/autocorrelation
%   function from the biased estimate. Note that the biased
%   acf is a positive definite function (gives a pos. def.
%   matrix). The unbiased estimate is not necessarily pos.
%   def. Assumes equally spaced time lags.
% Version: 12 Feb 97
% Usage:   acfu=acfunb(acfc,tlag)
% Input:   acfc - biased estimate of acf
%          tlag - time lags (equally spaced)
% Output:  acfu - unbiased estimate of acf

if nargin<2
  error('Too few input arguments');
end

n=length(tlag);
dt=tlag(n)/(n-1);  % Lag increment (ave for unequal lags)
T=n*dt;
acfu=acfb*T./(T-tlag);
