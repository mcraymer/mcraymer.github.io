function y=lsfte(x,t,f,P)
% Least Squares Fourier Transform of Even
% Functions
%   Computes least squares Fourier transform of an even
%   function for a vector of desired frequencies.
% Version: 9 Jan 98
% Useage:  y=lsfte(x,t,f,P)
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
%          P - weight matrix of x (optional, P=I default)
%              scalar => equal weights
%              vector => diagonal weight matrix without correlations
%              matrix => fully populated weight matrix with correlations
% Output:  y - LS Fourier transform at frequecies f

if nargin<3
  error('Too few input arguments');
elseif nargin==3
  P=1;
end

Pdim=size(P);
if Pdim==[1 1]
  Ptype='scalar';
else
  if Pdim(2)==1
    Ptype='vector';
  else
    Ptype='matrix';
  end
end

A=cos(2*pi*t*f');
if Ptype=='scalar'
  y=A'*x;
elseif Ptype=='vector'
  y=A'*(x.*P);
elseif Ptype=='matrix'
  y=A'*P*x;
end
