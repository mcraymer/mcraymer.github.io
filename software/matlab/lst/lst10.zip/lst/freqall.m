function [f,fn]=freqall(t,fntype)
% Frequencies
%   Computes all (n-1) equally spaced, natural Fourier
%   frequencies based on the fundamental frequency (or
%   fundamental period) for both equally and unequally
%   spaced data.
%
%   *** NOTE *** Nyquist frequency is included in the
%   set of frequencies. Will cause singuarities if used
%   the correlated form of LS transform or spectrum
%   (Nyquist is not linearly independent of the zero
%   frequency).
%
% Version: 12 Feb 97
% Useage:  f=freqall(t,fntype)
% Input:   t      - vector of times
%          fntype - type of Nyquist freq. (optional)
%                   'nyq' = conventional Nyquist (default)
%                   'ave' = ave. Nyquist
%                   'med' = median Nyquist
%                   'max' = max. Nyquist
% Output:  f      - natural frequencies
%          fn     - Nyquist frequency (optional)
if nargin<1
  error('Too few input arguments');
elseif nargin==1
  fntype='nyq';
end
n=length(t);
fn=fnyquist(t,fntype);
df=fn/(n/2);
%f=[0:df:(n/2-1)*df]';  % Up to, but not including, Nyquist
f=[0:df:(n-1)*df]';   % All frequencies
