function [c,lags]=acfbin(x,t,nbins,opt)
% Autocovariance Function Using Lag Bins
%   Computes the autocovariance function of an unequally spaced
%   data series x with the mean removed. A smoothed estimate is
%   given using "nbins" equally spaced lag bins.  The unbiased
%   estimate is obtained by dividing the acf estimate by the
%   number of lag pairs in each lag bin. The biased estimate is
%   obtained by dividing each bin estimate by the total number
%   of points. The autocorrelation function is obtained from
%   this autocovariance function by dividing by c(1), the
%   autocovariance for lag zero (the variance).
% Version: 6 Jul 97
% Useage:  [c,lags]=acfbin(x,t,nbins)
%          [c,lags]=acfbin(x,t,nbins,'unbiased')
%          [c,lags]=acfbin(x,t,nbins,'biased')
% Input:   x - vector of data series values (n,1)
%          t - vector of data series times (n,1)
%          nbins - number of lag bins
%          'unbiased' - unbiased acf estimate (default)
%          'biased' - biased acf estimate
% Output:  c - autocovariance function (nbins,1)
%          lags - lags corresponding to bins (nbins,1)

if nargin<3
  error('Too few input arguments');
elseif nargin==3
  biased=0;
elseif nargin==4
  if strcmp(opt,'biased')
    biased=1;
  elseif strcmp(opt,'unbiased')
    biased=0;
  else
    error('Incorrect 4th input argument');
  end
end

n=length(x);
binwidth=(max(t)-min(t))/(nbins-1);
lags=[0:nbins-1]'*binwidth;
c=zeros(nbins,1);
nc=c;
c(1)=x'*x;
nc(1)=n;
for i=1:n-1
  dt=t(1+i:n)-t(1:n-i);
  xx=x(1+i:n).*x(1:n-i);
  for j=2:nbins
    ind=(dt>lags(j-1))&(dt<=lags(j));
    c(j)=c(j)+sum(xx(ind));
    nc(j)=nc(j)+sum(ind);
  end
end
%c(2:nbins)=c(2:nbins)-c(1:nbins-1);
%nc(2:nbins)=nc(2:nbins)-nc(1:nbins-1);
ind=find(nc==0);     % Find lags with no sums and
if sum(ind)~=0       % set corresponding c to zero
  c(ind)=0;          % and nc to 1 to avoid divide-
  nc(ind)=1;         % by-zero error
end
if biased
  c=c/n;
else
  c=c./nc;
end
