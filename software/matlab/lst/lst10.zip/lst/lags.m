function dt=lags(t,tol);
% LAGS  Finds all possible lags (differences) for arguments of a
% data series (usually time). Uses brute force algorithm (SLOW!).
% Version: 7 Jun 97
% Usage:   dt=lags(t,tol);
% Input:   t   - data series arguments (usually time)
%          tol - tolerance for equivalence of lags (default=eps)
% Output:  dt  - argument lags

if nargin<1
  error('No input arguments')
elseif nargin<2
  tol=eps;
end

%----- Brute-force algorithm (SLOW!)

%dt=[];
%for i=1:length(t)
%  if rem(i,10)==0
%    disp(['row ' int2str(i) ' of ' int2str(length(t))]);
%  end
%  for j=1:i
%    dtij=abs(t(j)-t(i));
%%   if all(dtij~=dt)
%    if all(abs(dtij-dt)>tol)
%      dt=[dt;dtij];
%      if rem(length(dt),100)==0
%        disp([int2str(length(dt)) ' lags found']);
%      end
%    end
%  end
%end
%disp([int2str(length(dt)) ' lags found']);
%dt=sort(dt);

%----- Vectorized algorithm

tt=kron(ones(1,length(t)),t);
dt=abs(tt-tt');
dt=sort(dt(:));
ind=find(abs(diff(dt))>tol);
dt=[0;dt(ind)];
