function c=acfw(x,P,opt)
% Weighted Autocovariance Function
%   Computes the weighted autocovariance function
%   of an evenly spaced data series x with the mean
%   removed.  The unbiased estimate is given,
%   scaled by 1/(N-k) where k is the lag, while the
%   biased estimate is scaled by 1/N.  The
%   autocorrelation function is obtained by
%   dividing the acf by c(1), the autocov. for lag
%   zero.
% Version: 6 Jul 97
% Useage:  c=acfw(x,P)
%          c=acfw(x,P,'biased')
%          c=acfw(x,P,'unbiased')
% Input:   x  - data series values (n,1)
%          P  - weight matrix for x
%          'biased' - compute biased estimate of ACF
%          'unbiased' - compute biased estimate of ACF
%               (default)
% Output:  c  - autocovariance function (n,1)

% NOTE: Should probably use (df-k) as divisor for
% unbiased estimate, where df = degrees of freedom.

if nargin<2
  error('Too few input arguments');
elseif nargin==2
  biased=0;
elseif nargin==3
  if strcmp(opt,'biased')
    biased=1;
  elseif strcmp(opt,'unbiased')
    biased=0;
  else
    error('Invalid 3rd argument');
  end
end

n=length(x);
c=zeros(n,1);

if biased
  for k=0:n-1
    c(k+1) = x(1:n-k)'*P(1:n-k,1+k:n)*x(1+k:n)/n;
  end
else
  for k=0:n-1
    c(k+1) = x(1:n-k)'*P(1:n-k,1+k:n)*x(1+k:n)/(n-k);
  end
end
