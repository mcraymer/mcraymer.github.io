function s=dfsc(x,t,f,opt)
% Discrete Fourier Spectrum w/ Correlations
%   Computes one-sided spectral density function for a given set
%   of integer Fourier frequencies using the DFT. Uses complex
%   notation. Accounts for correlations between frequencies (i.e.,
%   frequencies above Nyquist will produce singularities).
% Version: 8 Feb 97
% Useage:  s=dfsc(x,t,f)
%          s=dfsc(x,t,f,'norm')
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
%          'norm' - flag to normalize spectrum
% Output:  s - spectral values at frequecies f

if nargin==3
  norm=0;
elseif nargin==4
  if strcmp(opt,'norm')
    norm=1;
  else
    error(['Invalid input argument ' opt]);
  end
elseif nargin<3
  error('Too few input arguments')
end

A=exp(i*2*pi*t*f');
N=real(A'*A);
%----- Loop algorithm
%y=N\(A.'*x);
%s=zeros(size(f));
%for i=1:length(f)
%  s(i)=y(i)'*N(i,i)*y(i);
%end
%----- Vectorized algorithm
y=A.'*x;           % Complex matrix DFT
s=N\(y.*conj(y));  % Complex two-sided DFS
%----- Normalize spectrum
s=[s(1);s(2:length(s))*2];   % One-sided DFS
if norm
  %s=s./sum(s);    % Normalized spectrum
  xnorm=x'*x;      % Total power
  s=s./xnorm;      % Normalized spectrum
end
