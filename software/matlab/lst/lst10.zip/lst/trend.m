function [b,Cb,r]=trend(x,t,ndat,idat,lt,nper,per,P)
% Least Squares Trend Estimation
%   Computes least squares estimates of trend model defined
%   by datum biases, common linear trend, and periodic
%   components. Returns parameter estimates, their covariance
%   matrix and the residuals after trend removal.
% Version: 12 Jun 97
% Useage:  [b,Cb,r]=trend(x,t,ndat,idat,lt,nper,per,P)
% Input:   x    - data series values (observations or dependent
%                 variable)
%          t    - data series "times" (independent variable)
%          ndat - number of datum biases
%          idat - indices in x for start of datum biases
%          lt   - linear trend switch (0=off,1=on)
%          nper - number of forced periods
%          per  - forced periods in units of x
%          P    - weight matrix of observations x (optional, default
%                 P=I)
% Output:  b    - estimated trend parameters (in order: biases,
%                 linear trend, cos & sin coefficients)
%          Cb   - estimated covariance matrix of parameters
%          r    - x residuals after removing known constituents

if nargin<7
  error('Too few input arguments');
elseif nargin==7
  P=eye(length(x));
end

n=length(t);
m=ndat+lt+nper*2;

%----- Form design matrix
A=zeros(n,m);
for i=1:ndat
  if i<ndat
    ind=(idat(i):idat(i+1)-1);
  else
    ind=(idat(i):n);
  end
  A(ind,i)=ones(length(ind),1);
end
if lt==1
  A(:,ndat+1)=t-min(t);
end
for i=1:nper
  if per(i)==0
    error('Zero period linear combination of constant biases');
  end
  ind=ndat+lt+(i-1)*2+[1 2];
  A(:,ind)=[cos(2*pi/per(i)*t) sin(2*pi/per(i)*t)];
end

%----- Form and solve normal equations
Cb=inv(A'*P*A);
b=Cb*A'*P*x;

%----- Compute residuals and Cov matrix
r=x-A*b;
rnorm=r'*P*r;
vf=rnorm/(n-m);
Cb=vf*Cb;
