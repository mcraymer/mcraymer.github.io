function [x,xstd]=ilsfte(y,f,t1,t2,P)
% Inverse Least Squares Fourier Transform of Even Functions
% for Independent Frequencies
%   Computes inverse least squares Fourier transform of an even
%   function for a given series of desired times. Ignores
%   correlations among frequencies (treats frequencies
%   independently). Optionally uses weighted normals from LSFT.
%   See also ILSFT, ILSFTC, ILSFTEC.
% Version: 9 Jan 98
% Useage:   [x,xstd]=ilsfte(y,f,t1,t2,P)
% Input:   y  - LS Fourier transform for frequecies f and
%               times t1
%          f  - spectral frequencies used in LSFT
%          t1 - data series "times" used in LSFT
%          t2 - data series times for inverse transform
%          P  - observation weight matrix of x used in LSFT (optional,
%               P=I default)
%               scalar => equal weights
%               vector => diagonal weight matrix without correlations
%               matrix => fully populated weight matrix with correlations
% Output:  x  - inverse transform for times t2
%          xstd - standard deviations of inverse transform values

if nargin<4
  error('Too few input arguments');
elseif nargin==4
  P=1;
end
status=0;

Pdim=size(P);
if Pdim==[1 1]
  Ptype='scalar';
else
  if Pdim(2)==1
    Ptype='vector';
  else
    Ptype='matrix';
  end
end

if status, disp('Forming time design matrix...'); end
A=cos(2*pi*t1*f');

if status, disp('Forming normal equation matrix...'); end
m=length(f);
N=zeros(m,1);
if Ptype=='scalar'
  %N=diag(A'*A);
  for i=1:m
    N(i)=A(:,i)'*A(:,i);
  end
elseif Ptype=='vector'
  N=diag(A'*( A'*(A.* kron(P,ones(1,nc)) )));
elseif Ptype=='matrix'
  N=diag(A'*P*A);
end

if status, disp('Forming lag design matrix...'); end
clear A
A=cos(2*pi*t2*f');

if status, disp('Computing ilsft...'); end
x=A*(y(1:length(f))./N);

if nargout==2
  %disp('Computing stds of ilsft...');
  Ninv=1.0./N;
  xstd=zeros(size(t2));
  for i=1:length(t2)
    xstd(i)=A(i,:)*diag(Ninv)*A(i,:)';
  end
  xstd=sqrt(xstd);
end
