function c=acf(x,opt)
% Autocovariance Function
%   Computes the autocovariance function of an evenly spaced
%   data series x with the mean removed. Unbiased estimate is
%   scaled by 1/(N-k) where k is the lag.  The biased estimate
%   is scaled by 1/N. The autocorrelation function can be
%   obtained by dividing by c(1), the autocov. for lag zero.
% Version: 6 Jul 97
% Usage:  c=acf(x)
%         c=acf(x,'biased')
%         c=acf(x,'unbiased')
% Input:   x - data series values (n,1)
%          'biased' - flag to give the biased estimate (scaled
%              by 1/N)
%          'unbiased' - flag to give the unbiased estimate
%              (scaled by 1/(N-lag))
% Output:  c - autocovariance function (n,1); by default the
%              unbiased estimate is given.

if nargin<1
  error('Too few input arguments');
elseif nargin==1
  biased=0;
elseif nargin==2
  if strcmp(opt,'biased')
    biased=1;
  elseif strcmp(opt,'unbiased')
    biased=0;
  else
    error('Invalid second argument');
  end
end

n=length(x);
c=zeros(n,1);

if biased
  for k=0:n-1
    c(k+1) = x(1:n-k)'*x(1+k:n)/n;
  end
else
  for k=0:n-1
    c(k+1) = x(1:n-k)'*x(1+k:n)/(n-k);
  end
end
