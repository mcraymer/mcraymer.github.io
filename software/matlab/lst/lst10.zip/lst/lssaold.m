function [s,b,Cb,r]=lssa(x,t,P,ndat,idat,lt,nper,per,f,stat)
% Least Squares Spectral Analysis
%   Computes least squares (one-sided) spectral density
%   function for a vector of desired frequencies using
%   the sequential algorithm. Ignores correlations among
%   frequencies.
% Version: 12 Oct 97
% Useage:  [s,b,Cb,r]=lssa(x,t,P,ndat,idat,lt,nper,per,f,stat)
% Input:   x    - data series values
%          t    - data series "times"
%          P    - weight matrix of x
%                 scalar => equal weights
%                 vector => diagonal weight matrix without correlations
%                 matrix => fully populated weight matrix with correlations
%          ndat - number of datum biases
%          idat - indices for start of datum biases
%          lt   - linear trend switch (0=off,1=on)
%          nper - number of forced periods
%          per  - forced periods
%          f    - spectral frequencies
%          stat - status display flag (0=don't display, 1=display)
% Output:  s    - spectral values at frequecies f
%          b    - estimated coefficients
%          Cb   - estimated covariancem matrix of estimated coefficients
%          r    - x residuals after removing known constituents
if nargin<9
  error('Too few input arguments');
elseif nargin==9
  stat=0;
elseif nargin==10
  if stat~=0 & stat~=1
    error('Incorrect stat input argument');
  end
end
Pdim=size(P);
if Pdim==[1 1]
  Ptype='scalar';
else
  if Pdim(2)==1
    Ptype='vector';
  else
    Ptype='matrix';
  end
end
n=length(t);
nc=ndat+lt+nper*2;
nw=length(f);
%--------------- Compute known constituents
if nc>0
%----- Design matrix
A1=zeros(n,nc);
for i=1:ndat
  if i<ndat
    ind=(idat(i):idat(i+1)-1);
  else
    ind=(idat(i):n);
  end
  A1(ind,i)=ones(length(ind),1);
end
if lt==1
  A1(:,ndat+1)=t-min(t);
end
for i=1:nper
  if per(i)==0
    error('Zero period linear combination of constant biases');
  end
  ind=ndat+lt+(i-1)*2+[1 2];
  A1(:,ind)=[cos(2*pi/per(i)*t) sin(2*pi/per(i)*t)];
end
%----- Normal matrix
if Ptype=='scalar'
  Ninv=inv(A1'*A1);
elseif Ptype=='vector'
  Ninv=inv(A1'*(A1.* kron(P,ones(1,nc)) ));
elseif Ptype=='matrix'
  Ninv=inv(A1'*P*A1);
end
%----- Estimated constituents & residuals
if Ptype=='scalar'
  b=Ninv*A1'*x;
elseif Ptype=='vector'
  b=Ninv*A1'*(x.*P);
elseif Ptype=='matrix'
  b=Ninv*A1'*P*x;
end
r=x-A1*b;
%----- Variance factor & covariance matrix
if Ptype=='scalar'
  rnorm=r'*r;
elseif Ptype=='vector'
  rw=r.*P;
  rnorm=r'*rw;
elseif Ptype=='matrix'
  rnorm=r'*P*r;
end
vf=rnorm/(n-nc);
Cb=vf*Ninv;
%----- List results
if nc>0 & nargout<2 & stat==1
  disp(' ');
  disp('Known constituents & estimated std.');
  disp([b,sqrt(diag(Cb))])
end

else      % no constituents
  r=x;
  A1=zeros(n,1);
  Ninv=0;
  rnorm=r'*r;
end
%--------------- Compute spectrum of residual series
s=zeros(nw,1);
for i=1:nw
  if rem(i,100)==0 & stat==1
    disp([int2str(i),' of ',int2str(nw),' frequencies processed']);
  end
  if f(i)==0 & ndat>0
    s(i)=0;
  else
    A2=[cos(2*pi*f(i)*t) sin(2*pi*f(i)*t)];  % won't work for f=0
    if Ptype=='scalar'
      N12=A1'*A2;
      N22=A2'*A2;
      M22=inv(N22-N12'*Ninv*N12);
      b2=A2'*r;
    elseif Ptype=='vector'
      N12=A1'*(A2.*[P P]);
      N22=A2'*(A2.*[P P]);
      M22=inv(N22-N12'*Ninv*N12);
      b2=A2'*rw;
    elseif Ptype=='matrix'
      N12=A1'*P*A2;
      N22=A2'*P*A2;
      M22=inv(N22-N12'*Ninv*N12);
      b2=A2'*P*r;                  %IS P INCLUDED HERE TOO ????
    end
    s(i)=b2'*M22*b2 / rnorm;
  end
end
if rem(i,100)~=0 & stat==1
  disp([num2str(nw),' of ',int2str(nw),' frequencies processed']);
end
