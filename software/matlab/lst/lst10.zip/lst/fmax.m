function max=fmax(t)
% Maximum Frequency
%   Computes maximum frequency for a given time
%   series.  Nyquist frequency for evenly spaced
%   data or frequency for 2 times 2nd smallest
%   time interval for unevenly spaced data.
% Version: 30 Nov 89
% Useage:  fmax=fmax(t)
% Input:   t    - data series "times"
% Output:  fmax - maximum spectral frequency
n=length(t);
dt=sort(t([2:n])-t([1:n-1]));
max=1.0./(2*dt(n-2));
