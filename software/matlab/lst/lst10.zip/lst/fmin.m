function min=fmin(t)
% Minimum Frequency
%   Computes minimum frequency for a given time
%   series
% Version: 12 Sep 89
% Useage:  min=fmin(t)
% Input:   t    - data series "times"
% Output:  fmin - minimum spectral frequency
n=length(t);
min=1.0./(t(n)-t(1));
