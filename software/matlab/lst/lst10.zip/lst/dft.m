function y=dft(x,t,f)
% Discrete Fourier Transform
%   Computes the discrete Fourier transform for a vector of
%   desired frequencies.
% Version: 9 Jan 98
% Useage:  y=dft(x,t,f)
% Input:   x - data series values
%          t - data series times
%          f - frequencies
% Output:  y - DFT at frequecies f

if nargin<3
  error('Too few input arguments');
end

i=sqrt(-1);

% Traditional summation form
%n=length(t);
%m=length(f);
%y=zeros(n,1);
%k=[0:n-1]';
%for j=0:n-1
%  y(j+1)=sum(x.*exp(i*2*pi*j*k/n));
%end

% Complex exp. vector form
%m=length(f);
%y=zeros(n,1);
%for j=1:m
%  y(j)=sum(x.*exp(i*2*pi*f(j)*t));
%end

% Complex exp. matrix form
A=exp(i*2*pi*t*f');
y=A.'*x;     % Non-conjugate transpose

% Trig. matrix form = LSFT
%A=[cos(2*pi*t*f') sin(2*pi*t*f')];
%y=A'*x;
