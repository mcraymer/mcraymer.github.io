function [s,f]=ffsall(x,t,opt)
% Fast Fourier Spectrum
%   Computes a two-sided spectral density function for the set
%   of all integer Fourier frequencies using the FFT.  Uses
%   complex notation.
% Version: 12 Feb 97
% Useage:  f=ffsall(x,t)
%          f=ffsall(x,t,'norm')
%          [s,f]=ffsall(x,t)
%          [s,f]=ffsall(x,t,'norm')
% Input:   x - data series values
%          t - data series "times"
%          'norm' - optional flag to normalize spectrum
% Output:  s - fft spectrum
%          f - integer frequencies (all possible)

if nargin==2
  norm=0;
elseif nargin==3
  if strcmp(opt,'norm')
    norm=1;
  else
    error(['Invalid input argument ' opt]);
  end
elseif nargin<2
  error('Too few input arguments')
end

if all(diff(diff(t)))==0
  dt=t(2)-t(1);
else
  error('Input times (t) not equally spaced');
end

n=length(x);
f=(0:n-1)'./(dt*n);   % Up to nyquist freq only
y=fft(x);
s=y.*conj(y)/n;       % Two-sided spectrum
if norm
  xnorm=sum(s);       % Total power
  s=s./xnorm;         % Normalized spectrum
end
