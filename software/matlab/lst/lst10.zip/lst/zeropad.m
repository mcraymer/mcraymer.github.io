function [xpad,tpad]=zeropad(x,t)
% ZEROPAD  Pads a time series (t,x) with equally spaced zero
%   values to double the original series length.
% Version: 8 Jun 97
% Usage:   [xpad,tpad]=zeropad(x,t)
% Input:   x - original series values (can input multiple series
%              where each series is a column of matrix x)
%          t - original series times
% Output:  xpad - zero-padded series values
%          tpad - zero-padded series times

if nargin<2
  error('Too few input parameters');
end

[n,m]=size(x);
xpad=[x;zeros(n,m)];
dt=(max(t)-min(t))/(n-1);
tpad=[t;max(t)+(dt:dt:n*dt)'];
