function [x,t]=gendat(n,spacing,series,w)
% Generate Data
%    Generates equally or unequally spaced time
%    series test data
% Version: 22 Jan 97
% Useage:  [x,t]=gendat(n,spacing,series,w)
% Input:   n       - number of data points
%          spacing - series spacing
%                    1=equal
%                    2=unequal (uniform)
%                    3=unequal (Gaussian)
%          series  - type of series
%                    1=random
%                    2=sine
%                    3=sine + random
%                    4=linear trend
%                    5=linear trend + random
%                    6=quadratic
%                    7=quadratic + random
%                    8=exponential
%                    9=exponential + random
%          w       - row-vector of frequencies of sine series (optional)
% Output:  x       - time series values
%          t       - time series "times"
if nargin==3
  w=0;
end
if spacing == 1
  t = [1:n]';
elseif spacing == 2
  rand('uniform');
  t = rand(n,1)*n;
elseif spacing == 3
  rand('normal');
  t = rand(n,1)*n;
end
%if series > 1
%  w = input('Frequency of periodic component > ');
%end
rand('normal');
if series==1
  x = rand(n,1)/2;
elseif series==2
  x = sin(2*pi*kron(w,t));
elseif series==3
  x = sum(sin(2*pi*kron(w,t)'))' + rand(n,1)/2;
elseif series==4
  x = 0.1*t;
elseif series==5
  x = 0.1*t + rand(n,1);
elseif series==6
  x = 0.001*t.*t;
elseif series==7
  x = 0.001*t.*t + rand(n,1);
elseif series==8
  x = exp(t/20);
elseif series==9
  x = exp(t/20) + rand(n,1)*2;
end
if spacing == 2
  [t,i] = sort(t);
  x = x(i);
end
