function [s,b,Cb,r]=lssaz(x,t,P,ndat,idat,lt,nper,per,f,norm,stat)
% Least Squares Spectral Analysis with Zero-Padding
%   Computes least squares (one-sided) spectral density
%   function for a vector of desired frequencies using
%   the sequential algorithm. Optionally includes a priori
%   bias, linear, period trends. Zero-pads residual series
%   prior to computing spectrum. Ignores correlations
%   among frequencies.
% Version: 9 Jan 98
% Usage:   [s,b,Cb,r]=lssa(x,t,P,ndat,idat,lt,nper,per,f,norm,stat)
% Input:   x    - data series values
%          t    - data series "times"
%          P    - weight matrix of x
%                 scalar => equal weights
%                 vector => diagonal weight matrix without correlations
%                 matrix => fully populated weight matrix with correlations
%          ndat - number of datum biases
%          idat - indices for start of datum biases
%          lt   - linear trend switch (0=off,1=on)
%          nper - number of forced periods
%          per  - forced periods
%          f    - spectral frequencies
%          norm - spectrum normalization flag (0=don't, 1=normalize);
%                 default=1
%          stat - status display flag (0=don't display, 1=display);
%                 default=0
% Output:  s    - spectral values at frequecies f
%          b    - estimated a priori model coefficients
%          Cb   - estimated covariance matrix of estimated coefficients
%          r    - x residuals after removing known constituents
if nargin<9
  error('Too few input arguments');
elseif nargin==9
  norm=1;
  stat=0;
elseif nargin==10
  if norm~=0 & norm~=1
    error('Incorrect input argument: norm');
  end
  stat=0;
elseif nargin==11
  if norm~=0 & norm~=1
    error('Incorrect input argument: norm');
  end
  if stat~=0 & stat~=1
    error('Incorrect input argument: stat');
  end
end

Pdim=size(P);
if Pdim==[1 1]
  Ptype='scalar';
else
  if Pdim(2)==1
    Ptype='vector';
  else
    Ptype='matrix';
  end
end

n=length(t);
nc=ndat+lt+nper*2;
nw=length(f);

%--------------- Compute known constituents
if nc>0
%----- Design matrix
A1=zeros(n,nc);
for i=1:ndat
  if i<ndat
    ind=(idat(i):idat(i+1)-1);
  else
    ind=(idat(i):n);
  end
  A1(ind,i)=ones(length(ind),1);
end
if lt==1
  A1(:,ndat+1)=t-min(t);
%  A1(:,ndat+1)=t;
end
for i=1:nper
  if per(i)==0
    error('Zero period (infinite frequency) undefined - use datum bias instead');
  end
  ind=ndat+lt+(i-1)*2+[1 2];
  A1(:,ind)=[sin(2*pi/per(i)*t) cos(2*pi/per(i)*t)];
end
%----- Normal matrix
if Ptype=='scalar'
  N1inv=inv(A1'*A1);
elseif Ptype=='vector'
  N1inv=inv(A1'*(A1.* kron(P,ones(1,nc)) ));
elseif Ptype=='matrix'
  N1inv=inv(A1'*P*A1);
end
%----- Estimated parameters
if Ptype=='scalar'
  b=N1inv*A1'*x;
elseif Ptype=='vector'
  b=N1inv*A1'*(x.*P);
elseif Ptype=='matrix'
  b=N1inv*A1'*P*x;
end
end
%----- Model residuals
if nc>0
  r=x-A1*b;
else
  r=x;
end
%----- Variance factor & covariance matrix
if Ptype=='scalar'
  rnorm=r'*r;
elseif Ptype=='vector'
  rnorm=r'*(r.*P);
elseif Ptype=='matrix'
  rnorm=r'*P*r;
end
if nc>0
  vf=rnorm/(n-nc);
  Cb=vf*N1inv;
end
%----- List results
if nc>0 & nargout<2 & stat==1
  disp(' ');
  disp('Estimated a priori model parameters & std.');
  disp([b,sqrt(diag(Cb))])
end

%--------------- Zero-pad residuals
[r,t]=zeropad(r,t);
A1=[A1;zeros(size(A1))];
if Ptype=='vector'
  P=[P;zeros(size(P))];
elseif Ptype=='matrix'
  P=[P zeros(size(P)); zeros(size(P)) zeros(size(P))];
end

%--------------- Compute spectrum of residual series
s=zeros(nw,1);
for i=1:nw
  if rem(i,100)==0 & stat==1
    disp([int2str(i),' of ',int2str(nw),' frequencies processed']);
  end
  if f(i)==0 & ndat>0
    s(i)=NaN;
  else
    if f(i)==0
      A2=cos(2*pi*f(i)*t);
    else
      A2=[sin(2*pi*f(i)*t) cos(2*pi*f(i)*t)];
    end
    if Ptype=='scalar'
      if nc>0
        N12=A1'*A2;
        N22=A2'*A2;
        M22=inv(N22-N12'*N1inv*N12);
      else
        N22=A2'*A2;
        M22=inv(N22);
      end
      F=A2'*r;  %LS transform
    elseif Ptype=='vector'
      if nc>0
        N12=A1'*(A2.*[P P]);
        N22=A2'*(A2.*[P P]);
        M22=inv(N22-N12'*N1inv*N12);
      else
        N22=A2'*(A2.*[P P]);
        M22=inv(N22);
      end
      F=A2'*(r.*P);  %LS transform
    elseif Ptype=='matrix'
      if nc>0
        N12=A1'*P*A2;
        N22=A2'*P*A2;
        M22=inv(N22-N12'*N1inv*N12);
      else
        N22=A2'*P*A2;
        M22=inv(N22);
      end
      F=A2'*P*r;  %LS transform
    end

    if norm==0
      s(i)=F'*M22*F;
    else
      s(i)=(F'*M22*F) / rnorm;
    end
  end
end
if rem(i,100)~=0 & stat==1
  disp([num2str(nw),' of ',int2str(nw),' frequencies processed']);
end
