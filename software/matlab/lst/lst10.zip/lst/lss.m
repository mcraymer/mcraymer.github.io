function s=lss(x,t,f,opt1,opt2)
% Least Squares Spectrum for Independent Frequencies
%   Computes one-sided least squares spectral values for a
%   for a given weighted data series and set of frequencies.
%   Ignores correlations among frequencies (treats frequencies
%   independently). Optionally weights observation data series.
%   See also LSSC (for correlated frequencies).
% Version: 9 Jan 98
% Useage:  s=lss(x,t,f)
%          s=lss(x,t,f,'norm')
%          s=lss(x,t,f,P)
%          s=lss(x,t,f,P,'norm')
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
%          P - observation weight matrix (optional, P=I
%              default)
%          'norm' - flag to normalize spectrum
% Output:  s - spectral values at frequecies f

if nargin<3
  error('Too few input arguments');
elseif nargin==3
    P=eye(length(x));
    wtd=0;  %weigted soln flag (0=unwtd,1=wtd)
    norm=0; %normalized spectrum flag (0=unnorm,1=norm)
elseif nargin==4
  if isstr(opt1)
    %P=eye(length(x));
    wtd=0;
    if strcmp(opt1,'norm')
      norm=1;
    else
      error('Invalid 4th input argument');
    end
  else
    P=opt1;
    wtd=1;
    norm=0;
  end
elseif nargin==5
  P=opt1;
  wtd=1;
  if isstr(opt2)
    if strcmp(opt2,'norm')
      norm=1;
    else
      error('Invalid 5th input argument');
    end
  end
end

m=length(f);
s=zeros(size(f));
for i=1:m
  if m>=100 & rem(i,100)==0
    disp([int2str(i),' of ',int2str(m),' frequencies processed']);
  end
  A=[sin(2*pi*f(i)*t) cos(2*pi*f(i)*t)];
  if wtd
    N=A'*P*A;
  else
    N=A'*A;
  end
  ind=(sum(abs(N))>eps);
  if wtd
    F=A(:,ind)'*P*x;
  else
    F=A(:,ind)'*x;
  end
  s(i)=F'*inv(N(ind,ind))*F;
end
if m>=100 & rem(i,100)~=0
  disp([int2str(i),' of ',int2str(m),' frequencies processed']);
end

if norm
  if wtd
    xnorm=x'*P*x;   %Total power (quadratic form)
  else
    xnorm=x'*x;     %Total power (quadratic form)
  end
  s=s./xnorm;    % Normalized spectrum
end
