function fn=fnyquist(t,fntype)
% Nyquist Frequency
%   Computes the Nyquist frequency from a vector of
%   either equally or unequally spaced times.
% Version: 21 Feb 97
% Useage:  fn=fnyquist(t,fntype)
% Input:   t  - data series times
%          fntype - type of Nyquist freq. (optional)
%               'nyq' = conventional Nyquist based on
%                       fundamental period (default)
%               'ave' = average
%               'med' = median
%               'max' = maximum
% Output:  fn - Nyquist frequency

if nargin<1
  error('Too few input arguments');
elseif nargin==1
  fntype='nyq'
end

t=sort(t);
if fntype=='nyq'          % Conventional Nyquist (default)
  n=length(t);
  To=t(n)-t(1);
  %fn=1/(2*To/(n-1));
  fn=(n-1)/(2*To);
elseif fntype=='ave'      % Average
  n=length(t);
  dt2=t(3:n)-t(1:n-2);
  fn=1/mean(dt2);
elseif fntype=='med'      % Median
  n=length(t);
  dt2=t(3:n)-t(1:n-2);
  fn=1/median(dt2);
elseif fntype=='max'      % Maximum
  n=length(t);
  dt2=t(3:n)-t(1:n-2);
  fn=1/min(dt2);
else
  error('Unknown type of nyquist frequency');
end
