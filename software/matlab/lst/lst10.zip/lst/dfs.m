function s=dfs(x,t,f,opt)
% Discrete Fourier Spectrum w/o Correlations
%   Computes one-sided spectral density function for a given set
%   of integer Fourier frequencies using the DFT.  Uses complex
%   notation. Ignores correlations among frequencies (i.e.,
%   frequencies above Nyquist frequency will *NOT* produce
%   singularities).
% Version: 8 Feb 97
% Useage:  s=dfs(x,t,f)
%          s=dfs(x,t,f,'norm')
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
%          'norm' - flag to normalize spectrum
% Output:  s - spectral values at frequecies f

if nargin==3
  norm=0;
elseif nargin==4
  if strcmp(opt,'norm')
    norm=1;
  else
    error(['Invalid input argument ' opt]);
  end
elseif nargin<3
  error('Too few input arguments');
end

n=length(t);
A=exp(i*2*pi*t*f');
y=A.'*x;
s=y.*conj(y)*2/n;  % One-sided spectrum
s(1)=s(1)/2;       % Zero freq not doubled
if norm
  xnorm=x'*x;      % Total power
  s=s./xnorm;      % Normalized spectrum
end
