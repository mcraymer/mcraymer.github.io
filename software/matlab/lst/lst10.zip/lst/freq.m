function [f,fn]=freq(t,fntype)
% Frequencies
%   Computes all (n-1) equally spaced, natural Fourier
%   frequencies based on the fundamental frequency (or
%   fundamental period) for both equally and unequally
%   spaced data.
%
%   *** NOTE *** Do not include Nyquist frequency in
%   set of frequencies if using correlated form of
%   LS transform or spectrum (Nyquist is not linearly
%   independent of the zero frequency).
%
% Version: 21 Feb 97
% Useage:  f=freq(t,fntype)
% Input:   t      - vector of times
%          fntype - type of Nyquist freq. (optional)
%                   'nyq' = conventional Nyquist (default)
%                   'ave' = ave. Nyquist
%                   'med' = median Nyquist
%                   'max' = max. Nyquist
% Output:  f      - natural frequencies
%          fn     - Nyquist frequency (optional)

if nargin<1
  error('Too few input arguments');
elseif nargin==1
  fntype='nyq';
end

n=length(t);
fn=fnyquist(t,fntype);
df=fn*2/n;
f=[0:df:(n/2-1)*df]';  % Up to, but not including, Nyquist
%f=[0:df:(n-1)*df]';   % All frequencies
