function s=lss(x,t,f,opt1)
% Least Squares Spectrum for Independent Frequencies
% (Unweighted Conventional Form)
%   Computes one-sided least squares spectral values for a
%   for a given data series and set of frequencies. Ignores
%   correlations among frequencies (treats frequencies
%   independently). Observation data is equally weighted.
%   See also LSSC (for correlated frequencies).
% Version: 21 Jun 97
% Useage:  s=lss(x,t,f)
%          s=lss(x,t,f,'norm')
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
%          'norm' - flag to normalize spectrum
% Output:  s - spectral values at frequecies f

if nargin<3
  error('Too few input arguments');
elseif nargin==3
  norm=0;
elseif nargin==4
  if strcmp(opt1,'norm')
    norm=1;
  else
    error('Invalid 4th input argument');
  end
end

m=length(f);
s=zeros(size(f));
for i=1:m
  if m>100 & rem(i,100)==0
    disp([int2str(i),' of ',int2str(m),' frequencies processed']);
  end
  A=[cos(2*pi*f(i)*t) sin(2*pi*f(i)*t)];
  N=A'*A;
  ind=(sum(N)>eps);
  F=A(:,ind)'*x;
  s(i)=F'*inv(N(ind,ind))*F;
end
if m>100 & rem(i,100)~=0
  disp([int2str(i),' of ',int2str(m),' frequencies processed']);
end

if norm
  xnorm=x'*x;  % Total power (= sum(yi'*inv(Cyi)*yi)
  s=s./xnorm;  % Normalized spectrum
end
