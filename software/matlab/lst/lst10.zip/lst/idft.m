function x=idft(y,f,t)
% Inverse Discrete Fourier Transform
%   Computes the inverse discrete Fourier transform for a vector
%   of desired frequencies.
% Version: 9 Jan 98
% Useage:  x=idft(y,f,t)
% Input:   y - DFT at frequecies f
%          f - frequencies
%          t - data series times (must be same as times used in DFT)
% Output:  x - data series values

if nargin<3
  error('Too few input arguments');
end

i=sqrt(-1);

% Tradiational form
%n=length(t);
%m=length(f);
%x=zeros(n,1);
%k=[0:n-1]';
%for j=0:n-1
%  x(j+1)=sum(y.*exp(-i*2*pi*j*k/n))/n;
%end

% Complex exp. vector form
%m=length(f);
%x=zeros(n,1);
%for j=1:m
%  x(j)=sum(y.*exp(-i*2*pi*f*t(j)))/n;
%end

% Complex exp. matrix form
A=exp(-i*2*pi*t*f');
x=A*inv(A'*A)*y;    % inv(A'*A)=diag(1/n)
%x=A*y/n;

% Trig. matrix form = ILSFT
%A=[cos(2*pi*t*f') sin(2*pi*t*f')];
%x=A*inv(A'*A)*y;  % singular (ILSFT approach)
%x=A*y/n;
%ind1=sum(A)~=0;               %
%ind2=(f<fnyquist(t,'ave'))';  %
%ind2=[ind2 ind2];             % ILSFT
%ind=ind1&ind2;                %
%A=A(:,ind);                   %
%x=A*inv(A'*A)*y(ind);         %
