function dx=range(x)
% RANGE  Returns range (max-min) of a data series.
% Version: 8 Jun 97
% Usage:   dx=range(x)
% Input:   x - original series values (can input multiple series
%              where each series is a column of matrix x)
% Output:  dx - range (max-min) of x

if nargin<1
  error('Too few input parameters');
end

dx=max(x)-min(x);
