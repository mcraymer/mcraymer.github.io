function p=lomb(x,t,f)
% Lomb's Normalized Periodogram
%   Computes the normalized periodogram as defined
%   by Lomb (1976) for a given vector of
%   frequencies.
% Version: 13 Oct 89
% Useage:  p=lomb(x,t,f)
% Input:   x - data series values
%          t - data series "times"
%          f - spectral frequencies
% Output:  p - periodogram values at frequecies f
t1=clock;
n=length(f);
p=zeros(f);
r=x'*x;
for i=1:n
  sums=sum(sin(4*pi*f(i)*t));
  sumc=sum(cos(4*pi*f(i)*t));
  tau=atan(sums/sumc)/(4*pi*f(i));
  c=cos(2*pi*f(i)*(t-tau));
  s=sin(2*pi*f(i)*(t-tau));
  xc=x'*c;
  xs=x'*s;
  cc=c'*c;
  ss=s'*s;
  p(i)=(xc*xc/cc + xs*xs/ss)/r;
  if (i/10-floor(i/10)) == 0
    disp([num2str(i),' of ',num2str(n),...
         ' frequencies processed']);
  end
end
dt=etime(clock,t1);
disp([num2str(n),' frequencies processed']);
disp(['Elapsed time = ',num2str(dt),' seconds']);
