function C=covmate(c)
% COVMATE  Forms covariance/correlation matrix corresponding
%   to a covariance function for equally spaced time lags.
%   times.
% Version: 7 Jun 97
% Usage:   C=covmate(c)
% Input:   c - covariance/correlation function (equally spaced
%              time lags)
% Output:  C - covariance/correlation matrix

if nargin<1
  error('Too few input arguments')
end

n=length(c);
C=zeros(n,n);
for i=1:n
  C(:,i)=c(abs((1:n)-i)+1);
end
