function b=blanka(m,n)
% BLANKA  Creates an mxn array of blanks. Modified from MATLAB
%   function BLANKS.
% Version: 1996-01-23
% Useage:  b=blanka(m,n)
% Input:   m - number of rows
%          n - number of columns
% Output:  b - mxn array of blanks

% Version History
% 1996-01-23  Initial version based on MATLAB function "blanks".

b=setstr(ones(m,n).*' ');
