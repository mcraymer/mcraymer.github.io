function ver2(arg)
% VER2 MATLAB, SIMULINK, and TOOLBOX version information.
%   VER displays the current MATLAB and toolbox version numbers.
%   VER(TBX) displays the current version information for the
%   toolbox specified by the string TBX.
%
%   For example,
%      ver control
%   returns the version info for the Control System Toolbox.
%
%   See also VERSION, HOSTID, LICENSE, INFO, WHATSNEW.

%   Copyright (c) 1984-98 by The MathWorks, Inc.
%   $Revision: 5.21 $  $Date: 1997/11/21 23:32:46 $
%   Revised 2000/02/10, M. Craymer (added output of release
%   number using function release; renamed from ver to ver2)

p = path2cell(matlabpath);

if nargin > 0
  % Reverse the path strings for easy searching later
  for i=1:length(p),
    p{i} = fliplr(p{i});
  end
  if strcmp(lower(deblank(arg)),'matlab'),
    disp([prepender('MATLAB Version '),version,' on ',computer]);
    disp(['MATLAB Release ',release]);

    if isunix | isvms
       list = hostid; len = length(list);
       if len == 1
          disp(['MATLAB Server Hostid: ',list{1}])
       else
          disp(['MATLAB Server Hostid: ',list{1},' :'])
          for i=2:len-1
             disp(['                      ',list{i},' :'])
          end
          disp(['                      ',list{len}])
       end
    end
    disp(['MATLAB License Number: ',license]);
    arg = 'general';
    larg = length(arg);
  end
  arg = fixarg(p,arg);
  if strncmp(computer,'MAC',3)
  	arg = [arg filesep];
  end
  targ = fliplr([filesep arg]);
  larg = length(targ);
  for i=1:length(p),
    if strncmp(targ,p{i},larg);
       file = fullfile(fliplr(p{i}),'Contents.m');
       if exist(file)
           c = computer;
           if c(1:2) == 'PC'
              fp = fopen(file,'rb');
           else
              fp = fopen(file,'r');
           end
           s  = [fgetl(fp) '  '];
           s1 = [fgetl(fp) '  '];
           s(1:2) = [];
           s1(1:2) = [];
           if strcmp(deblank(lower(arg)),'general')
             disp(s1)
           else
             s = deblank(s);
             if length(s) > 45, s = [s(1:42) '...']; end
             disp([s blanks(45-length(s)) '  ' s1])
           end
           fclose(fp);
       else
           disp(['No Contents.m file for ' fliplr(p{i})])
       end
    end
  end
else
    disp('--------------------------------------------------')
    disp([prepender('MATLAB Version '),version,' on ',computer]);
    disp(['MATLAB Release ',release]);
    if isvms | isunix
       list = hostid; len = length(list);
       if len == 1
          disp(['MATLAB Server Hostid: ',list{1}])
       else
          disp(['MATLAB Server Hostid: ',list{1},' :'])
          for i=2:len-1
             disp(['                      ',list{i},' :'])
          end
          disp(['                      ',list{len}])
       end
    end
    disp(['MATLAB License Identification Number: ',license]);
    disp('--------------------------------------------------')
    
    % Remove the toolbox/matlab directories
    d = [];
    if isvms,
       tm  = 'toolbox:[matlab';
       tmg = 'toolbox:[matlab.general]';
    else
       tm  = ['toolbox' filesep 'matlab'];
       tmg = ['toolbox' filesep 'matlab' filesep 'general'];
    end
    % Look for and remove toolbox/local as well
    if isvms
      tl = 'toolbox:[local]';
    else
      tl = ['toolbox' filesep 'local'];
    end
    for i=1:length(p),
      if ~isempty(findstr(tmg,lower(p{i}))), k = i; end
      if ~isempty(findstr(tm,lower(p{i}))), 
          d = [d i]; 
      end
      if ~isempty(findstr(tl,lower(p{i}))), d = [d i]; end
    end
    p = [p(k);p];
    p(d+1) = [];
    
    % Now go through each directory and print out the version information
    % from the Contents.m file.
    for i=1:length(p)
        file = fullfile(p{i},'Contents.m');
        if exist(file)
            c = computer;
            if c(1:2) == 'PC'
              fp = fopen(file,'rb');
             else
              fp = fopen(file,'r');
             end
             s = fgetl(fp);  if ~isstr(s), s = ''; end
             s  = [s '  '];
             s1 = fgetl(fp); if ~isstr(s1), s1 = ''; end
             s1 = [s1 '  '];
             s(1:2) = [];
             s1(1:2) = [];
             if ~isempty(findstr(p{i},'general'))
                % Look for Version
                k = findstr('Version',s1);
                s = s1(1:k-1);
                s1 = s1(k:end);
             end
             s = deblank(s);
             % Remove any trailing period.
             if ~isempty(s) & s(end)=='.', s(end)=[]; end
             s1 = deblank(s1);
             if length(s) > 45, s = [s(1:42) '...']; end
             if ~isempty(s1)
               % Look for last space, presumably just before the date.
               k = max(find(s1==' '));
               s2 = s1(k+1:end);
               s1 = deblank(s1(1:k));
               s1 = [s1 ' ' blanks(20-length(s1)-1) s2];
               disp([s blanks(45-length(s)) '  ' s1])
             end
             fclose(fp);
        else
          % Skip this directory since there's no Contents.m
        end
    end
end

%--------------------------------------------------
function c = path2cell(p)
%PATH2CELL Split path into cell array of strings.
%   PATH2CELL(PATH) returns a cell array of strings containing the
%   individual path elements.

seps = [0 find(p==pathsep) length(p)+1];

c = cell(length(seps)-1,1);
for i=1:length(seps)-1,
  c{i} = p(seps(i)+1:seps(i+1)-1);
  if c{i}(end) == ']',
    c{i}(end) = [];
  end
end
%--------------------------------------------------
function newarg = fixarg (p, arg)
%FIXARG Fix the argument for special cases
%   FIXARG (PATH, ARG) returns a modified argument
%   for the special cases below.
%   1. toolboxes lmi, mpc, or mutools are not
%      conforming.
%   2. matlabroot/simulink is on the MAC path so
%      handle simulink differently in this case.

    switch arg
        case 'lmi'
            dir = 'lmilab';
        case 'mpc'
            dir = 'mpccmds';
        case 'mutools'
            dir = 'commands';
        otherwise
            dir = '';
    end
    if ~isempty(dir)
        targ = fliplr([filesep arg]);
        larg = length(targ);
        found = 0;
        for i=1:length(p)
            if strncmp(targ,p{i},larg)
                found = 1;
                break;
            end
        end
        if ~found
            newarg = [ arg filesep dir ];
        else
            newarg = arg;
        end
    else
        newarg = arg;
    end
    switch newarg
        case 'simulink'
            if strncmp(computer,'MAC',3)
                newarg = [newarg filesep newarg];
            end
    end
%--------------------------------------------------
