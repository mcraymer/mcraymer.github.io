function [year,month,day]=caldate(julian)
% CALDATE  Returns the calendar date for which the Julian day number
%   begins at noon. Positive year signifies A.D.; negative, B.C.
%   Remember that the year after 1 B.C. was 1 A.D. Adapted from
%   "Numerical Recipes in FORTRAN", by Press, Teukolsky, Vetterling,
%   and Flannery.  Cambridge University Press, 1999 (2nd Edition),
%   p.16. Non-vectorized. See also JULDATE.
% Version: 1999-04-26
% Usage:   [year, month, day]=caldate(julian)
% Input:   julian - julian date
% Output:  year   - year of Gregorian calendar
%          month  - month of Gregorian calendar 
%          day    - day of Gregorian calendar 

% Version History
% 1999-04-26  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin ~= 1
  error('Incorrect number of arguments');
end

igreg=2299161;          % Beginning of Gregorian calendar

ja=julian;
test=julian>=igreg;     % Gregorian calendar begins Oct 15, 1582
jalpha=fix((julian(test)-1867216-0.25)/36524.25);
ja(test)=julian(test)+1+jalpha-fix(0.25*jalpha);

jb=ja+1524;
jc=fix(6680.0+((jb-2439870)-122.1)/365.25);
jd=fix(365*jc+(0.25*jc));
je=fix((jb-jd)/30.6001);

day=jb-jd-fix(30.6001*je);
month=je-1;
test=month>12;
month(test)=month(test)-12;
year=jc-4715;
test=month>2;
year(test)=year(test)-1;
test=year<=0;
year(test)=year(test)-1;
