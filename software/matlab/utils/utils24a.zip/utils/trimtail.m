function s2 = trimtail(s1)
% TRIMTAIL  Strips trailing blanks from tail end of string s1 and
%   returns trimmed string s2.
% Version: 2007-06-14
% Useage:  s2=trimtail(s1)
% Input:   s1 - string to be trimmed
% Output:  s2 - trimmed string

% Version History
% 2007-06-14  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if ~isstr(s1)
    error('Input must be a string.')
end
if isempty(s1)
  s2 = s1;
  return;
end

% Find last non-blank character
iend = min(find(fliplr(s1) ~= ' '));
iend = length(s1)-iend(1)+1;

s2 = s1(1:iend);
