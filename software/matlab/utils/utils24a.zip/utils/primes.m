function p=primes(nmax)
% PRIMES  Finds prime numbers up to user-specified limit.
% Version 1999-09-20
% Usage:  p=primes(nmax)
% Input:  nmax - user-specified limit for prime number search
% Output: p    - vector of prime numbers less than or equal to nmax

% Version History
% 1999-09-20  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nmax < 1
  error('Invalid argument nmax');
elseif nmax == 1
  p=1;
elseif nmax == 2
  p=[1;2];
else
  p=2;
  for n=3:nmax
    if all( rem(n*ones(size(p)), p) ~= 0 )
      p=[p;n];
    end
  end
  p=[1;p];
end
