function D=bdiag(B,n)
% BDIAG  Block diagonal matrix. Forms a block diagonal matrix using
%   matrix B along n diagonal blocks.
% Version 1992-11-26
% Useage: D=bdiag(B,n)
% Input:  B - matrix to put on diagonal blocks
%         n - number of diagonal blocks
% Output: D - block diagonal matrix

% Version History
% 1992-11-26  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

m=max(size(B));
D=zeros(m*n,m*n);
for i=1:m:n*m
  D(i:i+m-1,i:i+m-1)=B;
end
