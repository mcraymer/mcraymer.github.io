function z=gridder(x,y,v,n);
% Gridder
%   Creates a grid matrix of "vertical" v coordinates at arbitrarily
%   spaced x,y coordinates for use in 3D mesh and contour plots. Grid
%   is defined by n, the min. number of grids in either x or y.
%   Relative x-y scale is maintained. v coordinates are assigned to
%   nearest grid point. If more than 1 point is assigned to the same
%   grid point, the largest v value is used. Resolution of the grid is
%   improved by increasing n. The grid is defined so that the default
%   mesh view is from the SW.
% Version: 1993-08-30
% Useage: z=gridder(x,y,v,n)
% Input:  x - x coordinate of points (N)
%         y - y coordinate of points (E)
%         v - vertical coordinate of points
%         n - minimum number of grids in one dimension
% Output: z - grid array of vertical values

% Version History
% 1993-08-30  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

maxx=max(x);
minx=min(x);
maxy=max(y);
miny=min(y);
dx=(maxx-minx)/(n-3);
dy=(maxy-miny)/(n-3);
ds=max(dx,dy);               % Grid spacing
ix=round((-x+maxx)/ds)+2;    % switch sign to view from SW
iy=round((y-miny)/ds)+2;
if dx==ds
  iyo=floor((n-max(iy)+1)/2)-1;
  iy=iy+iyo;
end
if dy==ds
  ixo=floor((n-max(ix)+1)/2)-1;
  ix=ix+ixo;
end
z=zeros(n,n);
for i=1:length(ix)
  z(ix(i),iy(i))=max(v(i),z(ix(i),iy(i)));
end
