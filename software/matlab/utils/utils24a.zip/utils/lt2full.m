function Cf=lt2full(Cl);
% LT2FULL  Converts a lower triangular matrix to fully populated
%   matrix.
% Version 1995-02-25
% Useage: Cf=lt2full(Cl)
% Input:  Cl - lower triangular matrix
% Output: Cf - fully populated matrix

% Version History
% 1995-02-25  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

Cf=Cl+Cl'-diag(diag(Cl));
