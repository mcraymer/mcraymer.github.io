function liststr(s)
% LISTSTR  Lists numbered vector of strings (vector index numbers used
%   for ids) to screen.
% Version: 1993-08-25
% Useage:  liststr(s)
% Input:   s - string
% Output:  screen list

% Version History
% 1993-08-25  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

disp(' ');
for i=1:max(size(s))
%  disp([num2str(i),'  ',s(i,:)])
  fmt=['%4.0f  ',s(i,:),'\n'];
  fprintf(fmt,i);
end
disp(' ');
