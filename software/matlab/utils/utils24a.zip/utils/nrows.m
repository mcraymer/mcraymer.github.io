function nr=nrows(A)
% NROWS  Returns number of rows in matrix.
% Version 1997-09-20
% Usage:  nr=nrows(A)
% Input:  A  - matrix
% Output: nr - number of rows

% Version History
% 1997-09-20  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

[nr,nc]=size(A);
