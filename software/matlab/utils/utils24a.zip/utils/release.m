function r=release
% RELEASE  MATLAB release number.
%   RELEASE returns the current MATLAB release number.
%   Calls MATLAB function VERSION.
%
%   See also VER, VERSION, HOSTID, LICENSE, INFO, WHATSNEW.

%   Revised 2000-02-10, M. Craymer

v=version;
switch v(1:5)
  case '5.2.0', r='10';
  case '5.2.1', r='10.1';
  case '5.3.0', r='11';
  case '5.3.1', r='11.1';
end
