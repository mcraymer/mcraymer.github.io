function [julian]=juldate(year, month, day)
% JULDATE  Returns the Julian Day Number that begins at noon of the
%   calendar date. Positive year signifies A.D.; negative, B.C. The
%   year after 1 B.C. was 1 A.D. (there is no year 0). Adapted from
%   "Numerical Recipes in FORTRAN", by Press, Teukolsky, Vetterling
%   and Flannery.  Cambridge University Press, 1999 (2nd Edition),
%   p.13. Non-vectorized. See also CALDATE.
% Version: 1999-04-26
% Usage:   [julian]=juldate(year,month,day)
% Input:   year   - year of Gregorian calendar
%          month  - month of Gregorian calendar 
%          day    - day of Gregorian calendar 
% Output:  julian - julian date

% Version History
% 1999-04-26  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if nargin ~= 3
  error('Incorrect number of arguments');
end

igreg=15+31*(10+12*1582);   % Gregorian Calander adopted Oct 15, 1582

test=year<=0;
year(test)=year(test)+1;

test=month>2;
jy=year;jm=month;
jm(test)=jm(test)+1;
jy(~test)=jy(~test)-1;
jm(~test)=jm(~test)+13;

julian=fix(floor(365.25*jy)+floor(30.6001*jm)+day+1720995);

% Test whether to change to Gregorian Calandar
test=day+31*(month+12*year)>=igreg;
ja=fix(0.01*jy(test));
julian(test)=julian(test)+2-ja+fix(0.25*ja);
