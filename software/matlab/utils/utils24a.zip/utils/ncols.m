function nc=ncols(A)
% NCOLS  Returns number of columns in matrix.
% Version 1997-09-20
% Usage:  nr=ncols(A)
% Input:  A  - matrix
% Output: nc - number of columns

% Version History
% 1997-09-20  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

[nr,nc]=size(A);
