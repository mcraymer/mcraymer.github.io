function ind=strind(str,strarr)
% STRIND  Finds row index for a string in an array of strings. Strings
%   must have same column dimension.
% Version 1996-02-21
% Usage: ind=strind(str,strarr)
% Input:  str    - string to find
%         strarr - array of strings
% Output: ind    - row index of str in strarr

% Version History
% 1996-02-21  Initial version.

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

if (nargin<2)
  error('Too few input arguments');
end
[m,n]=size(strarr);
for i=1:m
  if (strcmp(str,strarr(i,:)))
    ind=i;
    break;
  end
end
